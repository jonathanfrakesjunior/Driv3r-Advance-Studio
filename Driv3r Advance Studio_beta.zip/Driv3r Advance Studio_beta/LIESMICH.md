# Driv3r Advance Studio

Mod-Werkzeug für **Driv3r** (Game Boy Advance, Europe-Fassung, Code B3RP, 8 MB).
Läuft ohne Installation im Browser: **`index.html` doppelklicken** (oder `Driv3r Advance Studio starten.bat`).
Kein Server, kein Python, keine Internetverbindung nötig. Getestet mit Chrome/Edge.

**Sprachen:** Deutsch, English, Français, Español, Italiano – Auswahl oben rechts (wird gemerkt).
Anleitung auch als [README_EN.md](README_EN.md), [LISEZMOI_FR.md](LISEZMOI_FR.md), [LEEME_ES.md](LEEME_ES.md), [LEGGIMI_IT.md](LEGGIMI_IT.md).

Erwartete ROM: SHA-1 `3e4da1cd2a5915d2218cd59e061baeb3a08be1c6`.

## Loslegen

1. `index.html` öffnen, **ROM laden** (oder die .gba ins Fenster ziehen).
2. Links einen Bereich wählen, exportieren, bearbeiten, importieren.
3. Unter **ROM & Projekt** regelmäßig das Projekt sichern (`.d3studio` – enthält nur deine Änderungen).
4. **ROM speichern** erzeugt die fertige `.gba` (Kopf-Prüfsumme wird korrigiert). Immer in mGBA testen.
   Alternativ: **IPS-Patch erzeugen** zum Weitergeben ohne ROM.

Die Original-Datei wird nie verändert. Wird Platz knapp, verschiebt das Studio Daten automatisch ans ROM-Ende,
biegt alle Zeiger um und erweitert die ROM bei Bedarf auf 16 MB (mehr verträgt der EEPROM-Speicherstand nicht).

## Bereiche

| Bereich | Inhalt | Format |
|---|---|---|
| Bilder & Texturen | Titelbild, Hauptmenü, 2 Menü-3D-Texturen, 10 Stadt-Texturatlanten 256×256 | indiziertes PNG; VC-Kompression automatisch |
| Zwischensequenzen | 213 Story-Standbilder 240×160, 33 Bildfolgen mit Untertiteln (EN/FR/DE/ES/IT) | PNG/JPG rein, JPEG wird passend neu kodiert |
| Sprites | 23 Fahrzeuge (alle Blickwinkel), Figuren-Animationen, Effekte | PNG je Bild (auch in neuer Größe) oder als Bogen (8 Bilder/Zeile) |
| HUD, Schrift & Skyline | HUD-Symbole, Menü-Schrift, **Spielschrift** (256 Zeichen 8×16 für alle Meldungen), 6 Skyline-Panoramen | 4-Bit-PNG, Zeichen-Editor |
| Paletten | 16 Palettendateien (Städte Tag/Abend/Nacht, Menüs, HUD) | Farbwahl, JASC .pal, .act, PNG |
| Texte | Missionsmeldungen 5-sprachig, Credits, Menütexte | Editor + CSV |
| Sound & Musik | 10 Songs (Tracker GBAMOD30), 16 Instrumente, 38 Effekte | WAV, MIDI-Export/-Import, .gbamod roh |
| Karteneditor | Miami & Nizza als texturierte Draufsicht aus den 3D-Daten, Verkehrsspuren | **Neue Gebäude, Straßen mit KI-Verkehr, Plätze, Wasser, Rampen, Brücken bauen**; Flächen löschen/verschieben/neu texturieren, Zellen leeren/wiederherstellen, Deskriptoren |
| Missionen | 25 Missionen (Miami 1–12, Nizza 13–25) mit allen Schritten, alle 19 Befehle benannt | Felder/Hex bearbeiten, Schritte einfügen/löschen/verschieben, Punkte auf der Karte ziehen, JSON |
| Komplett-Paket | alles als ZIP heraus und wieder hinein | Unverändert eingespielt bleibt die ROM byte-identisch |

### Tipps

* **Bilder:** Indizierte PNGs behalten ihre Indizes. RGB-Bilder werden der Palette zugeordnet. Für komplett neue
  Vollbilder „Neue Farben erzeugen" anhaken – das Studio berechnet eine eigene Palette im erlaubten Bereich.
* **Stadt-Texturen** werden über Deskriptoren (Rahmen) auf die 3D-Flächen gelegt. Option „Textur-Rahmen" zeigt sie im Atlas.
  Motive an derselben Stelle lassen oder im Karteneditor den Deskriptor anpassen.
* **Musik per MIDI:** Jedem MIDI-Kanal ein Instrument zuordnen; Akkorde werden auf bis zu 8 GBA-Kanäle verteilt.
  „Probehören" rendert die Vorschau im Browser, ohne zu speichern. Eigene Instrumente zuerst als WAV importieren.
* **Bauen (Karteneditor → Bauen):** *Gebäude*: Eckpunkte klicken, Doppelklick baut (konvexer Grundriss, Höhe,
  Stockwerk, Fassaden-/Dachtextur, massiv, Verdeckung). *Boden/Straße*: Rechteck aufziehen – Straße, Gras, Wasser oder
  nur Grafik; unterschiedliche Anfangs-/Endhöhe = Rampe, Höhe über Wasser = Brücke. Straßen ab 64 Einheiten Breite
  bekommen automatisch zwei Gegenspuren mit KI-Verkehr (Rechtsverkehr), die an Spuren in der Nähe (bis 200 Einheiten)
  angeschlossen werden – also am besten an einer Kreuzung ansetzen. Ebene „Verkehr" zeigt alle Spuren.
  *Flächen*: einzelne Flächen anklicken und löschen, verschieben, neu texturieren oder das Material ändern.
  Beim ersten Bauen wird die Stadt ans ROM-Ende kopiert (ROM wird 16 MB); das Original bleibt unberührt.
* **Missionen:** 00 Missionsstart (Texturensatz, Tageszeit, Fahrzeug, Startposition), 02 Speicherpunkt,
  03 Ziele mit Zeitlimit, 04/0B/10 hinfahren (Zone, Markierung oder Objekt, mit Radarpfeil), 05 Zwischensequenz,
  06 Meldung (Nummer = Meldungs-ID im Text-Tab), 07 Timer, 08 Straßensperre (6 Objekte), 09 KI-Fahrzeug mit Route,
  0A Akteur mit Countdown, 0C Verfolgung, 0D Formation, 0E warten auf Akteur, 0F Rennen, 11 Pfad, 12 Mission geschafft.
  Im Karteneditor erscheinen die Punkte der gewählten Mission und können mit der Maus verschoben werden.
* **Spielschrift:** Unter „HUD, Schrift & Skyline" → Gruppe „Schrift". Neu gezeichnete Zeichen (z. B. Kleinbuchstaben)
  sind danach im Text-Editor erlaubt.

## Technische Notizen (für Neugierige)

* Kompression „VC" (VD-dev): Kopf `VC`, u32 Größe, Modus 0–9; Bitstrom mit Gamma-Codes (Dekoder im Spiel bei 0x08254338).
* Grafik: Mode 4 (8-Bit-Bitmap), HUD/Schrift/Skyline als 4-Bit-Objekte im 1D-Modus.
* Stadt: 128×128 Zellen à 512 Einheiten, Raster ab Kartenbasis (Miami 0x5F8800, Nizza 0x4B0000),
  Textur-Deskriptoren ab Basis+0xC000, Missionstabelle über Basis+0x11020, Kollisionsflächen über Basis+0x1101C,
  Verdeckungswände über Basis+0x11000, Verkehrsspuren über Basis+0x11064 (je Spur: Knoten X/Höhe/Y + Nachfolger).
  Zelleinträge: 0 Geometrie (muss vorn stehen, liefert die Bodenhöhe), 1 Verdeckung, 2 Detail, 3 Objekte,
  4 Kollision, 5 Verkehrs-Startpunkte.
* Missions-Interpreter ab 0x0816E178 (Init-Tabelle 0x0817137C, Update-Tabelle 0x0816E324).
* Spielschrift: Zeiger bei 0x234E54, 256 Zeichen à 8×16 Pixel, 4 Bit.
* Sound: „LS_Play (C) Logik State 2003", Mischrate 10512 Hz, Songs „GBAMOD30" (RLE-kodierte Kanalspalten).
* Zwischensequenzen: Standard-JPEG, nur der SOS-Marker FFDA ist als FF1A abgelegt.

## Mod: Vice City (mods/Driv3r - Vice City Mod.gba)

Miami ist komplett durch eine Stadt nach der Vorlage `werkzeuge/vice_city_karte.png` ersetzt (Nizza bleibt original):
zwei Hauptinseln mit Strand, Parks, Flughafen, Brücken und kleinen Inseln, 365 Straßenabschnitte mit KI-Verkehr
(730 Spuren), rund 740 Gebäude an den Straßen (hohe Blöcke auf den weißen Flächen der Vorlage), Kaimauern, Wasser.
Die Bebauungsdichte ist so gewählt, dass das Spiel wie das Original mit 20 Bildern/s läuft.
Spielerstart und Startautos stehen in der Innenstadt der Westinsel; alle Missionspunkte wurden auf die nächstgelegene
neue Straße verschoben (Mission 1 komplett relativ zum neuen Start). Die Missionen sind dadurch spielbar, folgen aber
nicht mehr der ursprünglichen Miami-Geografie – im Missionseditor lassen sie sich weiter anpassen.
Die ROM lässt sich im Studio öffnen und weiterbearbeiten (Bauen, Flächen, Verkehr).

**Eigene Städte:** `werkzeuge/stadt_aus_bild.py <bild.png> <ausgabe.gba> [Einheiten pro Pixel]` (Python mit numpy,
scipy, scikit-image, Pillow). Farben der Vorlage: Blau = Wasser, Schwarz = Straße, Gelb = Strand, Grün = Park,
Grau = bebaubare Fläche, Weiß = hohe Gebäude. Die Original-ROM wird aus dem Studio-Ordner gelesen.

## Grenzen

* Gebäude-Grundrisse müssen konvex sein (L- oder U-Formen aus mehreren Gebäuden zusammensetzen).
* Objekte in den Zellen (Typ 3: Laternen, Hydranten usw.) werden angezeigt und bleiben erhalten, aber nicht einzeln bearbeitet.
* Die Song-Vorschau im Browser ist eine Nachbildung des Tracker-Players – im Spiel kann es minimal anders klingen.
