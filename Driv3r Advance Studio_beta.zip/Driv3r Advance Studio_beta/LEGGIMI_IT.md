# Driv3r Advance Studio

Strumento di modding per **Driv3r** (Game Boy Advance, versione europea, codice B3RP, 8 MB).
Funziona nel browser senza installazione: **fai doppio clic su `index.html`** (oppure su `Driv3r Advance Studio starten.bat`).
Non servono server, Python né connessione a Internet. Testato con Chrome/Edge.

**Lingue:** Deutsch, English, Français, Español, Italiano – si scelgono in alto a destra (la scelta viene ricordata).

ROM prevista: SHA-1 `3e4da1cd2a5915d2218cd59e061baeb3a08be1c6`.

## Per iniziare

1. Apri `index.html`, fai clic su **Carica ROM** (oppure trascina il .gba nella finestra).
2. Scegli una sezione a sinistra: esporta, modifica, importa.
3. Salva regolarmente il progetto in **ROM e progetto** (`.d3studio` – contiene solo le tue modifiche).
4. **Salva ROM** crea il `.gba` finale (il checksum dell'intestazione viene corretto). Provalo sempre in mGBA.
   In alternativa: **Crea patch IPS** per condividere senza la ROM.

Il file originale non viene mai modificato. Quando lo spazio scarseggia, lo Studio sposta automaticamente i dati alla fine della ROM,
aggiorna tutti i puntatori ed espande la ROM a 16 MB se necessario (il salvataggio EEPROM non consente di più).

## Sezioni

| Sezione | Contenuto | Formato |
|---|---|---|
| Immagini e texture | Schermata del titolo, menu principale, 2 texture 3D del menu, 10 atlanti texture delle città 256×256 | PNG indicizzato; compressione VC automatica |
| Filmati | 213 immagini fisse della storia 240×160, 33 sequenze con sottotitoli (EN/FR/DE/ES/IT) | PNG/JPG in entrata, il JPEG viene ricodificato automaticamente |
| Sprite | 23 veicoli (tutte le angolazioni), animazioni dei personaggi, effetti | PNG per fotogramma (anche in nuova dimensione) o come foglio (8 fotogrammi/riga) |
| HUD, font e skyline | Simboli HUD, font del menu, **font di gioco** (256 caratteri 8×16 per tutti i messaggi), 6 panorami skyline | PNG a 4 bit, editor di caratteri |
| Tavolozze | 16 file di tavolozza (città giorno/sera/notte, menu, HUD) | selettore colore, JASC .pal, .act, PNG |
| Testi | Messaggi di missione in 5 lingue, riconoscimenti, testi dei menu | editor + CSV |
| Suono e musica | 10 brani (tracker GBAMOD30), 16 strumenti, 38 effetti | WAV, esportazione/importazione MIDI, .gbamod grezzo |
| Editor mappa | Miami e Nizza in vista dall'alto con texture dai dati 3D, corsie del traffico | **Costruisci edifici, strade con traffico IA, piazze, acqua, rampe, ponti**; elimina/sposta/ritexturizza facce, svuota/ripristina celle, descrittori |
| Missioni | 25 missioni (Miami 1–12, Nizza 13–25) con tutti i passi, tutti i 19 comandi con nome | modifica campi/hex, inserisci/elimina/sposta passi, trascina punti sulla mappa, JSON |
| Pacchetto completo | tutto come ZIP, in uscita e in entrata | reimportato senza modifiche, la ROM resta identica byte per byte |

### Suggerimenti

* **Immagini:** i PNG indicizzati mantengono i loro indici. Le immagini RGB vengono adattate alla tavolozza. Per immagini intere
  completamente nuove spunta «Genera nuovi colori» – lo Studio calcola una tavolozza propria nell'intervallo consentito.
* Le **texture delle città** vengono applicate alle facce 3D tramite descrittori (riquadri). L'opzione «Riquadri texture» li mostra nell'atlante.
  Lascia i motivi nella stessa posizione oppure adatta il descrittore nell'editor mappa.
* **Musica via MIDI:** assegna uno strumento a ogni canale MIDI; gli accordi vengono distribuiti su un massimo di 8 canali GBA.
  «Ascolta» calcola l'anteprima nel browser senza salvare. Importa prima i tuoi strumenti come WAV.
* **Costruire (editor mappa → Costruisci):** *Edificio*: fai clic sui vertici, il doppio clic costruisce (pianta convessa, altezza,
  piano, texture di facciata/tetto, solido, occlusione). *Suolo/strada*: traccia un rettangolo – strada, erba, acqua o
  solo grafica; altezza iniziale/finale diversa = rampa, altezza sopra l'acqua = ponte. Le strade larghe almeno 64 unità
  ricevono automaticamente due corsie opposte con traffico IA (guida a destra), collegate alle corsie vicine (fino a 200 unità)
  – conviene quindi partire da un incrocio. Il livello «Traffico» mostra tutte le corsie.
  *Facce*: fai clic su singole facce per eliminarle, spostarle, ritexturizzarle o cambiarne il materiale.
  Alla prima costruzione la città viene copiata alla fine della ROM (la ROM diventa di 16 MB); l'originale resta intatto.
* **Missioni:** 00 inizio missione (set di texture, ora del giorno, veicolo, posizione di partenza), 02 checkpoint,
  03 bersagli con limite di tempo, 04/0B/10 raggiungi (zona, segnalino o oggetto, con freccia radar), 05 filmato,
  06 messaggio (numero = ID del messaggio nella scheda Testi), 07 timer, 08 posto di blocco (6 oggetti), 09 veicolo IA con percorso,
  0A attore con conto alla rovescia, 0C inseguimento, 0D formazione, 0E attendi attore, 0F gara, 11 percorso, 12 missione superata.
  L'editor mappa mostra i punti della missione scelta; si possono spostare con il mouse.
* **Font di gioco:** in «HUD, font e skyline» → gruppo «Font». I caratteri appena disegnati (ad es. le minuscole)
  vengono poi accettati nell'editor di testo.

## Note tecniche (per i curiosi)

* Compressione «VC» (VD-dev): intestazione `VC`, dimensione u32, modalità 0–9; flusso di bit con codici gamma (decoder del gioco a 0x08254338).
* Grafica: modalità 4 (bitmap a 8 bit), HUD/font/skyline come oggetti a 4 bit in modalità 1D.
* Città: 128×128 celle da 512 unità, griglia alla base della mappa (Miami 0x5F8800, Nizza 0x4B0000),
  descrittori texture a base+0xC000, tabella missioni tramite base+0x11020, superfici di collisione tramite base+0x1101C,
  muri di occlusione tramite base+0x11000, corsie del traffico tramite base+0x11064 (per corsia: nodi X/altezza/Y + successori).
  Voci di cella: 0 geometria (deve venire per prima, fornisce l'altezza del suolo), 1 occlusione, 2 dettaglio, 3 oggetti,
  4 collisione, 5 punti di comparsa del traffico.
* Interprete delle missioni a 0x0816E178 (tabella di inizializzazione 0x0817137C, tabella di aggiornamento 0x0816E324).
* Font di gioco: puntatore a 0x234E54, 256 caratteri da 8×16 pixel, 4 bit.
* Suono: «LS_Play (C) Logik State 2003», frequenza di mixaggio 10512 Hz, brani «GBAMOD30» (colonne dei canali codificate RLE).
* Filmati: JPEG standard, solo il marcatore SOS FFDA è memorizzato come FF1A.

## Mod: Vice City (mods/Driv3r - Vice City Mod.gba)

Miami è sostituita interamente da una città basata sul modello `werkzeuge/vice_city_karte.png` (Nizza resta originale):
due isole principali con spiaggia, parchi, aeroporto, ponti e isolette, 365 tratti di strada con traffico IA
(730 corsie), circa 740 edifici lungo le strade (blocchi alti sulle aree bianche del modello), banchine, acqua.
La densità edilizia è scelta in modo che il gioco giri a 20 fotogrammi/s come l'originale.
La partenza del giocatore e le auto iniziali si trovano nel centro dell'isola ovest; tutti i punti missione sono stati spostati
sulla nuova strada più vicina (la missione 1 interamente relativa alla nuova partenza). Le missioni sono quindi giocabili, ma non seguono
più la geografia originale di Miami – si possono adattare ulteriormente nell'editor missioni.
La ROM si può aprire nello Studio e continuare a modificare (costruzione, facce, traffico).

**Le tue città:** `werkzeuge/stadt_aus_bild.py <immagine.png> <uscita.gba> [unità per pixel]` (Python con numpy,
scipy, scikit-image, Pillow). Colori del modello: blu = acqua, nero = strada, giallo = spiaggia, verde = parco,
grigio = area edificabile, bianco = edifici alti. La ROM originale viene letta dalla cartella dello Studio.

## Limiti

* Le piante degli edifici devono essere convesse (componi forme a L o a U con più edifici).
* Gli oggetti nelle celle (tipo 3: lampioni, idranti ecc.) vengono mostrati e conservati, ma non modificati singolarmente.
* L'anteprima dei brani nel browser è una ricostruzione del player tracker – nel gioco il suono può differire leggermente.
