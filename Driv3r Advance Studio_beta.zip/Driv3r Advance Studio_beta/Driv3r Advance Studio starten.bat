@echo off
title Driv3r Advance Studio
cd /d "%~dp0"
echo.
echo   Driv3r Advance Studio wird geoeffnet ...
echo.
start "" "%~dp0index.html"
echo   Falls sich nichts oeffnet: index.html doppelklicken
echo   oder per Rechtsklick mit Chrome / Edge / Firefox oeffnen.
timeout /t 4 >nul
