# Driv3r Advance Studio

Herramienta de modding para **Driv3r** (Game Boy Advance, versión europea, código B3RP, 8 MB).
Funciona en el navegador sin instalación: **haz doble clic en `index.html`** (o en `Driv3r Advance Studio starten.bat`).
No necesita servidor, Python ni conexión a Internet. Probado con Chrome/Edge.

**Idiomas:** Deutsch, English, Français, Español, Italiano; se eligen arriba a la derecha (se recuerda).

ROM esperada: SHA-1 `3e4da1cd2a5915d2218cd59e061baeb3a08be1c6`.

## Primeros pasos

1. Abre `index.html` y pulsa **Cargar ROM** (o arrastra el .gba a la ventana).
2. Elige una sección a la izquierda: exportar, editar, importar.
3. Guarda el proyecto con regularidad en **ROM y proyecto** (`.d3studio`: solo contiene tus cambios).
4. **Guardar ROM** genera el `.gba` final (se corrige la suma de comprobación de la cabecera). Pruébalo siempre en mGBA.
   Alternativa: **Crear parche IPS** para compartir sin la ROM.

El archivo original nunca se modifica. Si falta espacio, el Studio mueve los datos automáticamente al final de la ROM,
actualiza todos los punteros y amplía la ROM a 16 MB si hace falta (la partida guardada en EEPROM no admite más).

## Secciones

| Sección | Contenido | Formato |
|---|---|---|
| Imágenes y texturas | Pantalla de título, menú principal, 2 texturas 3D del menú, 10 atlas de texturas de ciudad 256×256 | PNG indexado; compresión VC automática |
| Cinemáticas | 213 imágenes fijas de la historia 240×160, 33 secuencias con subtítulos (EN/FR/DE/ES/IT) | entrada PNG/JPG, el JPEG se recodifica automáticamente |
| Sprites | 23 vehículos (todos los ángulos), animaciones de personajes, efectos | PNG por fotograma (también en otro tamaño) o como hoja (8 fotogramas/fila) |
| HUD, fuente y skyline | Símbolos del HUD, fuente del menú, **fuente del juego** (256 caracteres de 8×16 para todos los mensajes), 6 panoramas de skyline | PNG de 4 bits, editor de caracteres |
| Paletas | 16 archivos de paleta (ciudades día/tarde/noche, menús, HUD) | selector de color, JASC .pal, .act, PNG |
| Textos | Mensajes de misión en 5 idiomas, créditos, textos de menú | editor + CSV |
| Sonido y música | 10 canciones (tracker GBAMOD30), 16 instrumentos, 38 efectos | WAV, exportación/importación MIDI, .gbamod en bruto |
| Editor de mapa | Miami y Niza en vista cenital texturizada a partir de los datos 3D, carriles de tráfico | **Construir edificios, carreteras con tráfico IA, plazas, agua, rampas, puentes**; eliminar/mover/retexturizar caras, vaciar/restaurar celdas, descriptores |
| Misiones | 25 misiones (Miami 1–12, Niza 13–25) con todos los pasos, las 19 órdenes con nombre | editar campos/hex, insertar/eliminar/mover pasos, arrastrar puntos en el mapa, JSON |
| Paquete completo | todo como ZIP, de ida y vuelta | importado sin cambios, la ROM queda idéntica byte a byte |

### Consejos

* **Imágenes:** los PNG indexados conservan sus índices. Las imágenes RGB se asignan a la paleta. Para imágenes completas
  totalmente nuevas marca «Generar colores nuevos»: el Studio calcula una paleta propia dentro del rango permitido.
* Las **texturas de ciudad** se aplican a las caras 3D mediante descriptores (marcos). La opción «Marcos de textura» los muestra en el atlas.
  Deja los motivos en el mismo sitio o ajusta el descriptor en el editor de mapa.
* **Música por MIDI:** asigna un instrumento a cada canal MIDI; los acordes se reparten en hasta 8 canales de GBA.
  «Escuchar» calcula la vista previa en el navegador sin guardar. Importa antes tus propios instrumentos como WAV.
* **Construir (editor de mapa → Construir):** *Edificio*: haz clic en los vértices; el doble clic construye (planta convexa, altura,
  planta, textura de fachada/tejado, sólido, ocultación). *Suelo/carretera*: dibuja un rectángulo: carretera, hierba, agua o
  solo gráfico; altura inicial/final distinta = rampa, altura sobre el agua = puente. Las carreteras de 64 unidades de ancho o más
  reciben automáticamente dos carriles opuestos con tráfico IA (circulación por la derecha), conectados a los carriles cercanos (hasta 200 unidades);
  por eso conviene empezar en un cruce. La capa «Tráfico» muestra todos los carriles.
  *Caras*: haz clic en caras sueltas para eliminarlas, moverlas, retexturizarlas o cambiar su material.
  En la primera obra la ciudad se copia al final de la ROM (la ROM pasa a 16 MB); el original queda intacto.
* **Misiones:** 00 inicio de misión (conjunto de texturas, hora del día, vehículo, posición inicial), 02 punto de control,
  03 objetivos con límite de tiempo, 04/0B/10 ir a (zona, marcador u objeto, con flecha de radar), 05 cinemática,
  06 mensaje (número = ID del mensaje en la pestaña Textos), 07 temporizador, 08 control de carretera (6 objetos), 09 vehículo IA con ruta,
  0A actor con cuenta atrás, 0C persecución, 0D formación, 0E esperar a un actor, 0F carrera, 11 ruta, 12 misión superada.
  El editor de mapa muestra los puntos de la misión elegida; se pueden mover con el ratón.
* **Fuente del juego:** en «HUD, fuente y skyline» → grupo «Fuente». Los caracteres recién dibujados (p. ej. minúsculas)
  quedan admitidos después en el editor de textos.

## Notas técnicas (para curiosos)

* Compresión «VC» (VD-dev): cabecera `VC`, tamaño u32, modo 0–9; flujo de bits con códigos gamma (decodificador del juego en 0x08254338).
* Gráficos: modo 4 (bitmap de 8 bits), HUD/fuente/skyline como objetos de 4 bits en modo 1D.
* Ciudad: 128×128 celdas de 512 unidades, cuadrícula en la base del mapa (Miami 0x5F8800, Niza 0x4B0000),
  descriptores de textura en base+0xC000, tabla de misiones vía base+0x11020, superficies de colisión vía base+0x1101C,
  muros de ocultación vía base+0x11000, carriles de tráfico vía base+0x11064 (por carril: nodos X/altura/Y + sucesores).
  Entradas de celda: 0 geometría (debe ir primero, da la altura del suelo), 1 ocultación, 2 detalle, 3 objetos,
  4 colisión, 5 puntos de aparición del tráfico.
* Intérprete de misiones en 0x0816E178 (tabla de inicio 0x0817137C, tabla de actualización 0x0816E324).
* Fuente del juego: puntero en 0x234E54, 256 caracteres de 8×16 píxeles, 4 bits.
* Sonido: «LS_Play (C) Logik State 2003», frecuencia de mezcla 10512 Hz, canciones «GBAMOD30» (columnas de canal codificadas en RLE).
* Cinemáticas: JPEG estándar, solo el marcador SOS FFDA está guardado como FF1A.

## Mod: Vice City (mods/Driv3r - Vice City Mod.gba)

Miami se sustituye por completo por una ciudad basada en la plantilla `werkzeuge/vice_city_karte.png` (Niza sigue siendo la original):
dos islas principales con playa, parques, aeropuerto, puentes e islas pequeñas, 365 tramos de carretera con tráfico IA
(730 carriles), unos 740 edificios junto a las carreteras (bloques altos en las zonas blancas de la plantilla), muelles, agua.
La densidad de edificación está elegida para que el juego funcione a 20 fotogramas/s como el original.
El inicio del jugador y los coches iniciales están en el centro de la isla oeste; todos los puntos de misión se movieron a la
carretera nueva más cercana (la misión 1 entera es relativa al nuevo inicio). Por eso las misiones son jugables, pero ya no siguen
la geografía original de Miami; se pueden ajustar más en el editor de misiones.
La ROM se puede abrir en el Studio y seguir editando (construcción, caras, tráfico).

**Tus propias ciudades:** `werkzeuge/stadt_aus_bild.py <imagen.png> <salida.gba> [unidades por píxel]` (Python con numpy,
scipy, scikit-image, Pillow). Colores de la plantilla: azul = agua, negro = carretera, amarillo = playa, verde = parque,
gris = zona edificable, blanco = edificios altos. La ROM original se lee de la carpeta del Studio.

## Límites

* Las plantas de los edificios deben ser convexas (compón formas en L o en U con varios edificios).
* Los objetos de las celdas (tipo 3: farolas, bocas de incendio, etc.) se muestran y se conservan, pero no se editan por separado.
* La vista previa de las canciones en el navegador es una recreación del reproductor tracker; en el juego puede sonar ligeramente distinta.
