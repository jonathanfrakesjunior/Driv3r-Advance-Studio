/* Driv3r Advance Studio - mapbuild.js : Bauen in der Stadt (neue Gebaeude, Strassen, Rampen, Bruecken)
   Erkenntnisse (im Emulator verifiziert):
   - Zelleintraege: Typ 0 Geometrie (MUSS Eintrag 0 sein - daraus kommt die Bodenhoehe), Typ 2 Detail-Geometrie,
     Typ 1 Verdeckungswaende (Occluder, blenden Dahinterliegendes aus; liegen ~26 Einheiten innen),
     Typ 3 Objekte, Typ 4 begehbare/feste Flaechen (Kollision; muss Eintrag 0 oder 1 sein), Typ 5 Verkehrs-Startpunkte.
   - Verkehr: Spurtabelle R = Basis + u32[Basis+0x11064]: u16 Offset[N] (Halbworte ab R, Offset[0] = N) -> Spur =
     u8 Knoten, u8 Flags (Bits 0-6 Anzahl Nachfolger, 0x80 = hier keine Autos erzeugen), Knoten x (s16 X, s16 Hoehe, s16 Y),
     u16 Nachfolger-Spuren. Typ-5-Block: u8 Anzahl, 0, Paare (u16 Knoten, u16 Spur). Rechtsverkehr, Gegenspur ~94 Einheiten.
   - Boden: Flaechen im ersten Geometrieblock mit Materialbits 12-13 (1 Strasse, 2 Gelaende, 3 Wasser);
     die erste passende Flaeche bestimmt die Hoehe.
   - Gebaeude-Kollision: Dachflaeche (Typ 4) in Dachhoehe, ~7 Einheiten groesser als die sichtbare Wand.
   - Die ganze Stadt darf verschoben werden (alle Verweise sind relativ zur Kartenbasis). Fuer Bauarbeiten
     wird sie ans ROM-Ende kopiert; dahinter liegen erweiterbare Flaechen-/Wandtabellen und ein Bau-Speicher. */
(function (global) {
'use strict';
var G = global.D3S;
var WIN = 0x200000, META = WIN - 16, MAGIC = 0x42533344;          /* 'D3SB' */
var ORIG = { 0: [0x5F8800, 0x778000], 1: [0x4B0000, 0x5F8800] };
var MAT_NAMES = [$t('kein Boden'), $t('Strasse/Pflaster'), $t('Gelaende/Gras'), $t('Wasser')];
G.MAT_NAMES = MAT_NAMES;

function D() { return G.App.rom.data; }
function u16(o) { return G.u16(D(), o); }
function s16(o) { return G.u16(D(), o) << 16 >> 16; }
function u32(o) { return G.u32(D(), o); }
function p16(a, o, v) { v = Math.round(v); a[o] = v & 255; a[o + 1] = (v >> 8) & 255; }
function s8(v) { v = Math.max(-128, Math.min(127, Math.round(v))); return v & 255; }

/* ---------------------------------------------------------------- Vorbereitung */
function isPrepared(L) { return L.mapBase + WIN <= D().length && u32(L.mapBase + META) === MAGIC; }
function ctxOf(L) {
  if (!isPrepared(L)) return null;
  var b = L.mapBase;
  return { L: L, base: b, heap: b + u32(b + META + 4), F: b + u32(b + 0x1101C), T: b + u32(b + 0x11000),
    fEnd: b + u32(b + META + 8), tEnd: b + u32(b + META + 12), fMax: b + u32(b + 0x1101C) + 0x1FFF0, tMax: b + u32(b + 0x11000) + 0xFFF0, end: b + META };
}
function saveMeta(c) { var d = D(), m = c.base + META; G.putU32(d, m, MAGIC); G.putU32(d, m + 4, c.heap - c.base); G.putU32(d, m + 8, c.fEnd - c.base); G.putU32(d, m + 12, c.tEnd - c.base); }

function scanTables(L) {
  var d = D(), b = L.mapBase, F = b + u32(b + 0x1101C), T = b + u32(b + 0x11000), fmax = 0, tmax = 0, cmax = 0;
  for (var row = 0; row < 128; row++) for (var col = 0; col < 128; col++) {
    var o = b + (row * 128 + col) * 3, v = d[o] | (d[o + 1] << 8) | (d[o + 2] << 16);
    if (!v) continue;
    var c = b + (v & 0xFFFFF) * 2, n = v >>> 20;
    for (var i = 0; i < n; i++) {
      var e = u16(c + 6 + 2 * i), t = e >> 10, bo = c + (e & 0x3FF) * 2;
      if (t === 4) for (var k = 0; k < d[bo]; k++) fmax = Math.max(fmax, u16(bo + 2 + 2 * k) * 2 + 30);
      if (t === 1) for (var k2 = 0; k2 < u16(bo); k2++) tmax = Math.max(tmax, u16(bo + 2 + 2 * k2) + 12);
      cmax = Math.max(cmax, bo + 64 - b);
    }
  }
  return { F: F, T: T, fSize: fmax, tSize: tmax, cellEnd: cmax };
}
/* Stadt ans ROM-Ende kopieren und Tabellen mit Reserve anlegen */
function prepare(L) {
  if (isPrepared(L)) return ctxOf(L);
  var r = G.App.rom, o = ORIG[L.id];
  var start = L.mapBase, end = (o && o[0] === start) ? o[1] : start + 0x180000;
  var size = end - start;
  var sc = scanTables(L);
  if (sc.fSize > 0x1F000 || sc.tSize > 0xF000) throw new Error($t('Tabellen zu gross fuer die Reserve.'));
  if (r.data.length < G.ROM_MAX) r.expandTo(G.ROM_MAX);
  var nb = (r.freeStart() + 0xFFFF) & ~0xFFFF;
  if (nb + WIN > r.data.length) throw new Error($t('Kein Platz fuer die Bau-Kopie der Stadt (16 MB voll).'));
  var d = r.data;
  d.copyWithin(nb, start, end);
  var Fn = nb + ((size + 0xFF) & ~0xFF), Tn = Fn + 0x20000, heap = Tn + 0x10000;
  if (heap + 0x10000 > nb + META) throw new Error($t('Stadt zu gross fuer das Bau-Fenster.'));
  d.copyWithin(Fn, sc.F, sc.F + sc.fSize);
  d.copyWithin(Tn, sc.T, sc.T + sc.tSize);
  G.putU32(d, nb + 0x1101C, Fn - nb); G.putU32(d, nb + 0x11000, Tn - nb);
  G.setPtr(L.tab, nb);
  var c = { L: L, base: nb, heap: heap, F: Fn, T: Tn, fEnd: Fn + sc.fSize, tEnd: Tn + sc.tSize };
  saveMeta(c);
  r.allocTop = Math.max(r.allocTop || 0, nb + WIN);
  G.logChange(L.name + $t(': Stadt fuer Bauarbeiten nach ') + G.hx(nb) + $t(' kopiert (Original bleibt unangetastet)'));
  G.invalidate();
  L.mapBase = nb;
  return ctxOf(L);
}
function alloc(c, n) {
  c.heap = (c.heap + 3) & ~3;
  var a = c.heap; c.heap += n;
  if (c.heap > c.end) throw new Error($t('Bau-Speicher der Stadt ist voll.'));
  saveMeta(c); return a;
}
G.cityIsPrepared = isPrepared; G.cityPrepare = prepare; G.cityCtx = ctxOf;

/* ---------------------------------------------------------------- Zellen */
var startsCache = null;
function starts(base) {
  if (startsCache && startsCache.base === base && startsCache.stamp === G.App.log.length) return startsCache.list;
  var d = D(), st = [];
  for (var i = 0; i < 16384; i++) {
    var o = base + i * 3, v = d[o] | (d[o + 1] << 8) | (d[o + 2] << 16);
    if (!v) continue;
    var c = base + (v & 0xFFFFF) * 2; st.push(c);
    for (var k = 0; k < (v >>> 20); k++) st.push(c + (u16(c + 6 + 2 * k) & 0x3FF) * 2);
  }
  st.sort(function (a, b) { return a - b; });
  startsCache = { base: base, list: st, stamp: G.App.log.length };
  return st;
}
function blockSize(base, t, o) {
  var d = D();
  if (t === 0) return 2 + 6 * d[o] + 12 * d[o + 1];
  if (t === 2) return 6 + 6 * d[o + 4] + 12 * d[o + 5];
  if (t === 4) return 2 + 2 * d[o];
  if (t === 1) return 2 + 2 * u16(o);
  if (t === 5) return 2 + 4 * u16(o);
  if (t === 3 && d[o + 8] >= 1 && d[o + 8] <= 16) return 10 + 14 * d[o + 8];
  var st = starts(base);
  for (var i = 0; i < st.length; i++) if (st[i] > o) return Math.min(st[i] - o, 512);
  return 64;
}
function cellVal(base, col, row) { var d = D(), o = base + (row * 128 + col) * 3; return d[o] | (d[o + 1] << 8) | (d[o + 2] << 16); }
function setCellVal(base, col, row, v) { var d = D(), o = base + (row * 128 + col) * 3; d[o] = v & 255; d[o + 1] = (v >> 8) & 255; d[o + 2] = (v >> 16) & 255; }
function readCell(base, col, row) {
  var v = cellVal(base, col, row);
  if (!v) return null;
  var c = base + (v & 0xFFFFF) * 2, n = v >>> 20, blocks = [], end = c + 6 + 2 * n;
  for (var i = 0; i < n; i++) {
    var e = u16(c + 6 + 2 * i), t = e >> 10, o = c + (e & 0x3FF) * 2, sz = blockSize(base, t, o);
    blocks.push({ t: t, bytes: D().slice(o, o + sz) });
    end = Math.max(end, o + sz);
  }
  return { hdr: [s16(c), s16(c + 2), u16(c + 4)], blocks: blocks, at: c, size: end - c };
}
function writeCell(c, col, row, hdr, blocks, old) {
  if (blocks.length > 15) throw new Error($t('Zelle ') + col + '/' + row + $t(': zu viele Eintraege.'));
  var head = (6 + 2 * blocks.length + 1) & ~1, size = head;
  blocks.forEach(function (b) { size += (b.bytes.length + 1) & ~1; });
  var blob = new Uint8Array(size), p = head;
  p16(blob, 0, hdr[0]); p16(blob, 2, hdr[1]); p16(blob, 4, Math.min(0xFFFF, hdr[2]));
  blocks.forEach(function (b, i) {
    if ((p >> 1) >= 0x400) throw new Error($t('Zelle ') + col + '/' + row + $t(' ist zu voll (max. ~2 KB Daten je Zelle).'));
    p16(blob, 6 + 2 * i, (b.t << 10) | (p >> 1));
    blob.set(b.bytes, p); p += (b.bytes.length + 1) & ~1;
  });
  var at;
  if (old && old.at >= c.base && size <= old.size && old.at + old.size <= c.end && isHeapCell(c, old.at)) at = old.at;
  else at = alloc(c, size + 2);
  if (at & 1) at++;
  D().set(blob, at);
  setCellVal(c.base, col, row, (blocks.length << 20) | ((at - c.base) >> 1));
  startsCache = null;
}
function isHeapCell(c, at) { var h0 = c.T + 0x10000; return at >= h0; }   /* nur eigene Bau-Zellen ueberschreiben */

/* ---------------------------------------------------------------- Geometrie */
function parseGeo(b) {
  var nv = b[0], nf = b[1], verts = [], faces = [];
  for (var i = 0; i < nv; i++) { var o = 2 + 6 * i; verts.push([(b[o] | (b[o + 1] << 8)) << 16 >> 16, (b[o + 2] | (b[o + 3] << 8)) << 16 >> 16, (b[o + 4] | (b[o + 5] << 8)) << 16 >> 16]); }
  var fb = 2 + 6 * nv;
  for (var f = 0; f < nf; f++) {
    var q = fb + 12 * f;
    faces.push({ i: [b[q], b[q + 1], b[q + 2], b[q + 3]], n: [b[q + 4] << 24 >> 24, b[q + 5] << 24 >> 24, b[q + 6] << 24 >> 24], n2: [b[q + 7] << 24 >> 24, b[q + 8] << 24 >> 24, b[q + 9] << 24 >> 24], tex: b[q + 10] | (b[q + 11] << 8) });
  }
  return { verts: verts, faces: faces };
}
function buildGeo(g) {
  if (g.verts.length > 255 || g.faces.length > 255) throw new Error($t('Geometrieblock zu gross (max. 255 Punkte/Flaechen).'));
  var b = new Uint8Array(2 + 6 * g.verts.length + 12 * g.faces.length), p = 2;
  b[0] = g.verts.length; b[1] = g.faces.length;
  g.verts.forEach(function (v) { p16(b, p, v[0]); p16(b, p + 2, v[1]); p16(b, p + 4, v[2]); p += 6; });
  g.faces.forEach(function (f) {
    b[p] = f.i[0]; b[p + 1] = f.i[1]; b[p + 2] = f.i[2]; b[p + 3] = f.i[3];
    var n2 = f.n2 || f.n;
    b[p + 4] = s8(f.n[0]); b[p + 5] = s8(f.n[1]); b[p + 6] = s8(f.n[2]); b[p + 7] = s8(n2[0]); b[p + 8] = s8(n2[1]); b[p + 9] = s8(n2[2]);
    p16(b, p + 10, f.tex); p += 12;
  });
  return b;
}
/* Flaeche mit eigenen Punkten an eine Geometrie anhaengen (vorn = hoechste Boden-Prioritaet) */
function addFace(g, pts, n, tex, front) {
  var idx = pts.map(function (v) {
    for (var k = 0; k < g.verts.length; k++) { var w = g.verts[k]; if (w[0] === v[0] && w[1] === v[1] && w[2] === v[2]) return k; }
    g.verts.push([v[0], v[1], v[2]]); return g.verts.length - 1;
  });
  while (idx.length < 4) idx.push(idx[idx.length - 1]);
  var f = { i: idx, n: n, n2: n, tex: tex };
  if (front) g.faces.unshift(f); else g.faces.push(f);
}
G.parseGeo = parseGeo; G.buildGeo = buildGeo;

/* ---------------------------------------------------------------- Hilfen */
function cellOf(x, y) { return [(x + 0x8000) >> 9, (0x8000 - y) >> 9]; }
function cellCenter(col, row) { return [col * 512 - 0x8000 + 256, 0x8000 - row * 512 - 256]; }
function norm2(dx, dy) { var L = Math.hypot(dx, dy) || 1; return [dx / L * 127, dy / L * 127]; }
function signedArea(p) { var a = 0; for (var i = 0; i < p.length; i++) { var q = p[(i + 1) % p.length]; a += p[i][0] * q[1] - q[0] * p[i][1]; } return a / 2; }
function clockwise(p) { return signedArea(p) < 0 ? p.slice() : p.slice().reverse(); }
function isConvex(p) {
  var s = 0;
  for (var i = 0; i < p.length; i++) {
    var a = p[i], b = p[(i + 1) % p.length], c = p[(i + 2) % p.length];
    var cr = (b[0] - a[0]) * (c[1] - b[1]) - (b[1] - a[1]) * (c[0] - b[0]);
    if (cr !== 0) { if (s === 0) s = Math.sign(cr); else if (Math.sign(cr) !== s) return false; }
  }
  return true;
}
function offsetPoly(poly, dist) {   /* Uhrzeigersinn; dist>0 nach aussen */
  var n = poly.length, out = [];
  for (var i = 0; i < n; i++) {
    var p0 = poly[(i + n - 1) % n], p1 = poly[i], p2 = poly[(i + 1) % n];
    var n1 = nrm(p0, p1), n2 = nrm(p1, p2), bx = n1[0] + n2[0], by = n1[1] + n2[1], bl = Math.hypot(bx, by) || 1;
    bx /= bl; by /= bl;
    var k = dist / Math.max(0.3, bx * n1[0] + by * n1[1]);
    out.push([Math.round(p1[0] + bx * k), Math.round(p1[1] + by * k)]);
  }
  return out;
  function nrm(a, b) { var dx = b[0] - a[0], dy = b[1] - a[1], L = Math.hypot(dx, dy) || 1; return [-dy / L, dx / L]; }
}
function cellsOfBox(x0, y0, x1, y1) {
  var a = cellOf(x0, y1), b = cellOf(x1, y0), out = [];
  for (var col = Math.max(0, a[0]); col <= Math.min(127, b[0]); col++) for (var row = Math.max(0, a[1]); row <= Math.min(127, b[1]); row++) out.push([col, row]);
  return out;
}

/* Zellaenderungen sammeln und am Ende geschlossen schreiben */
function Batch(c) { this.c = c; this.cells = {}; }
Batch.prototype.get = function (col, row) {
  var k = col + ',' + row;
  if (!this.cells[k]) {
    var rc = readCell(this.c.base, col, row), cc = cellCenter(col, row);
    this.cells[k] = { col: col, row: row, old: rc, hdr: rc ? rc.hdr.slice() : [cc[0], cc[1], 362], blocks: rc ? rc.blocks.map(function (b) { return { t: b.t, bytes: b.bytes }; }) : [], extraGeo: [], s4: [], s1: [], s5: [], grow: [] };
  }
  return this.cells[k];
};
Batch.prototype.geo = function (cl) {   /* Geometrie aus Eintrag 0 (anlegen, falls noetig) */
  if (!cl.g) {
    var gi = cl.blocks.findIndex(function (b) { return b.t === 0; });
    if (gi >= 0) { cl.g = parseGeo(cl.blocks[gi].bytes); cl.gi = gi; }
    else { cl.g = { verts: [], faces: [] }; cl.gi = -1; }
  }
  return cl.g;
};
Batch.prototype.commit = function () {
  var c = this.c, self = this;
  Object.keys(this.cells).forEach(function (k) {
    var cl = self.cells[k], blocks = cl.blocks;
    var g0 = null, extra = [];
    if (cl.g) {
      /* Eintrag-0-Geometrie; laeuft sie ueber, zusaetzliche Bloecke */
      var main = { verts: cl.g.verts, faces: cl.g.faces };
      if (main.verts.length > 255 || main.faces.length > 255) {
        var keep = { verts: [], faces: [] };
        var rest = { verts: [], faces: [] };
        main.faces.forEach(function (f, i) {
          var tgt = (keep.faces.length < 200 && keep.verts.length < 240) ? keep : rest;
          if (tgt === rest && rest.faces.length >= 250) { extra.push(buildGeo(rest)); rest = { verts: [], faces: [] }; tgt = rest; }
          addFace(tgt, f.i.map(function (x) { return main.verts[x]; }), f.n, f.tex, false);
        });
        main = keep;
        if (rest.faces.length) extra.push(buildGeo(rest));
      }
      g0 = buildGeo(main);
    }
    var t4 = [], t1 = [], t5 = [], others = [];
    blocks.forEach(function (b, i) {
      if (cl.g && i === cl.gi) return;
      if (b.t === 4) { for (var q = 0; q < b.bytes[0]; q++) t4.push(b.bytes[2 + 2 * q] | (b.bytes[3 + 2 * q] << 8)); }
      else if (b.t === 1) { var n = b.bytes[0] | (b.bytes[1] << 8); for (var q2 = 0; q2 < n; q2++) t1.push(b.bytes[2 + 2 * q2] | (b.bytes[3 + 2 * q2] << 8)); }
      else if (b.t === 5 && cl.s5.length) { for (var q3 = 0; q3 < b.bytes[0]; q3++) t5.push([b.bytes[2 + 4 * q3] | (b.bytes[3 + 4 * q3] << 8), b.bytes[4 + 4 * q3] | (b.bytes[5 + 4 * q3] << 8)]); }
      else others.push(b);
    });
    if (cl.s5.length) {
      t5 = t5.concat(cl.s5).slice(0, 255);
      var b5 = new Uint8Array(2 + 4 * t5.length); b5[0] = t5.length;
      t5.forEach(function (x, i) { p16(b5, 2 + 4 * i, x[0]); p16(b5, 4 + 4 * i, x[1]); });
      others.push({ t: 5, bytes: b5 });
    }
    t4 = t4.concat(cl.s4).filter(function (x) { return cl.rm4 ? cl.rm4.indexOf(x) < 0 : true; });
    t1 = t1.concat(cl.s1).filter(function (x) { return cl.rm1 ? cl.rm1.indexOf(x) < 0 : true; });
    var out = [];
    var geoFirst = g0 ? [{ t: 0, bytes: g0 }] : others.filter(function (b) { return b.t === 0; }).slice(0, 1);
    if (!geoFirst.length) geoFirst = [{ t: 0, bytes: buildGeo({ verts: [], faces: [] }) }];
    out.push(geoFirst[0]);
    if (t4.length) { var b4 = new Uint8Array(2 + 2 * t4.length); b4[0] = Math.min(255, t4.length); t4.slice(0, 255).forEach(function (x, i) { p16(b4, 2 + 2 * i, x); }); out.push({ t: 4, bytes: b4 }); }
    others.forEach(function (b) { if (b !== geoFirst[0]) out.push(b); });
    extra.concat(cl.extraGeo).forEach(function (b) { out.push({ t: 0, bytes: b }); });
    if (t1.length) { var b1 = new Uint8Array(2 + 2 * t1.length); p16(b1, 0, t1.length); t1.forEach(function (x, i) { p16(b1, 2 + 2 * i, x); }); out.push({ t: 1, bytes: b1 }); }
    /* Mittelpunkt/Radius fuer das Sichtbarkeits-Culling */
    var cx = cl.hdr[0], cy = cl.hdr[1], rad = cl.hdr[2] || 256;
    out.forEach(function (b) {
      if (b.t !== 0) return;
      var gg = parseGeo(b.bytes);
      gg.verts.forEach(function (v) { rad = Math.max(rad, Math.hypot(v[0] - cx, v[2] - cy) + Math.abs(v[1]) / 2); });
    });
    writeCell(c, cl.col, cl.row, [cx, cy, Math.ceil(rad)], out, cl.old);
  });
  saveMeta(c);
  G.invalidate();
};

function addSurface(c, quad, h, flags) {   /* quad: 4 Punkte gegen den Uhrzeigersinn, h Zahl oder Array */
  c.fEnd = (c.fEnd + 1) & ~1;
  if (c.fEnd + 30 > c.fMax) throw new Error($t('Flaechentabelle voll.'));
  var d = D(), a = c.fEnd;
  quad.forEach(function (p, i) { var hh = Array.isArray(h) ? h[i] : h; p16(d, a + 6 * i, p[0]); p16(d, a + 6 * i + 2, hh); p16(d, a + 6 * i + 4, p[1]); });
  p16(d, a + 24, 0); p16(d, a + 26, 0); p16(d, a + 28, flags || 0);
  c.fEnd += 30;
  return (a - c.F) >> 1;
}
function addOccluder(c, a, b, h) {
  if (c.tEnd + 12 > c.tMax) throw new Error($t('Wandtabelle voll.'));
  var d = D(), o = c.tEnd, n = norm2(b[1] - a[1], -(b[0] - a[0]));
  p16(d, o, a[0]); p16(d, o + 2, a[1]); p16(d, o + 4, b[0]); p16(d, o + 6, b[1]); p16(d, o + 8, h);
  d[o + 10] = s8(n[0]); d[o + 11] = s8(n[1]);
  c.tEnd += 12;
  return o - c.T;
}

/* ---------------------------------------------------------------- Verkehr (KI-Spuren) */
var LMAGIC = 0x454E414C;   /* 'LANE' vor einer eigenen Kopie der Spurtabelle */
function laneBase(c) { return c.base + u32(c.base + 0x11064); }
function readLanes(c) {
  var d = D(), R = laneBase(c), n = u16(R), out = [];
  for (var i = 0; i < n; i++) {
    var o = R + 2 * u16(R + 2 * i), k = d[o], f = d[o + 1], nodes = [], succ = [];
    for (var j = 0; j < k; j++) nodes.push([s16(o + 2 + 6 * j), s16(o + 4 + 6 * j), s16(o + 6 + 6 * j)]);
    for (var q = 0; q < (f & 0x7F); q++) succ.push(u16(o + 2 + 6 * k + 2 * q));
    out.push({ flags: f & 0x80, nodes: nodes, succ: succ });
  }
  return out;
}
function writeLanes(c, lanes) {
  var n = lanes.length, hw = n, offs = [], recs = [];
  lanes.forEach(function (l) {
    if (l.nodes.length > 255 || l.succ.length > 127) throw new Error($t('Spur zu lang.'));
    var b = new Uint8Array(2 + 6 * l.nodes.length + 2 * l.succ.length);
    b[0] = l.nodes.length; b[1] = l.flags | l.succ.length;
    l.nodes.forEach(function (v, j) { p16(b, 2 + 6 * j, v[0]); p16(b, 4 + 6 * j, v[1]); p16(b, 6 + 6 * j, v[2]); });
    l.succ.forEach(function (x, j) { p16(b, 2 + 6 * l.nodes.length + 2 * j, x); });
    if (hw > 0xFFFF) throw new Error($t('Spurtabelle voll (max. 128 KB).'));
    offs.push(hw); recs.push(b); hw += b.length >> 1;
  });
  var size = hw * 2, d = D(), R = laneBase(c);
  var own = R - 8 >= c.T + 0x10000 && u32(R - 4) === LMAGIC && u32(R - 8) >= size;
  if (!own) {
    var cap = 0x20000, a = alloc(c, cap + 8);
    G.putU32(d, a, cap); G.putU32(d, a + 4, LMAGIC); R = a + 8;
    G.putU32(d, c.base + 0x11064, R - c.base);
  }
  offs.forEach(function (o, i) { p16(d, R + 2 * i, o); d.set(recs[i], R + 2 * o); });
}
/* Zwei Gegenspuren entlang einer Strasse; verbindet sie mit Spuren, die in der Naehe enden/beginnen */
function addTraffic(c, B, pair, z) {
  var lanes = readLanes(c), base = lanes.length, NEAR = 200, linked = 0;
  function dist(a, b) { return Math.hypot(a[0] - b[0], a[2] - b[2]); }
  pair.forEach(function (nodes) { lanes.push({ flags: 0, nodes: nodes, succ: [] }); });
  pair.forEach(function (nodes, k) {
    var id = base + k, me = lanes[id], first = nodes[0], last = nodes[nodes.length - 1], cand = [];
    for (var i = 0; i < base; i++) { var l = lanes[i]; if (l.nodes.length && dist(l.nodes[0], last) < NEAR) cand.push([dist(l.nodes[0], last), i]); }
    cand.sort(function (a, b) { return a[0] - b[0]; });
    me.succ = cand.slice(0, 2).map(function (x) { return x[1]; });
    me.succ.push(base + 1 - k);                        /* Wenden auf die Gegenspur */
    linked += cand.length ? 1 : 0;
    for (var i2 = 0; i2 < base; i2++) {
      var l2 = lanes[i2];
      if (l2.nodes.length && l2.succ.length < 3 && dist(l2.nodes[l2.nodes.length - 1], first) < NEAR) { l2.succ.push(id); linked++; }
    }
    var seen = {};
    nodes.forEach(function (v, j) {
      if (j === nodes.length - 1) return;             /* nie am letzten Knoten: das Spiel liefe ueber das Spurende hinaus */
      var cc = cellOf(v[0], v[2]), key = cc.join(',');
      if (seen[key] || cc[0] < 0 || cc[0] > 127 || cc[1] < 0 || cc[1] > 127) return;
      seen[key] = 1;
      var cl = B.get(cc[0], cc[1]); B.geo(cl); cl.s5.push([j, id]);
    });
  });
  writeLanes(c, lanes);
  return { ids: [base, base + 1], linked: linked };
}
function roadLanes(x0, y0, x1, y1, axis, hAt) {
  var W = axis === 'x' ? y1 - y0 : x1 - x0, len = axis === 'x' ? x1 - x0 : y1 - y0;
  if (W < 64 || len < 64) return null;
  var off = Math.max(24, Math.min(48, W / 4)), mid = axis === 'x' ? (y0 + y1) / 2 : (x0 + x1) / 2;
  var n = Math.max(2, Math.ceil((len - 16) / 240) + 1), a = [], b = [];
  for (var i = 0; i < n; i++) {
    var t = (axis === 'x' ? x0 : y0) + 8 + (len - 16) * i / (n - 1);
    /* Rechtsverkehr: in Fahrtrichtung +X faehrt man suedlich (-Y), in Richtung +Y oestlich (+X) */
    if (axis === 'x') { a.push([Math.round(t), 0, Math.round(mid - off)]); b.unshift([Math.round(t), 0, Math.round(mid + off)]); }
    else { a.push([Math.round(mid + off), 0, Math.round(t)]); b.unshift([Math.round(mid - off), 0, Math.round(t)]); }
  }
  [a, b].forEach(function (l) { l.forEach(function (v) { v[1] = hAt(v[0], v[2]); }); });
  return [a, b];
}
G.cityLanes = function (L) { var c = ctxOf(L) || { base: L.mapBase }; return readLanes(c); };

/* ---------------------------------------------------------------- Gebaeude */
/* opts: h, storey, seg, wallTex, roofTex, collision(bool), occluders(bool) */
function buildBuilding(L, poly, opts) {
  if (poly.length < 3) throw new Error($t('Mindestens 3 Eckpunkte.'));
  poly = clockwise(poly.map(function (p) { return [Math.round(p[0]), Math.round(p[1])]; }));
  if (!isConvex(poly)) throw new Error($t('Grundriss muss konvex sein (keine einspringenden Ecken). Komplexe Formen aus mehreren Gebaeuden zusammensetzen.'));
  var c = prepare(L), B = new Batch(c);
  var h = Math.max(16, opts.h | 0), storey = Math.max(32, opts.storey || 208), seg = Math.max(32, opts.seg || 192);
  var levels = [0]; while (levels[levels.length - 1] + storey < h - 40) levels.push(levels[levels.length - 1] + storey); levels.push(h);
  var wallTex = 0x200 | (opts.wallDesc & 0x1FF), roofTex = 0x200 | (opts.roofDesc & 0x1FF);
  var n = poly.length;
  for (var i = 0; i < n; i++) {
    var a = poly[i], b = poly[(i + 1) % n], len = Math.hypot(b[0] - a[0], b[1] - a[1]), k = Math.max(1, Math.round(len / seg));
    var nn = norm2(-(b[1] - a[1]), b[0] - a[0]);          /* aussen bei Uhrzeigersinn */
    for (var j = 0; j < k; j++) {
      var x0 = Math.round(a[0] + (b[0] - a[0]) * j / k), y0 = Math.round(a[1] + (b[1] - a[1]) * j / k);
      var x1 = Math.round(a[0] + (b[0] - a[0]) * (j + 1) / k), y1 = Math.round(a[1] + (b[1] - a[1]) * (j + 1) / k);
      var cc = cellOf((x0 + x1) >> 1, (y0 + y1) >> 1), cl = B.get(cc[0], cc[1]), g = B.geo(cl);
      for (var li = 0; li < levels.length - 1; li++) {
        var lo = levels[li], hi = levels[li + 1];
        addFace(g, [[x0, hi, y0], [x1, hi, y1], [x1, lo, y1], [x0, lo, y0]], [nn[0], 0, nn[1]], wallTex, false);
      }
    }
  }
  /* Dach (fuer Draufsicht und Blick von oben) */
  for (var q = 1; q < n - 1; q += 2) {
    var ids = [0, q, q + 1, Math.min(q + 2, n - 1)], pts = ids.map(function (x) { return poly[x]; });
    var ccx = (pts[0][0] + pts[2][0]) >> 1, ccy = (pts[0][1] + pts[2][1]) >> 1, cr = cellOf(ccx, ccy), clr = B.get(cr[0], cr[1]);
    addFace(B.geo(clr), [pts[3], pts[2], pts[1], pts[0]].map(function (p) { return [p[0], h, p[1]]; }), [0, 127, 0], roofTex, false);
  }
  var xs = poly.map(function (p) { return p[0]; }), ys = poly.map(function (p) { return p[1]; });
  var box = [Math.min.apply(null, xs) - 16, Math.min.apply(null, ys) - 16, Math.max.apply(null, xs) + 16, Math.max.apply(null, ys) + 16];
  var cellsHit = cellsOfBox(box[0], box[1], box[2], box[3]);
  if (opts.collision !== false) {
    var sp = offsetPoly(poly, 7), ccw = sp.slice().reverse(), sids = [];
    for (var s = 1; s < ccw.length - 1; s += 2) sids.push(addSurface(c, [ccw[0], ccw[s], ccw[s + 1], ccw[Math.min(s + 2, ccw.length - 1)]], h, 0));
    cellsHit.forEach(function (cr2) { var cl2 = B.get(cr2[0], cr2[1]); cl2.s4 = cl2.s4.concat(sids); });
  }
  var small = Math.min(box[2] - box[0], box[3] - box[1]) < 128;
  if (opts.occluders !== false && !small) {
    var ip = offsetPoly(poly, -26).slice().reverse(), oids = [];
    for (var w = 0; w < ip.length; w++) oids.push(addOccluder(c, ip[w], ip[(w + 1) % ip.length], Math.round(h * 0.8)));
    cellsHit.forEach(function (cr3) { var cl3 = B.get(cr3[0], cr3[1]); cl3.s1 = cl3.s1.concat(oids); });
  }
  B.commit();
  G.logChange(L.name + $t(': Gebaeude gebaut (') + n + $t(' Ecken, Hoehe ') + h + $t(', Zellen ') + cellsHit.map(function (x) { return x.join('/'); }).join(' ') + ')');
  return cellsHit.length;
}

/* ---------------------------------------------------------------- Boden / Strasse / Rampe / Bruecke */
/* rect [x0,y0,x1,y1]; heights: {h0,h1} entlang 'axis' ('x' oder 'y') fuer Rampen; material 1-3; desc; tile */
function buildGround(L, rect, opts) {
  var c = prepare(L), B = new Batch(c);
  var x0 = Math.min(rect[0], rect[2]), x1 = Math.max(rect[0], rect[2]), y0 = Math.min(rect[1], rect[3]), y1 = Math.max(rect[1], rect[3]);
  if (x1 - x0 < 8 || y1 - y0 < 8) throw new Error($t('Flaeche zu klein.'));
  var tile = Math.max(32, opts.tile || 128), mat = opts.material & 3;
  var tex = (mat << 12) | 0x400 | 0x200 | (opts.desc & 0x1FF);
  var h0 = opts.h0 | 0, h1 = opts.h1 === undefined ? h0 : opts.h1 | 0, axis = opts.axis || 'y';
  function hAt(x, y) { var t = axis === 'x' ? (x - x0) / (x1 - x0) : (y - y0) / (y1 - y0); return Math.round(h0 + (h1 - h0) * t); }
  var nx = Math.ceil((x1 - x0) / tile), ny = Math.ceil((y1 - y0) / tile), faces = 0;
  for (var i = 0; i < nx; i++) for (var j = 0; j < ny; j++) {
    var ax = Math.round(x0 + (x1 - x0) * i / nx), bx = Math.round(x0 + (x1 - x0) * (i + 1) / nx);
    var ay = Math.round(y0 + (y1 - y0) * j / ny), by = Math.round(y0 + (y1 - y0) * (j + 1) / ny);
    var cc = cellOf((ax + bx) >> 1, (ay + by) >> 1), cl = B.get(cc[0], cc[1]);
    var pts = [[bx, hAt(bx, by), by], [ax, hAt(ax, by), by], [ax, hAt(ax, ay), ay], [bx, hAt(bx, ay), ay]];
    /* Normale einer Rampe */
    var dh = axis === 'x' ? (h1 - h0) / (x1 - x0) : (h1 - h0) / (y1 - y0), L2 = Math.hypot(dh, 1);
    var nrm = axis === 'x' ? [-dh / L2 * 127, 127 / L2, 0] : [0, 127 / L2, -dh / L2 * 127];
    addFace(B.geo(cl), pts, nrm, tex, true);
    faces++;
  }
  /* erhoehte Bruecken/Rampen brauchen zusaetzlich eine Flaeche, damit Autos/Figuren nicht durchfallen */
  if (opts.surface) {
    var sid = addSurface(c, [[x0, y0], [x1, y0], [x1, y1], [x0, y1]], [hAt(x0, y0), hAt(x1, y0), hAt(x1, y1), hAt(x0, y1)], 0);
    cellsOfBox(x0, y0, x1, y1).forEach(function (cr) { var cl2 = B.get(cr[0], cr[1]); B.geo(cl2); cl2.s4.push(sid); });
  }
  var tr = null;
  if (opts.traffic && mat === 1) {
    var tAxis = opts.trafficAxis || (h1 !== h0 ? axis : (x1 - x0 >= y1 - y0 ? 'x' : 'y'));
    var pair = roadLanes(x0, y0, x1, y1, tAxis, hAt);
    if (pair) tr = addTraffic(c, B, pair);
  }
  B.commit();
  if (tr) G.logChange(L.name + $t(': Verkehr fuer neue Strasse (Spuren ') + tr.ids.join('/') + ', ' + tr.linked + $t(' Verbindungen zum Strassennetz)'));
  G.logChange(L.name + ': ' + MAT_NAMES[mat] + $t(' gebaut (') + (x1 - x0) + 'x' + (y1 - y0) + ', ' + faces + $t(' Kacheln, Hoehe ') + h0 + (h1 !== h0 ? '-' + h1 : '') + ')');
  opts.trafficResult = tr;
  return faces;
}

/* ---------------------------------------------------------------- Flaechen einzeln bearbeiten */
function editCellGeo(L, col, row, fn, label) {
  var c = prepare(L), B = new Batch(c), cl = B.get(col, row);
  if (!cl.old) throw new Error($t('Leere Zelle.'));
  var g = B.geo(cl);
  fn(g, cl);
  B.commit();
  G.logChange(L.name + $t(' Zelle ') + col + '/' + row + ': ' + label);
}
function deleteFaces(L, col, row, faceIdx) {
  editCellGeo(L, col, row, function (g) {
    var set = {}; faceIdx.forEach(function (i) { set[i] = 1; });
    g.faces = g.faces.filter(function (f, i) { return !set[i]; });
    /* unbenutzte Punkte entfernen */
    var used = {}, map = {}, nv = [];
    g.faces.forEach(function (f) { f.i.forEach(function (x) { used[x] = 1; }); });
    g.verts.forEach(function (v, i) { if (used[i]) { map[i] = nv.length; nv.push(v); } });
    g.faces.forEach(function (f) { f.i = f.i.map(function (x) { return map[x]; }); });
    g.verts = nv;
  }, faceIdx.length + $t(' Flaeche(n) geloescht'));
}
function setFaceTex(L, col, row, faceIdx, desc, mat) {
  editCellGeo(L, col, row, function (g) {
    faceIdx.forEach(function (i) {
      var f = g.faces[i]; if (!f) return;
      var t = f.tex;
      if (desc !== null && desc !== undefined) t = (t & ~0x1FF) | 0x200 | (desc & 0x1FF);
      if (mat !== null && mat !== undefined) t = (t & ~0x3000) | ((mat & 3) << 12) | (mat ? 0x400 : 0);
      f.tex = t;
    });
  }, faceIdx.length + $t(' Flaeche(n) Textur/Material'));
}
function moveFaces(L, col, row, faceIdx, dx, dy, dh) {
  editCellGeo(L, col, row, function (g) {
    var vs = {}; faceIdx.forEach(function (i) { var f = g.faces[i]; if (f) f.i.forEach(function (x) { vs[x] = 1; }); });
    /* geteilte Punkte duplizieren, damit andere Flaechen bleiben */
    var shared = {};
    g.faces.forEach(function (f, i) { if (faceIdx.indexOf(i) < 0) f.i.forEach(function (x) { if (vs[x]) shared[x] = 1; }); });
    var remap = {};
    Object.keys(vs).forEach(function (k) {
      var x = +k, v = g.verts[x], nvv = [v[0] + dx, v[1] + dh, v[2] + dy];
      if (shared[x]) { g.verts.push(nvv); remap[x] = g.verts.length - 1; } else g.verts[x] = nvv;
    });
    faceIdx.forEach(function (i) { var f = g.faces[i]; if (f) f.i = f.i.map(function (x) { return remap[x] !== undefined ? remap[x] : x; }); });
  }, faceIdx.length + $t(' Flaeche(n) verschoben (') + dx + ',' + dy + $t(', Hoehe ') + dh + ')');
}
function clearCollision(L, col, row, which) {
  var c = prepare(L), B = new Batch(c), cl = B.get(col, row);
  B.geo(cl);
  cl.blocks = cl.blocks.filter(function (b) { return !((which === 'all' || which === 4) && b.t === 4) && !((which === 'all' || which === 1) && b.t === 1); });
  cl.gi = cl.blocks.findIndex(function (b) { return b.t === 0; });
  B.commit();
  G.logChange(L.name + $t(' Zelle ') + col + '/' + row + $t(': Kollision/Verdeckung entfernt (') + which + ')');
}

G.buildBuilding = buildBuilding; G.buildGround = buildGround;
G.cellDeleteFaces = deleteFaces; G.cellSetFaceTex = setFaceTex; G.cellMoveFaces = moveFaces; G.cellClearCollision = clearCollision;
G.cityReadCell = function (L, col, row) { return readCell(L.mapBase, col, row); };
})(window);
