/* Driv3r Advance Studio - tab_cutscenes.js : JPEG-Standbilder und Bildfolgen (Storyboards) */
(function (global) {
'use strict';
var G = global.D3S, el = G.el;
var state = { mode: 'story', story: 0, jpg: 0, lang: 2 };
G.cutsceneFocus = state;
var thumbCache = {};

function thumb(off, cb) {
  var d = G.App.rom.data, info = G.jpegScan(d, off);
  var key = off + ':' + (info ? info.size : 0) + ':' + (info ? d[off + info.size - 3] : 0);
  if (thumbCache[key]) { cb(thumbCache[key]); return; }
  if (!info) return;
  G.decodeJpeg(G.toStdJpeg(d, info)).then(function (r) { thumbCache[key] = r; cb(r); }).catch(function () { });
}
function jpgCanvas(off) {
  var c = el('canvas', { width: 240, height: 160 });
  var cx = c.getContext('2d'); cx.fillStyle = '#222'; cx.fillRect(0, 0, 240, 160);
  if (off >= 0) thumb(off, function (r) { cx.drawImage(r.canvas, 0, 0); });
  return c;
}

async function importJpeg(off) {
  var f = await G.pickFile('image/*');
  if (!f) return;
  try {
    G.busy($t('Bild wird kodiert ...')); await G.yieldUI();
    var im = await G.readImageFile(f);
    if (im.w !== 240 || im.h !== 160) im = G.resizeRGBA(im, 240, 160);
    var d = G.App.rom.data, info = G.jpegScan(d, off);
    var q = G.estimateQuality(info.quant[0]);
    var enc = G.encodeJpeg(im.rgba, 240, 160, { quality: Math.max(q, 70) });
    /* ggf. Qualitaet senken, bis es an den alten Platz passt */
    var qq = Math.max(q, 70);
    while (enc.length > info.size && qq > 40) { qq -= 5; enc = G.encodeJpeg(im.rgba, 240, 160, { quality: qq }); }
    if (enc.length > info.size) enc = G.encodeJpeg(im.rgba, 240, 160, { quality: Math.max(q, 70) });
    var res = G.replaceBlob(off, info.size, enc, { refs: G.findRefs(off), noRefsOk: false });
    G.logChange($t('Zwischensequenz-Bild ') + G.hx(off) + $t(' ersetzt (Q') + qq + ', ' + enc.length + $t(' Byte') + (res.moved ? $t(', verschoben nach ') + G.hx(res.off) : '') + ')');
    G.invalidate(['jpegs']);
    G.busy(false); G.toast($t('Bild ersetzt') + (res.moved ? $t(' (verschoben, ') + res.refs + $t(' Verweise angepasst)') : ''));
    G.refreshTab();
  } catch (e) { G.busy(false); G.toast($t('Import fehlgeschlagen: ') + e.message, 'err'); console.error(e); }
}
async function exportJpegPng(off, name) {
  var d = G.App.rom.data, info = G.jpegScan(d, off);
  var r = await G.decodeJpeg(G.toStdJpeg(d, info));
  G.download(name || ('zwischensequenz_' + G.hex(off, 6) + '.png'), G.pngWriteRGBA(r.rgba, r.w, r.h), 'image/png');
}
G.exportJpegPng = exportJpegPng;

G.registerTab({
  id: 'cutscenes', label: $t('Zwischensequenzen'), icon: '▶', group: $t('Grafik'), needsRom: true,
  render: function (v) {
    v.appendChild(el('h2', { text: $t('Zwischensequenzen') }));
    v.appendChild(el('p', { class: 'lead', html: $t('Die Story wird als Folge von Standbildern (240x160 JPEG) mit Untertiteln in 5 Sprachen erzaehlt. ') +
      $t('Bilder austauschen, Texte aendern, Bilder einer anderen Folge zuordnen. Neue Bilder werden automatisch passend kodiert.') }));
    v.appendChild(el('div', { class: 'toolbar' }, [
      G.button($t('Bildfolgen'), function () { state.mode = 'story'; G.refreshTab(); }, state.mode === 'story' ? 'on' : ''),
      G.button($t('Alle Bilder'), function () { state.mode = 'all'; G.refreshTab(); }, state.mode === 'all' ? 'on' : ''),
      el('span', { class: 'sep' }),
      G.button($t('Alle Bilder als ZIP (PNG)'), async function () {
        var jp = G.cached('jpegs', G.jpegCatalog), z = new G.ZipWriter(), d = G.App.rom.data;
        G.busy($t('Bilder werden dekodiert ...'));
        for (var i = 0; i < jp.length; i++) {
          var r = await G.decodeJpeg(G.toStdJpeg(d, jp[i]));
          z.add('zwischensequenz_' + G.hex(jp[i].off, 6) + '.png', G.pngWriteRGBA(r.rgba, r.w, r.h));
          if (i % 10 === 0) G.busyProgress(i / jp.length);
        }
        var zip = await z.buildAsync(); G.busy(false); G.download('driv3r_zwischensequenzen.zip', zip, 'application/zip');
      })
    ]));
    if (state.mode === 'all') renderAll(v); else renderStory(v);
  }
});

function renderAll(v) {
  var jp = G.cached('jpegs', G.jpegCatalog);
  var grid = el('div', { class: 'gridwrap', style: { '--cw': '250px' } });
  jp.forEach(function (info) {
    var c = jpgCanvas(info.off); c.style.width = '240px';
    grid.appendChild(el('div', { class: 'tile' }, [c,
      el('small', { text: G.hx(info.off) + ' - ' + info.size + $t(' Byte') }),
      el('div', { class: 'row tight', style: { justifyContent: 'center', marginTop: '4px' } }, [
        G.button('PNG', function () { exportJpegPng(info.off); }),
        G.button($t('Ersetzen ...'), function () { importJpeg(info.off); })
      ])]));
  });
  v.appendChild(grid);
}

function renderStory(v) {
  var sbs = G.storyboards(), tc = G.cached('texts', G.textCatalog);
  var split = el('div', { class: 'split' }), side = el('div', { class: 'side', style: { width: '220px' } }), main = el('div', { style: { flex: '1', minWidth: '0' } });
  var list = el('div', { class: 'list', style: { maxHeight: 'calc(100vh - 280px)' } });
  sbs.forEach(function (sb, i) {
    var first = sb.frames[0] && sb.frames[0].txt[0] >= 0 ? G.readStr(sb.frames[0].txt[0]) : '';
    list.appendChild(el('div', { class: 'it' + (i === state.story ? ' sel' : ''), onclick: function () { state.story = i; G.refreshTab(); } },
      [el('b', { text: String(i + 1) }), el('span', { class: 'grow', text: first || $t('(leer)') }), el('small', { text: sb.frames.length })]));
  });
  side.appendChild(list); split.appendChild(side); split.appendChild(main); v.appendChild(split);
  var sb = sbs[state.story];
  if (!sb) return;
  main.appendChild(el('div', { class: 'row', style: { marginBottom: '8px' } }, [
    el('b', { text: $t('Bildfolge ') + (state.story + 1) + ' - ' + sb.frames.length + $t(' Bilder') }),
    el('span', { class: 'spacer' }), el('span', { class: 'mut', text: $t('Sprache fuer Schnellbearbeitung:') }),
    G.select(G.K.LANGS.map(function (l, i) { return { value: i, label: l }; }), state.lang, function (x) { state.lang = +x; G.refreshTab(); })
  ]));
  var jp = G.cached('jpegs', G.jpegCatalog);
  sb.frames.forEach(function (f, fi) {
    var c = jpgCanvas(f.jpg);
    c.title = $t('Klicken: Bild ersetzen');
    c.onclick = function () { importJpeg(f.jpg); };
    var right = el('div');
    G.K.LANGS.forEach(function (lang, li) {
      var off = f.txt[li];
      if (off < 0) return;
      var cur = G.readStr(off);
      var ta = el('textarea', { rows: 2, style: { width: '100%', display: li === state.lang ? 'block' : 'none' } }, [cur]);
      var cnt = el('div', { class: 'txtcnt' });
      function upd() { cnt.textContent = ta.value.length + $t(' Zeichen (Platz: ') + cur.length + (G.findRefs(off).length ? $t(', laengere Texte werden verschoben') : '') + ')'; }
      ta.oninput = upd;
      ta.onchange = function () {
        try { G.writeText(off, ta.value, $t('Zwischensequenz ') + (state.story + 1) + '/' + (fi + 1) + ' ' + lang); G.toast($t('Text gespeichert.')); G.refreshTab(); }
        catch (e) { G.toast(e.message, 'err'); }
      };
      if (li === state.lang) { upd(); right.appendChild(el('div', { class: 'hint', text: lang + ':' })); right.appendChild(ta); right.appendChild(cnt); }
      else right.appendChild(el('div', { class: 'hint', text: lang + ': ' + cur.slice(0, 90) + (cur.length > 90 ? ' ...' : '') }));
    });
    /* Bild einer anderen Datei zuordnen */
    var sel = G.select(jp.map(function (j, k) { return { value: j.off, label: $t('Bild ') + (k + 1) + ' @' + G.hx(j.off) }; }), f.jpg, function (x) {
      G.setPtr(f.at, +x); G.logChange($t('Bildfolge ') + (state.story + 1) + $t(' Bild ') + (fi + 1) + ' -> ' + G.hx(+x)); G.refreshTab();
    });
    right.appendChild(el('div', { class: 'row tight', style: { marginTop: '6px' } }, [
      el('span', { class: 'mut', text: $t('Bild:') }), sel,
      G.button('PNG', function () { exportJpegPng(f.jpg); }), G.button($t('Ersetzen ...'), function () { importJpeg(f.jpg); })
    ]));
    main.appendChild(el('div', { class: 'storyframe' }, [el('div', {}, [c, el('small', { class: 'mut', text: $t('Bild ') + (fi + 1) })]), right]));
  });
}

G.cutscenesExportAll = async function (zip) {
  var jp = G.cached('jpegs', G.jpegCatalog), d = G.App.rom.data;
  for (var i = 0; i < jp.length; i++) {
    var r = await G.decodeJpeg(G.toStdJpeg(d, jp[i]));
    zip.add('zwischensequenzen/zs_' + G.hex(jp[i].off, 6) + '.png', G.pngWriteRGBA(r.rgba, r.w, r.h));
    zip.add('zwischensequenzen/original_jpg/zs_' + G.hex(jp[i].off, 6) + '.jpg', G.toStdJpeg(d, jp[i]));
  }
  return jp.length;
};
/* Import: PNG wird neu kodiert, JPG (Standard) wird direkt uebernommen */
G.cutscenesImportFile = async function (name, bytes, report, origBytes) {
  var m = /zs_([0-9A-F]{6})\.(png|jpe?g)$/i.exec(name);
  if (!m) return false;
  var off = parseInt(m[1], 16), d = G.App.rom.data, info = G.jpegScan(d, off);
  if (!info) { report.skip.push(name + $t(': kein Bild an dieser Adresse')); return true; }
  if (origBytes && origBytes.get('zwischensequenzen/zs_' + m[1] + '.png') && G.bytesEqual(origBytes.get('zwischensequenzen/zs_' + m[1] + '.png'), bytes)) return true;
  var enc;
  if (/jpe?g/i.test(m[2])) {
    if (/original_jpg/.test(name)) { var std = G.toStdJpeg(d, info); if (G.bytesEqual(std, bytes)) return true; }
    enc = bytes.slice(); var sc = G.jpegScan(enc, 0); if (!sc) { report.skip.push(name + $t(': ungueltiges JPEG')); return true; }
    if (sc.w !== 240 || sc.h !== 160) { report.skip.push(name + $t(': muss 240x160 sein')); return true; }
    enc[sc.sos + 1] = 0x1A;
  } else {
    var png = G.pngRead(bytes);
    var cur = await G.decodeJpeg(G.toStdJpeg(d, info));
    var diff = 0; for (var i = 0; i < cur.rgba.length; i += 4) diff += Math.abs(cur.rgba[i] - png.rgba[i]);
    if (diff / (240 * 160) < 1) return true;   /* unveraendert */
    var rgba = png.w === 240 && png.h === 160 ? png.rgba : G.resizeRGBA(png, 240, 160).rgba;
    enc = G.encodeJpeg(rgba, 240, 160, { quality: Math.max(70, G.estimateQuality(info.quant[0])) });
  }
  var res = G.replaceBlob(off, info.size, enc, {});
  report.done.push($t('Zwischensequenz ') + G.hx(off) + (res.moved ? $t(' (verschoben)') : ''));
  G.invalidate(['jpegs']);
  return true;
};
})(window);
