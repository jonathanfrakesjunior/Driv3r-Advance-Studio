/* Driv3r Advance Studio - tab_images.js : Vollbilder, Menue-3D-Texturen, Stadt-Texturatlanten (VC) */
(function (global) {
'use strict';
var G = global.D3S, el = G.el;
var state = { sel: 0, pal: null, zoom: 2, dither: false, overlay: false };

function idxRange(idx) { var lo = 255, hi = 0; for (var i = 0; i < idx.length; i++) { if (idx[i] < lo) lo = idx[i]; if (idx[i] > hi) hi = idx[i]; } return [lo, hi]; }

G.registerTab({
  id: 'images', label: $t('Bilder & Texturen'), icon: '▨', group: $t('Grafik'), needsRom: true,
  hint: $t('Titel, Menue, Menue-3D-Texturen und Stadt-Texturatlanten'),
  render: function (v) {
    var cat = G.cached('images', G.imageCatalog);
    v.appendChild(el('h2', { text: $t('Bilder & Texturen') }));
    v.appendChild(el('p', { class: 'lead', html: $t('Vollbilder (240x160), Menue-3D-Texturen und die Texturatlanten der Staedte. ') +
      $t('Export als indiziertes PNG mit Spielpalette; Import aus PNG/JPG/BMP. Indizierte PNGs behalten ihre Farbindizes, ') +
      $t('alles andere wird der Palette zugeordnet. Mit "Neue Farben" berechnet das Studio eine eigene Palette fuer das Bild.') }));
    var split = el('div', { class: 'split' }), side = el('div', { class: 'side' }), main = el('div', { style: { flex: '1', minWidth: '0' } });
    split.appendChild(side); split.appendChild(main); v.appendChild(split);
    var list = el('div', { class: 'list', style: { maxHeight: 'calc(100vh - 250px)' } }), lastGroup = '';
    cat.forEach(function (it, i) {
      if (it.group !== lastGroup) { list.appendChild(el('div', { class: 'navgroup', text: it.group })); lastGroup = it.group; }
      var row = el('div', { class: 'it' + (i === state.sel ? ' sel' : ''), onclick: function () { state.sel = i; state.pal = null; G.refreshTab(); } },
        [el('span', { class: 'grow', text: it.name }), el('small', { text: it.w + 'x' + it.h })]);
      list.appendChild(row);
    });
    side.appendChild(list);
    side.appendChild(el('div', { class: 'row', style: { marginTop: '8px' } }, [
      G.button($t('Alle als ZIP'), async function () {
        G.busy($t('Bilder werden exportiert ...')); await G.yieldUI();
        var z = new G.ZipWriter();
        cat.forEach(function (it) {
          var raw = G.vcDecode(G.App.rom.data, it.off).data, P = G.composePal(it.pals).bg;
          z.add(fileName(it), G.pngWriteIndexed(raw.subarray(0, it.w * it.h), it.w, it.h, P, false));
        });
        var zip = await z.buildAsync(); G.busy(false);
        G.download('driv3r_bilder.zip', zip, 'application/zip');
      })
    ]));
    var it = cat[state.sel];
    if (!it) { main.appendChild(el('div', { class: 'card', text: $t('Keine Bilder gefunden.') })); return; }
    renderDetail(main, it);
  }
});

function fileName(it) { return 'bild_' + it.id + '_' + G.hex(it.off, 6) + '_' + it.w + 'x' + it.h + '.png'; }

function renderDetail(main, it) {
  var d = G.App.rom.data, dec = G.vcDecode(d, it.off), raw = dec.data.subarray(0, it.w * it.h);
  var palFiles = G.cached('palfiles', G.paletteFiles);
  var palChoice = state.pal || it.pals;
  var P = G.composePal(palChoice).bg, rg = idxRange(raw);
  var cv = G.idxCanvas(raw, it.w, it.h, P, false);
  if (state.overlay && it.level !== undefined) drawDescriptors(cv, it);
  var zv = G.zoomView(cv, it.w > 240 ? 2 : 3);

  var palSel = G.select([{ value: it.pals.join(','), label: $t('Standard (') + it.pals.map(function (p) { return (palFiles.filter(function (f) { return f.off === p; })[0] || {}).name || G.hx(p); }).join(' + ') + ')' }]
    .concat(palFiles.map(function (f) { return { value: String(f.off), label: f.name }; })), palChoice.join(','), function (val) { state.pal = val.split(',').map(Number); G.refreshTab(); });

  main.appendChild(el('div', { class: 'toolbar' }, [
    el('b', { text: it.name }), el('span', { class: 'sep' }), el('span', { class: 'mut', text: $t('Palette') }), palSel, zv.ctl,
    it.level !== undefined ? el('label', { class: 'chk' }, [el('input', { type: 'checkbox', checked: state.overlay, onchange: function () { state.overlay = this.checked; G.refreshTab(); } }), $t('Textur-Rahmen')]) : null
  ]));
  main.appendChild(el('div', { class: 'infobar' }, [
    el('span', { html: $t('Adresse <b>') + G.hx(it.off) + '</b>' }), el('span', { html: $t('VC-Modus <b>') + dec.mode + '</b>' }),
    el('span', { html: $t('gepackt <b>') + dec.used.toLocaleString('de-DE') + $t('</b> / entpackt <b>') + dec.data.length.toLocaleString('de-DE') + $t('</b> Byte') }),
    el('span', { html: $t('benutzte Farbindizes <b>') + rg[0] + '-' + rg[1] + '</b>' })
  ]));
  main.appendChild(zv.wrap);

  var lo = rg[0], hi = rg[1];
  var opts = { keep: true, newColors: false, dither: false, allRange: false };
  var box = el('div', { class: 'card', style: { marginTop: '10px' } }, [
    el('h4', { text: $t('Export / Import') }),
    el('div', { class: 'row' }, [
      G.button($t('PNG exportieren'), function () { G.exportPNG(fileName(it), raw, it.w, it.h, P, false); }, 'primary'),
      G.button($t('Bild importieren ...'), function () { doImport(it, raw, P, lo, hi, opts, palChoice); }),
      el('label', { class: 'chk', title: $t('Fuer total neue Bilder: eine eigene Palette im erlaubten Indexbereich berechnen und in die Palettendatei schreiben') },
        [el('input', { type: 'checkbox', onchange: function () { opts.newColors = this.checked; } }), $t('Neue Farben erzeugen')]),
      el('label', { class: 'chk', title: $t('Standard: nur der Indexbereich, den das Original benutzt (andere Farben gehoeren oft zu anderen Grafiken)') },
        [el('input', { type: 'checkbox', onchange: function () { opts.allRange = this.checked; } }), $t('alle 256 Farben erlauben')]),
      el('label', { class: 'chk' }, [el('input', { type: 'checkbox', onchange: function () { opts.resize = this.checked; } }), $t('Groesse anpassen')])
    ]),
    el('p', { class: 'hint', html: $t('Bildgroesse muss ') + it.w + 'x' + it.h + $t(' sein (oder "Groesse anpassen"). Erlaubter Farbbereich: Index ') + lo + '-' + hi + '. ' +
      (it.group === $t('Stadt-Texturen') ? $t('Die Texturen werden ueber Rahmen (Deskriptoren) auf die 3D-Flaechen gelegt - Motive also an derselben Stelle lassen.') : '') })
  ]);
  main.appendChild(box);
  main.appendChild(el('div', { class: 'card' }, [el('h4', { text: $t('Palette (Bereich ') + lo + '-' + hi + ')' }), G.palGrid(P, lo, hi)]));
}

/* Deskriptor-Rahmen der Stadttexturen ueber den Atlas zeichnen */
function drawDescriptors(cv, it) {
  var L = G.levels()[it.level], d = G.App.rom.data, cx = cv.getContext('2d');
  cx.strokeStyle = 'rgba(255,220,0,.8)'; cx.lineWidth = 1;
  for (var k = 0; k < 512; k++) {
    var o = L.mapBase + 0xC000 + 40 * k;
    if (G.u32(d, o) !== 2 || d[o + 6] !== it.slot) continue;
    cx.beginPath();
    for (var p = 0; p < 4; p++) { var u = G.u32(d, o + 8 + 8 * p) / 16, vv = G.u32(d, o + 12 + 8 * p) / 16; if (p) cx.lineTo(u, vv); else cx.moveTo(u, vv); }
    cx.closePath(); cx.stroke();
  }
}

async function doImport(it, raw, P, lo, hi, opts, palChoice) {
  var f = await G.pickFile('image/*,.png,.bmp,.jpg,.jpeg,.gif');
  if (!f) return;
  try {
    G.busy($t('Bild wird eingelesen ...')); await G.yieldUI();
    if (opts.allRange) { lo = 0; hi = 255; }
    var res;
    if (opts.newColors) {
      var im = await G.readImageFile(f);
      if (im.w !== it.w || im.h !== it.h) { if (!opts.resize) throw new Error($t('Bildgroesse ') + im.w + 'x' + im.h + $t(' passt nicht (erwartet ') + it.w + 'x' + it.h + ').'); im = G.resizeRGBA(im, it.w, it.h); }
      /* Palette neu: nur Slots, die die Palettendatei wirklich enthaelt */
      var file = palChoice[palChoice.length - 1], slots = G.palFileSlots(file).filter(function (s) { return s >= lo && s <= hi; });
      if (!slots.length) throw new Error($t('Die gewaehlte Palette enthaelt keine Farben im Bereich ') + lo + '-' + hi + '.');
      var cols = G.medianCut(im.rgba, slots.length, false);
      var start = slots[0];
      G.writePalColors(file, start, cols);
      var P2 = P.slice(); cols.forEach(function (c, k) { P2[start + k] = c; });
      res = { idx: G.quantize(im.rgba, it.w, it.h, P2, start, start + cols.length - 1, {}), mode: $t('neue Palette (') + cols.length + $t(' Farben)') };
      G.logChange(it.name + $t(': Palette ') + G.hx(file) + $t(' Farben ') + start + '-' + (start + cols.length - 1) + $t(' neu berechnet'));
    } else {
      res = await G.importIndexed(f, it.w, it.h, P, { lo: lo, hi: hi, allowResize: opts.resize });
    }
    var full = G.vcDecode(G.App.rom.data, it.off).data.slice();
    full.set(res.idx, 0);
    if (G.bytesEqual(full, G.vcDecode(G.App.rom.data, it.off).data)) { G.busy(false); G.toast($t('Bild ist unveraendert - nichts zu tun.')); return; }
    G.busyProgress(0.5, $t('Komprimieren ...')); await G.yieldUI();
    var w = G.writeVC(it.off, full, it.name);
    G.busy(false);
    G.toast(it.name + $t(' importiert (') + res.mode + ')' + (w.moved ? $t(' - verschoben nach ') + G.hx(w.off) : ''));
    G.refreshTab();
  } catch (e) { G.busy(false); G.toast($t('Import fehlgeschlagen: ') + e.message, 'err'); console.error(e); }
}

G.imagesExportAll = function (zip) {
  var cat = G.cached('images', G.imageCatalog), n = 0;
  cat.forEach(function (it) {
    var raw = G.vcDecode(G.App.rom.data, it.off).data, P = G.composePal(it.pals).bg;
    zip.add('bilder/' + fileName(it), G.pngWriteIndexed(raw.subarray(0, it.w * it.h), it.w, it.h, P, false)); n++;
  });
  return n;
};
G.imagesImportFile = async function (name, bytes, report) {
  var m = /^bild_(.+?)_([0-9A-F]{6})_(\d+)x(\d+)\.png$/i.exec(name);
  if (!m) return false;
  var cat = G.cached('images', G.imageCatalog), it = cat.filter(function (x) { return x.id === m[1]; })[0];
  if (!it) { report.skip.push(name + $t(': unbekannte Grafik')); return true; }
  var png = G.pngRead(bytes), P = G.composePal(it.pals).bg;
  if (png.w !== it.w || png.h !== it.h) { report.skip.push(name + $t(': falsche Groesse')); return true; }
  var old = G.vcDecode(G.App.rom.data, it.off).data, rg = idxRange(old.subarray(0, it.w * it.h));
  var idx = (png.mode === 'P') ? png.idx : G.quantize(png.rgba, it.w, it.h, P, rg[0], rg[1], {});
  var full = old.slice(); full.set(idx, 0);
  if (G.bytesEqual(full, old)) return true;
  G.writeVC(it.off, full, it.name); G.invalidate('images');
  report.done.push(it.name);
  return true;
};
})(window);
