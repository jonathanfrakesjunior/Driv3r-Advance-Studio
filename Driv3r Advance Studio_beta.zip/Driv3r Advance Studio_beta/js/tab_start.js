/* Driv3r Advance Studio - tab_start.js */
(function (global) {
'use strict';
var G = global.D3S, el = G.el;

G.registerTab({
  id: 'start', label: $t('Start'), icon: '⌂', group: $t('Allgemein'),
  render: function (v) {
    v.appendChild(el('div', { class: 'hero' }, [
      el('h1', { html: 'Driv3r Advance Studio' }),
      el('p', { class: 'lead', html: $t('Mod-Werkzeug fuer <b>Driv3r</b> (Game Boy Advance, Europe). Laeuft komplett im Browser - ') +
        $t('keine Installation, kein Server. Alle Aenderungen bleiben im Speicher, bis du sie als neue ROM oder als Projekt sicherst. ') +
        $t('Die Original-Datei wird nie veraendert.') }),
      el('div', { class: 'row' }, [
        G.button($t('ROM laden'), function () { G.$('btnLoadRom').click(); }, 'primary'),
        G.App.rom ? G.button($t('Zur ROM-Uebersicht'), function () { G.selectTab('rom'); }) : null,
        el('span', { class: 'hint', text: $t('oder die .gba-Datei einfach ins Fenster ziehen') })
      ])
    ]));
    var feats = [
      [$t('Bilder & Texturen'), $t('Titel- und Menuebilder, Menue-3D-Texturen und alle 10 Stadt-Texturatlanten (256x256) als PNG heraus und wieder hinein. Kompression (VC) erledigt das Studio.')],
      [$t('Zwischensequenzen'), $t('213 JPEG-Standbilder der Story (240x160) austauschen und die 33 Bildfolgen samt Untertiteln in 5 Sprachen bearbeiten.')],
      [$t('Sprites'), $t('Fahrzeuge (23 Modelle, alle Blickwinkel), Figuren-Animationen und Effekte einzeln (auch in neuer Groesse) oder als Bogen ex- und importieren.')],
      [$t('HUD, Schrift & Skyline'), $t('HUD-Grafiken, Menue-Schrift mit Zeichentabelle, die Spielschrift aller Meldungen (Zeichen-Editor) und die sechs Skyline-Panoramen.')],
      [$t('Paletten'), $t('Alle 16 Palettendateien direkt bearbeiten, als .pal/.act/.png sichern und laden.')],
      [$t('Texte'), $t('Missionsmeldungen in 5 Sprachen nebeneinander, Credits und Menuetexte. Laengere Texte werden automatisch verschoben.')],
      [$t('Sound & Musik'), $t('10 Songs (Tracker-Format GBAMOD30) anhoeren, als WAV/MIDI exportieren, MIDI importieren. 16 Instrumente und 38 Effekte als WAV tauschen.')],
      [$t('Karteneditor'), $t('Miami und Nizza aus den echten 3D-Daten texturiert von oben. Neue Gebaeude, Strassen mit KI-Verkehr, Plaetze, Wasser, Rampen und Bruecken bauen; Flaechen loeschen, verschieben, neu texturieren; Verkehrsspuren anzeigen.')],
      [$t('Missionseditor'), $t('Alle 25 Missionen, alle 19 Befehle entschluesselt: Start, Zonen, Zeitlimits, Rennen, Verfolgungen, KI-Routen, Zwischensequenzen, Meldungen - Punkte direkt auf der Karte verschiebbar.')],
      [$t('Komplett-Paket'), $t('Alles auf einmal als ZIP exportieren, extern bearbeiten und wieder einspielen - ideal fuer Total Conversions.')]
    ];
    var f = el('div', { class: 'feat' });
    feats.forEach(function (x) { f.appendChild(el('div', { class: 'f' }, [el('b', { text: x[0] }), el('span', { text: x[1] })])); });
    v.appendChild(f);
    v.appendChild(el('h3', { text: $t('So geht es') }));
    v.appendChild(el('ol', { class: 'steps' }, [
      el('li', { text: $t('Eigene, legal erstellte ROM von "Driv3r (Europe)" laden (B3RP, 8 MB).') }),
      el('li', { text: $t('Links einen Bereich waehlen, Inhalte exportieren, bearbeiten und wieder importieren.') }),
      el('li', { text: $t('Unter "ROM & Projekt" regelmaessig das Projekt sichern (.d3studio - enthaelt nur deine Aenderungen).') }),
      el('li', { text: $t('"ROM speichern" erzeugt die fertige .gba (Kopf-Pruefsumme wird korrigiert). In mGBA testen.') })
    ]));
    v.appendChild(el('p', { class: 'hint', html: $t('Erwartete ROM: SHA-1 <span class="mono">') + G.K.SHA1 + $t('</span>. Grosse Umbauten koennen die ROM auf 16 MB erweitern ') +
      $t('(mehr geht wegen des EEPROM-Speicherstands nicht).') }));
  }
});
})(window);
