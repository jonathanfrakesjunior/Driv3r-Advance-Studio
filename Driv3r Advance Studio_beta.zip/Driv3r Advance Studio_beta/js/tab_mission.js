/* Driv3r Advance Studio - tab_mission.js : Missionseditor
   Missionstabelle = Kartenbasis + u32[Kartenbasis+0x11020]:
     u16 Offsets je Mission (0 = Ende) -> Liste u16 Offsets je Schritt (0 = Ende) -> Befehl (1 Opcode-Byte + Daten).
   Das Spiel arbeitet einen Schritt nach dem anderen ab (Interpreter ab 0x0816E178, 19 Befehle, alle entschluesselt).
   Koordinaten: s16 X (Ost), s16 Y (Nord), teils mit s16 Hoehe (Z) dazwischen. */
(function (global) {
'use strict';
var G = global.D3S, el = G.el;
var st = { level: 0, mission: 0, step: -1 };
G.missionFocus = st;

/* ---------------------------------------------------------------- Befehle */
/* Befehle - Bedeutung aus dem Interpreter entschluesselt (Init-Tabelle 0x0817137C, Update-Tabelle 0x0816E324).
   Byte-Positionen zaehlen ab dem Opcode-Byte. X/Y = Karte, Z = Hoehe. */
var FIXED = { 0x00: 14, 0x02: 2, 0x05: 2, 0x06: 2, 0x07: 4, 0x08: 40, 0x0A: 12, 0x0E: 6, 0x10: 24, 0x12: 2 };
function xzy(o, kind) { return { at: o, z: o + 2, y: o + 4, kind: kind }; }
function run(b, o, n, kind) { var p = []; for (var i = 0; (n < 0 || i < n) && o + 6 * i + 6 <= b.length; i++) p.push(xzy(o + 6 * i, kind)); return p; }
function runFields(b, o, n) { var f = []; for (var i = 0; (n < 0 || i < n) && o + 6 * i + 6 <= b.length && i < 24; i++) f.push(['P' + (i + 1) + ' X', o + 6 * i, 's16'], ['P' + (i + 1) + $t(' Hoehe'), o + 6 * i + 2, 's16'], ['P' + (i + 1) + ' Y', o + 6 * i + 4, 's16']); return f; }
/* Befehl 04/0B: Art 0 = Zone (4 Eckpunkte ab Byte 6), Art 1..0x17 = Objekt dieser Art, ab 0x18 = Markierung (+-16 Einheiten) */
function zoneKind(k) { return k === 0 ? $t('Zone (Viereck)') : k >= 0x18 ? $t('Markierung') : $t('Objekt Art ') + k; }
function zonePts(b) { var a = [{ at: 2, y: 4, kind: 'arrow' }]; return b[1] === 0 ? a.concat(polyPts(6, 4)) : a.concat([xzy(6, 'target')]); }
function zoneFields(b) {
  var f = [[$t('Art (0=Zone, 1-23=Objekt, 24+=Markierung)'), 1, 'u8'], [$t('Radarpfeil X'), 2, 's16'], [$t('Radarpfeil Y'), 4, 's16']];
  return b[1] === 0 ? f.concat(ptFields(6, 4)) : f.concat([['X', 6, 's16'], [$t('Hoehe'), 8, 's16'], ['Y', 10, 's16'], [$t('Parameter'), 12, 'u16']]);
}
var OPS = {
  0x00: { name: $t('Missionsstart (Spieler, Fahrzeug, Tageszeit)'), short: $t('Start'), pts: function () { return [xzy(6, 'spawn')]; },
    fields: [[$t('Texturensatz'), 1, 'u8'], [$t('Tageszeit (Himmel/Palette)'), 2, 'u8'], [$t('Fahrzeug (0 = zu Fuss, sonst Modell+1)'), 3, 'u8'], [$t('Wert 4'), 4, 'u8'], [$t('Wert 5'), 5, 'u8'], ['X', 6, 's16'], [$t('Hoehe'), 8, 's16'], ['Y', 10, 's16'], [$t('Winkel'), 12, 'u16']] },
  0x01: { name: $t('Objektliste'), short: $t('Liste'), fields: [[$t('Anzahl'), 1, 'u8']] },
  0x02: { name: $t('Speicherpunkt (Neustart ab hier)'), short: $t('Checkpoint'), fields: [[$t('Parameter'), 1, 'u8']] },
  0x03: { name: $t('Ziele in Zeit erreichen/zerstoeren'), short: $t('Ziele+Zeit'), pts: function (b) { var p = []; for (var i = 0; i < b[1] && 4 + 6 * i + 6 <= b.length; i++) p.push({ at: 6 + 6 * i, y: 8 + 6 * i, kind: 'target' }); return p; },
    fields: function (b) { var f = [[$t('Anzahl'), 1, 'u8'], [$t('Zeitlimit'), 2, 'u16']]; for (var i = 0; i < b[1] && i < 16; i++) f.push(['Z' + (i + 1) + $t(' ID'), 4 + 6 * i, 'u16'], ['Z' + (i + 1) + ' X', 6 + 6 * i, 's16'], ['Z' + (i + 1) + ' Y', 8 + 6 * i, 's16']); return f; } },
  0x04: { name: $t('Hinfahren (Zone/Markierung/Objekt)'), short: $t('Ziel'), pts: zonePts, fields: zoneFields },
  0x05: { name: $t('Zwischensequenz abspielen'), short: $t('Sequenz'), fields: [[$t('Bildfolge Nr. (0-32)'), 1, 'u8']], story: true },
  0x06: { name: $t('Meldung anzeigen'), short: $t('Meldung'), fields: [[$t('Meldung ID'), 1, 'u8']], msg: true },
  0x07: { name: $t('Zeitanzeige/Timer'), short: $t('Timer'), fields: [[$t('Modus'), 1, 'u8'], [$t('Zeit'), 2, 'u16']] },
  0x08: { name: $t('6 Objekte platzieren (Strassensperre)'), short: $t('Objekte'), pts: function (b) { return run(b, 4, 6, 'obj'); },
    fields: function (b) { return [[$t('Wert 1'), 1, 'u8'], [$t('Basis-ID'), 2, 'u16']].concat(runFields(b, 4, 6)); } },
  0x09: { name: $t('KI-Fahrzeug mit Route'), short: $t('KI-Route'), pts: function (b) { return run(b, 8, -1, 'path'); },
    fields: function (b) { return [[$t('Akteur-ID'), 1, 'u8'], [$t('Wert 2'), 2, 'u16'], [$t('Typ'), 4, 'u8'], [$t('Wert 5'), 5, 'u8'], [$t('Wert 6'), 6, 'u16']].concat(runFields(b, 8, -1)); } },
  0x0A: { name: $t('Akteur platzieren + Countdown'), short: $t('Platzieren'), pts: function () { return [xzy(4, 'spawn')]; },
    fields: [[$t('Art'), 1, 'u8'], [$t('Countdown (Frames)'), 2, 'u16'], ['X', 4, 's16'], [$t('Hoehe'), 6, 's16'], ['Y', 8, 's16'], [$t('Winkel'), 10, 'u16']] },
  0x0B: { name: $t('Hinfahren mit Grenzen'), short: $t('Ziel+'), pts: zonePts,
    fields: function (b) { return zoneFields(b).concat(b.length >= 26 ? [[$t('Grenze A'), 22, 's16'], [$t('Grenze B'), 24, 's16']] : []); } },
  0x0C: { name: $t('Verfolgung (aufgezeichnete Fahrt)'), short: $t('Verfolgung'), pts: function (b) { return run(b, 16, -1, 'path'); },
    fields: function (b) { return [[$t('Wert 1'), 1, 'u8'], [$t('Wert 6'), 6, 'u16'], [$t('Wert 8'), 8, 'u16'], [$t('Startpunkt'), 14, 'u8'], [$t('Modell?'), 15, 'u8']].concat(runFields(b, 16, -1)); } },
  0x0D: { name: $t('Formation/Gruppe'), short: $t('Gruppe') },
  0x0E: { name: $t('Warten bis Akteur fertig'), short: $t('Warten'), fields: [[$t('Wert 1'), 1, 'u8'], [$t('Akteur'), 2, 'u8'], [$t('Wert 3'), 3, 'u8'], [$t('Wert 4'), 4, 'u8'], [$t('Wert 5'), 5, 'u8']] },
  0x0F: { name: $t('Rennen (Checkpoints)'), short: $t('Rennen'), pts: function (b) { return run(b, 8, -1, 'path'); },
    fields: function (b) { return [[$t('Fahrzeug (Modell+1)'), 1, 'u8'], [$t('Startpunkt'), 6, 'u8']].concat(runFields(b, 8, -1)); } },
  0x10: { name: $t('Zone mit Radarpfeil'), short: $t('Zone'), pts: function () { return [xzy(2, 'arrow')].concat(polyPts(8, 4)); },
    fields: function () { return [[$t('Art'), 1, 'u8'], [$t('Pfeil X'), 2, 's16'], [$t('Pfeil Hoehe'), 4, 's16'], [$t('Pfeil Y'), 6, 's16']].concat(ptFields(8, 4)); } },
  0x11: { name: $t('Pfad folgen'), short: $t('Pfad'), pts: function (b) { return run(b, 4, -1, 'path'); },
    fields: function (b) { return [[$t('Flag'), 1, 'u8'], [$t('Wert 2'), 2, 'u8'], [$t('Startpunkt'), 3, 'u8']].concat(runFields(b, 4, -1)); } },
  0x12: { name: $t('Mission beenden (geschafft)'), short: $t('Ende'), fields: [[$t('Verzoegerung (Frames)'), 1, 'u8']] }
};
function polyPts(o, n) { var p = []; for (var i = 0; i < n; i++) p.push({ at: o + 4 * i, y: o + 4 * i + 2, kind: 'poly' }); return p; }
function ptFields(o, n) { var f = []; for (var i = 0; i < n; i++) { f.push(['P' + (i + 1) + ' X', o + 4 * i, 's16']); f.push(['P' + (i + 1) + ' Y', o + 4 * i + 2, 's16']); } return f; }
function zoneTpl() { return [0x04, 0x00, 0, 0, 0, 0, 0xE0, 0xFF, 0xE0, 0xFF, 0x20, 0, 0xE0, 0xFF, 0x20, 0, 0x20, 0, 0xE0, 0xFF, 0x20, 0]; }
var TEMPLATES = [
  [0x06, $t('Meldung anzeigen'), [0x06, 0x00]],
  [0x04, $t('Zielzone (Viereck)'), zoneTpl()],
  [0x04, $t('Markierung anfahren'), [0x04, 0x18, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]],
  [0x10, $t('Zone mit Radarpfeil'), [0x10, 0x00, 0, 0, 0, 0, 0, 0, 0xE0, 0xFF, 0xE0, 0xFF, 0x20, 0, 0xE0, 0xFF, 0x20, 0, 0x20, 0, 0xE0, 0xFF, 0x20, 0]],
  [0x0A, $t('Akteur platzieren + Countdown'), [0x0A, 0x01, 0x3C, 0, 0, 0, 0, 0, 0, 0, 0, 0]],
  [0x07, $t('Timer setzen'), [0x07, 0x01, 0x10, 0x0E]],
  [0x02, $t('Speicherpunkt'), [0x02, 0x00]],
  [0x05, $t('Zwischensequenz'), [0x05, 0x00]],
  [0x12, $t('Mission beenden'), [0x12, 0xA0]]
];

function rd(b, o, t) { if (t === 'u8') return b[o]; var v = b[o] | (b[o + 1] << 8); return t === 's16' ? (v << 16 >> 16) : v; }
function wr(b, o, t, v) { if (t === 'u8') b[o] = v & 255; else { b[o] = v & 255; b[o + 1] = (v >> 8) & 255; } }

/* ---------------------------------------------------------------- Lesen/Schreiben */
function load(levelIdx) {
  var L = G.levels()[levelIdx], d = G.App.rom.data;
  var tbl = L.mapBase + G.u32(d, L.mapBase + 0x11020), H = function (o) { return G.u16(d, tbl + o); };
  var ms = [], m = 0, all = {};
  while (m < 64 && H(2 * m)) {
    var mo = H(2 * m), steps = [], s = 0;
    while (s < 250 && H(mo + 2 * s)) { steps.push(H(mo + 2 * s)); all[H(mo + 2 * s)] = 1; s++; }
    ms.push({ mo: mo, offs: steps }); m++;
  }
  var sorted = Object.keys(all).map(Number).sort(function (a, b) { return a - b; });
  function stepLen(o) {
    var i = sorted.indexOf(o), op = d[tbl + o];
    if (i + 1 < sorted.length) return sorted[i + 1] - o;
    if (FIXED[op]) return FIXED[op];
    if (op === 0x04) return d[tbl + o + 1] === 0 ? 22 : 14;
    return 2;
  }
  var end = 0;
  ms.forEach(function (mi) {
    mi.steps = mi.offs.map(function (o) { var n = stepLen(o); end = Math.max(end, o + n); return { off: tbl + o, bytes: d.slice(tbl + o, tbl + o + n) }; });
  });
  return { L: L, tbl: tbl, size: end, missions: ms };
}
/* gesamte Tabelle neu bauen; passt sie nicht an den alten Platz, ans ROM-Ende */
function save(model, label) {
  var nm = model.missions.length, head = (nm + 1) * 2, lists = [], p = head;
  model.missions.forEach(function (mi) { lists.push(p); p += (mi.steps.length + 1) * 2; });
  var stepOff = [];
  model.missions.forEach(function (mi, k) { stepOff[k] = mi.steps.map(function (s) { var o = p; p += s.bytes.length; return o; }); });
  if (p > 0xFFFF) throw new Error($t('Missionstabelle zu gross (') + p + $t(' Byte, max. 65535).'));
  var buf = new Uint8Array(p);
  model.missions.forEach(function (mi, k) {
    G.putU16(buf, 2 * k, lists[k]);
    mi.steps.forEach(function (s, j) { G.putU16(buf, lists[k] + 2 * j, stepOff[k][j]); buf.set(s.bytes, stepOff[k][j]); });
  });
  var d = G.App.rom.data, L = model.L, target;
  if (p <= model.size) { target = model.tbl; d.set(buf, target); for (var i = target + p; i < model.tbl + model.size; i++) d[i] = 0; }
  else {
    var al = new G.Allocator(G.App.rom, true); target = al.alloc(p);
    if (target < 0) throw new Error($t('Kein Platz in der ROM.'));
    G.App.rom.data.set(buf, target);
    G.putU32(G.App.rom.data, L.mapBase + 0x11020, target - L.mapBase);
  }
  G.logChange(label + (target !== model.tbl ? $t(' (Missionstabelle ') + L.name + $t(' verschoben nach ') + G.hx(target) + ')' : ''));
  G.invalidate(['missions' + st.level]);
}
function model() { return G.cached('missions' + st.level, function () { return load(st.level); }); }
function missionLabel(k) { return $t('Mission ') + (st.level === 1 ? k + 1 : k + 1); }

/* ---------------------------------------------------------------- Karten-Overlay */
var COLORS = { spawn: '#57d98a', target: '#f5c518', poly: '#ff6b6b', path: '#4da3ff', arrow: '#c77dff', obj: '#ff9f43' };
function stepPoints(s) {
  var op = OPS[s.bytes[0]];
  if (!op || !op.pts) return [];
  try { return op.pts(s.bytes).filter(function (q) { return q.y + 2 <= s.bytes.length; }); } catch (e) { return []; }
}
G.drawMissionOverlay = function (cx, level, w2s, zoom) {
  if (level !== st.level) return;
  var M;
  try { M = model(); } catch (e) { return; }
  var mi = M.missions[st.mission]; if (!mi) return;
  mi.steps.forEach(function (s, j) {
    var pts = stepPoints(s); if (!pts.length) return;
    var selected = j === st.step, col = selected ? '#ffffff' : null;
    var sc = pts.map(function (q) { return w2s(rd(s.bytes, q.at, 's16'), rd(s.bytes, q.y, 's16')); });
    cx.lineWidth = selected ? 3 : 1.5;
    var kind = pts[pts.length - 1].kind;
    if (kind === 'poly' || kind === 'path') {
      cx.strokeStyle = col || COLORS[kind]; cx.beginPath();
      var first = pts[0].kind === kind ? 0 : 1;
      for (var i = first; i < sc.length; i++) { if (i === first) cx.moveTo(sc[i][0], sc[i][1]); else cx.lineTo(sc[i][0], sc[i][1]); }
      if (kind === 'poly') cx.closePath();
      cx.stroke();
    }
    sc.forEach(function (p, i) {
      cx.fillStyle = col || COLORS[pts[i].kind]; cx.beginPath(); cx.arc(p[0], p[1], selected ? 5 : 3.5, 0, 7); cx.fill();
    });
    cx.fillStyle = '#fff'; cx.font = '11px Segoe UI'; cx.fillText(String(j + 1), sc[0][0] + 6, sc[0][1] - 6);
  });
};
G.missionHitTest = function (level, sx, sy, w2s) {
  if (level !== st.level) return null;
  var M = model(), mi = M.missions[st.mission]; if (!mi) return null;
  var best = null, bd = 64;
  mi.steps.forEach(function (s, j) {
    stepPoints(s).forEach(function (q) {
      var p = w2s(rd(s.bytes, q.at, 's16'), rd(s.bytes, q.y, 's16')), dd = (p[0] - sx) * (p[0] - sx) + (p[1] - sy) * (p[1] - sy);
      if (dd < bd) { bd = dd; best = { step: j, q: q }; }
    });
  });
  return best;
};
G.missionDrag = function (hit, x, y) {
  var s = model().missions[st.mission].steps[hit.step];
  wr(s.bytes, hit.q.at, 's16', x); wr(s.bytes, hit.q.y, 's16', y);
  st.step = hit.step;
};
G.missionDragEnd = function (hit) {
  var M = model(), s = M.missions[st.mission].steps[hit.step];
  /* Punkt liegt in einem vorhandenen Schritt: direkt an Ort und Stelle schreiben */
  G.App.rom.data.set(s.bytes, s.off);
  G.logChange(M.L.name + ' ' + missionLabel(st.mission) + $t(' Schritt ') + (hit.step + 1) + $t(': Punkt verschoben'));
  G.updateStatus();
};

/* ---------------------------------------------------------------- Tab */
G.registerTab({
  id: 'mission', label: $t('Missionen'), icon: '⚑', group: $t('Welt'), needsRom: true,
  render: function (v) {
    var lv = G.levels(), M = model(), tc = G.cached('texts', G.textCatalog);
    v.appendChild(el('h2', { text: $t('Missionseditor') }));
    v.appendChild(el('p', { class: 'lead', html: $t('Jede Mission ist eine Folge von Schritten (Befehlen), die das Spiel nacheinander abarbeitet: Fahrzeuge platzieren, ') +
      $t('Meldung zeigen, auf Ankunft in einer Zone warten, Gegner mit Route starten, Rennen, Verfolgungen, Zeitlimits, Zwischensequenzen ... Alle 19 Befehle sind benannt, die Felder beschriftet. Schritte lassen sich aendern, einfuegen, loeschen und verschieben. ') +
      $t('Positionen kannst du im <b>Karteneditor</b> direkt mit der Maus ziehen (Missionen-Ebene zeigt die hier gewaehlte Mission).') }));
    v.appendChild(el('div', { class: 'toolbar' }, [
      G.select(lv.map(function (l, i) { return { value: i, label: l.name }; }), st.level, function (x) { st.level = +x; st.mission = st.level === 1 ? 12 : 0; st.step = -1; G.refreshTab(); }),
      el('span', { class: 'mut', text: M.missions.length + $t(' Missionen, Tabelle ') + G.hx(M.tbl) + ', ' + M.size + $t(' Byte') }),
      el('span', { class: 'spacer' }),
      G.button($t('Auf Karte zeigen'), function () { G.selectTab('map'); }),
      G.button($t('Als JSON exportieren'), function () { G.download('missionen_' + M.L.name.toLowerCase() + '.json', new TextEncoder().encode(G.missionsJSON(st.level)), 'application/json'); }),
      G.button($t('JSON importieren'), async function () {
        var f = await G.pickFile('.json'); if (!f) return;
        try { var rep = { done: [], skip: [] }; G.missionsImportJSON(st.level, await G.readFileText(f), rep); G.toast(rep.done.length ? $t('Missionen uebernommen.') : $t('Keine Aenderungen.')); G.refreshTab(); }
        catch (e) { G.toast(e.message, 'err'); }
      })
    ]));
    var split = el('div', { class: 'split' }), side = el('div', { class: 'side', style: { width: '200px' } }), main = el('div', { style: { flex: '1', minWidth: '0' } });
    var list = el('div', { class: 'list', style: { maxHeight: 'calc(100vh - 280px)' } });
    M.missions.forEach(function (mi, k) {
      var placeholder = mi.steps.length <= 1;
      list.appendChild(el('div', { class: 'it' + (k === st.mission ? ' sel' : ''), onclick: function () { st.mission = k; st.step = -1; G.refreshTab(); } },
        [el('span', { class: 'grow', text: missionLabel(k) + (placeholder ? $t(' (Platzhalter)') : '') }), el('small', { text: mi.steps.length + ' S.' })]));
    });
    side.appendChild(list); split.appendChild(side); split.appendChild(main); v.appendChild(split);
    var mi = M.missions[st.mission]; if (!mi) return;
    main.appendChild(el('div', { class: 'row', style: { marginBottom: '8px' } }, [el('b', { text: missionLabel(st.mission) + ' - ' + mi.steps.length + $t(' Schritte') }), el('span', { class: 'spacer' }),
      G.select(TEMPLATES.map(function (t, i) { return { value: i, label: '+ ' + t[1] }; }), 0, function () { }, { id: 'tplSel' }),
      G.button($t('Schritt einfuegen'), function () {
        var t = TEMPLATES[+document.getElementById('tplSel').value], at = st.step >= 0 ? st.step + 1 : mi.steps.length;
        mi.steps.splice(at, 0, { off: -1, bytes: new Uint8Array(t[2]) });
        commit($t('Schritt eingefuegt (') + t[1] + ')'); st.step = at; G.refreshTab();
      }, 'primary')
    ]));
    mi.steps.forEach(function (s, j) { main.appendChild(stepView(mi, s, j, tc)); });
  }
});

function commit(label) {
  try { save(model(), model().L.name + ' ' + missionLabel(st.mission) + ': ' + label); }
  catch (e) { G.toast(e.message, 'err'); G.invalidate(['missions' + st.level]); }
}

function describe(s, tc) {
  var b = s.bytes, op = OPS[b[0]], txt = op ? op.name : $t('Befehl ') + G.hex(b[0], 2);
  if (b[0] === 0x06 && tc.msg[b[1]]) txt += ' #' + b[1] + ': "' + G.readStr(tc.msg[b[1]][0]).slice(0, 60) + '"';
  else if (b[0] === 0x00) txt += ' (' + (b[3] ? $t('Fahrzeug ') + (b[3] - 1) : $t('zu Fuss')) + $t(' bei ') + rd(b, 6, 's16') + ', ' + rd(b, 10, 's16') + ')';
  else if (b[0] === 0x09) txt += $t(' (Akteur ') + b[1] + ', ' + Math.max(0, (b.length - 8) / 6 | 0) + $t(' Punkte)');
  else if (b[0] === 0x04 || b[0] === 0x0B) txt += ' - ' + zoneKind(b[1]);
  else if (b[0] === 0x05) txt += ' #' + (b[1] + 1);
  else if (b[0] === 0x03) txt += ' (' + b[1] + $t(' Ziele, Zeit ') + rd(b, 2, 'u16') + ')';
  else if (b[0] === 0x0F || b[0] === 0x0C || b[0] === 0x11) txt += ' (' + Math.max(0, (b.length - (b[0] === 0x0F ? 8 : b[0] === 0x0C ? 16 : 4)) / 6 | 0) + $t(' Punkte)');
  return txt;
}

function stepView(mi, s, j, tc) {
  var b = s.bytes, op = OPS[b[0]] || {}, sel = j === st.step;
  var head = el('div', { class: 'sh', onclick: function () { st.step = sel ? -1 : j; G.refreshTab(); } },
    [el('span', { class: 'mut', text: String(j + 1) }), el('span', { class: 'op', text: G.hex(b[0], 2) }), el('span', { class: 'grow', text: describe(s, tc) }), el('small', { class: 'mut', text: b.length + ' B' })]);
  var box = el('div', { class: 'step' + (sel ? ' sel' : '') }, [head]);
  if (!sel) return box;
  var body = el('div', { class: 'sb' });
  var fields = typeof op.fields === 'function' ? op.fields(b) : (op.fields || []);
  var inputs = [];
  if (fields.length) {
    var fg = el('div', { class: 'fieldgrid' });
    fields.forEach(function (f) {
      if (f[1] + (f[2] === 'u8' ? 1 : 2) > b.length) return;
      var inp = el('input', { type: 'number', value: rd(b, f[1], f[2]) });
      inputs.push([inp, f]);
      fg.appendChild(el('label', {}, [f[0], inp]));
    });
    body.appendChild(fg);
  }
  if (op.story) body.appendChild(el('div', { class: 'row' }, [G.button($t('Bildfolge ') + (b[1] + 1) + $t(' im Tab Zwischensequenzen oeffnen'), function () { if (G.cutsceneFocus) { G.cutsceneFocus.mode = 'story'; G.cutsceneFocus.story = b[1]; } G.selectTab('cutscenes'); })]));
  if (op.msg && tc.msg[b[1]]) body.appendChild(el('div', { class: 'okbox', html: G.K.LANGS.map(function (l, i) { return '<b>' + l + '</b>: ' + G.readStr(tc.msg[b[1]][i]); }).join('<br>') }));
  var hex = el('input', { class: 'hexin', value: Array.prototype.map.call(b, function (x) { return G.hex(x, 2); }).join(' ') });
  body.appendChild(el('label', { class: 'hint', style: { display: 'block', marginTop: '8px' } }, [$t('Rohdaten (Hex) - Laenge darf sich aendern'), hex]));
  body.appendChild(el('div', { class: 'row', style: { marginTop: '8px' } }, [
    G.button($t('Speichern'), function () {
      var nb;
      var hv = hex.value.trim().split(/\s+/).map(function (x) { return parseInt(x, 16); });
      var hexChanged = hv.length !== b.length || hv.some(function (x, i) { return x !== b[i]; });
      if (hexChanged) {
        if (hv.some(isNaN) || !hv.length) { G.toast($t('Ungueltige Hex-Werte.'), 'err'); return; }
        nb = new Uint8Array(hv);
      } else {
        nb = b.slice();
        inputs.forEach(function (x) { wr(nb, x[1][1], x[1][2], Math.round(+x[0].value)); });
      }
      s.bytes = nb; commit($t('Schritt ') + (j + 1) + $t(' geaendert')); G.refreshTab();
    }, 'primary'),
    G.button('↑', function () { if (j > 0) { mi.steps.splice(j - 1, 0, mi.steps.splice(j, 1)[0]); st.step = j - 1; commit($t('Schritt verschoben')); G.refreshTab(); } }, '', $t('nach oben')),
    G.button('↓', function () { if (j < mi.steps.length - 1) { mi.steps.splice(j + 1, 0, mi.steps.splice(j, 1)[0]); st.step = j + 1; commit($t('Schritt verschoben')); G.refreshTab(); } }, '', $t('nach unten')),
    G.button($t('Duplizieren'), function () { mi.steps.splice(j + 1, 0, { off: -1, bytes: b.slice() }); st.step = j + 1; commit($t('Schritt dupliziert')); G.refreshTab(); }),
    G.button($t('Loeschen'), async function () {
      if (mi.steps.length <= 1) { G.toast($t('Eine Mission braucht mindestens einen Schritt.'), 'err'); return; }
      if (!await G.confirmBox($t('Schritt loeschen'), $t('Schritt ') + (j + 1) + $t(' entfernen?'), $t('Loeschen'))) return;
      mi.steps.splice(j, 1); st.step = -1; commit($t('Schritt geloescht')); G.refreshTab();
    }, 'danger')
  ]));
  if (stepPoints(s).length) body.appendChild(el('p', { class: 'hint', text: $t('Dieser Schritt hat ') + stepPoints(s).length + $t(' Kartenpunkte - im Karteneditor ziehen.') }));
  box.appendChild(body);
  return box;
}

/* ---------------------------------------------------------------- JSON */
G.missionsJSON = function (level) {
  var M = load(level);
  return JSON.stringify({ stadt: M.L.name, hinweis: $t('Jeder Schritt: Hex-Bytes des Befehls. Opcode = erstes Byte.'),
    missionen: M.missions.map(function (mi, k) { return { nr: k + 1, schritte: mi.steps.map(function (s) { return { befehl: (OPS[s.bytes[0]] || {}).name || '?', hex: Array.prototype.map.call(s.bytes, function (x) { return G.hex(x, 2); }).join(' ') }; }) }; }) }, null, 1);
};
G.missionsImportJSON = function (level, text, rep) {
  var j = JSON.parse(text), M = load(level);
  if (!j.missionen) throw new Error($t('keine Missionsdatei'));
  var changed = false;
  j.missionen.forEach(function (m, k) {
    if (!M.missions[k]) return;
    var steps = m.schritte.map(function (s) { return { off: -1, bytes: new Uint8Array(s.hex.trim().split(/\s+/).map(function (x) { return parseInt(x, 16); })) }; });
    var same = steps.length === M.missions[k].steps.length && steps.every(function (s, i) { return G.bytesEqual(s.bytes, M.missions[k].steps[i].bytes); });
    if (!same) { M.missions[k].steps = steps; changed = true; }
  });
  if (changed) { var old = st.level; st.level = level; save(M, M.L.name + $t(': Missionen aus JSON')); st.level = old; rep.done.push($t('Missionen ') + M.L.name); }
};
})(window);
