/* Driv3r Advance Studio - app.js : Programmrahmen, Navigation, Dialoge, Projekt */
(function (global) {
'use strict';
var G = global.D3S;
G.t = function (s) { return s; };

var App = G.App = { rom: null, tabs: [], active: null, project: { name: $t('Mein Driv3r-Mod'), notes: '' }, log: [] };
G.cache = {};

/* ---------------------------------------------------------------- DOM */
function $(id) { return document.getElementById(id); }
function el(tag, attrs, children) {
  var e = document.createElement(tag);
  if (attrs) for (var k in attrs) {
    var v = attrs[k];
    if (v === null || v === undefined) continue;
    if (k === 'class') e.className = v;
    else if (k === 'text') e.textContent = v;
    else if (k === 'html') e.innerHTML = v;
    else if (k === 'style' && typeof v === 'object') Object.assign(e.style, v);
    else if (k.slice(0, 2) === 'on') e[k] = v;
    else if (k === 'value') e.value = v;
    else if (k === 'checked') e.checked = !!v;
    else if (k === 'disabled') e.disabled = !!v;
    else e.setAttribute(k, v);
  }
  if (children) (Array.isArray(children) ? children : [children]).forEach(function (c) {
    if (c === null || c === undefined || c === false) return;
    e.appendChild(typeof c === 'string' || typeof c === 'number' ? document.createTextNode(String(c)) : c);
  });
  return e;
}
function clear(node) { while (node.firstChild) node.removeChild(node.firstChild); return node; }
G.$ = $; G.el = el; G.clear = clear;

function button(label, onclick, cls, title) { return el('button', { class: cls || '', onclick: onclick, title: title || null }, [label]); }
G.button = button;
function select(options, value, onchange, attrs) {
  var s = el('select', attrs || {});
  options.forEach(function (o) { var op = el('option', { value: String(o.value) }, [o.label]); s.appendChild(op); });
  s.value = String(value);
  s.onchange = function () { onchange(this.value); };
  return s;
}
G.select = select;

/* ---------------------------------------------------------------- Meldungen */
var toastTimer = null;
function toast(msg, kind) {
  var t = $('toast');
  t.textContent = msg;
  t.className = 'show' + (kind ? ' ' + kind : '');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(function () { t.className = ''; }, kind === 'err' ? 7000 : 3500);
  if (kind === 'err') console.warn(msg);
}
G.toast = toast;
function busy(text) {
  var b = $('busy');
  if (text === false) { b.classList.remove('show'); return; }
  $('busyText').textContent = text || $t('Bitte warten ...');
  $('busyBar').style.width = '0%';
  b.classList.add('show');
}
function busyProgress(frac, text) { $('busyBar').style.width = Math.round(frac * 100) + '%'; if (text) $('busyText').textContent = text; }
function yieldUI() { return new Promise(function (r) { setTimeout(r, 0); }); }
G.busy = busy; G.busyProgress = busyProgress; G.yieldUI = yieldUI;

function modal(title, body, buttons) {
  return new Promise(function (resolve) {
    var wrap = $('modal'), box = clear($('modalBox'));
    box.appendChild(el('h3', { text: title }));
    var b = el('div', { class: 'modal-body' });
    if (typeof body === 'string') b.innerHTML = body; else b.appendChild(body);
    box.appendChild(b);
    var foot = el('div', { class: 'modal-foot' });
    (buttons || [{ label: 'OK', value: true, primary: true }]).forEach(function (bt) {
      foot.appendChild(el('button', { class: bt.primary ? 'primary' : (bt.danger ? 'danger' : ''), onclick: function () { wrap.classList.remove('show'); resolve(bt.value); } }, [bt.label]));
    });
    box.appendChild(foot);
    wrap.classList.add('show');
    wrap.onclick = function (e) { if (e.target === wrap) { wrap.classList.remove('show'); resolve(null); } };
  });
}
function confirmBox(title, text, yes) {
  return modal(title, '<p>' + text + '</p>', [{ label: $t('Abbrechen'), value: false }, { label: yes || $t('Ja, ausfuehren'), value: true, primary: true }]);
}
G.modal = modal; G.confirmBox = confirmBox;

/* ---------------------------------------------------------------- Dateien */
function download(name, bytes, mime) {
  var blob = bytes instanceof Blob ? bytes : new Blob([bytes], { type: mime || 'application/octet-stream' });
  var a = document.createElement('a');
  a.href = URL.createObjectURL(blob); a.download = name;
  document.body.appendChild(a); a.click();
  setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 3000);
}
function pickFile(accept, multiple) {
  return new Promise(function (resolve) {
    var inp = el('input', { type: 'file', accept: accept || '', style: 'display:none' });
    if (multiple) inp.multiple = true;
    inp.onchange = function () { var f = multiple ? Array.prototype.slice.call(inp.files) : inp.files[0]; inp.remove(); resolve(f || null); };
    document.body.appendChild(inp); inp.click();
  });
}
function readFileBytes(file) {
  return new Promise(function (resolve, reject) {
    var r = new FileReader();
    r.onload = function () { resolve(new Uint8Array(r.result)); };
    r.onerror = function () { reject(new Error($t('Datei konnte nicht gelesen werden'))); };
    r.readAsArrayBuffer(file);
  });
}
function readFileText(file) {
  return new Promise(function (resolve, reject) {
    var r = new FileReader();
    r.onload = function () { resolve(r.result); };
    r.onerror = function () { reject(new Error($t('Datei konnte nicht gelesen werden'))); };
    r.readAsText(file);
  });
}
G.download = download; G.pickFile = pickFile; G.readFileBytes = readFileBytes; G.readFileText = readFileText;

/* Bild laden (PNG direkt, alles andere ueber den Browser) -> {w,h,rgba,idx?,pal?} */
async function readImageFile(file) {
  var bytes = await readFileBytes(file);
  if (bytes[0] === 137 && bytes[1] === 80) { try { return G.pngRead(bytes); } catch (e) { /* weiter mit Browser */ } }
  return new Promise(function (resolve, reject) {
    var url = URL.createObjectURL(new Blob([bytes])), img = new Image();
    img.onload = function () {
      var c = document.createElement('canvas'); c.width = img.width; c.height = img.height;
      var cx = c.getContext('2d'); cx.drawImage(img, 0, 0);
      var id = cx.getImageData(0, 0, c.width, c.height); URL.revokeObjectURL(url);
      resolve({ w: c.width, h: c.height, mode: 'RGBA', rgba: new Uint8Array(id.data.buffer) });
    };
    img.onerror = function () { URL.revokeObjectURL(url); reject(new Error($t('Bild konnte nicht gelesen werden'))); };
    img.src = url;
  });
}
G.readImageFile = readImageFile;

/* ---------------------------------------------------------------- Canvas-Hilfen */
function idxCanvas(idx, w, h, pal, transparent0, scale) {
  var c = el('canvas'); c.width = w; c.height = h;
  var cx = c.getContext('2d'), id = cx.createImageData(w, h), px = id.data;
  for (var i = 0; i < w * h; i++) {
    var v = idx[i], col = pal[v] || [255, 0, 255];
    px[i * 4] = col[0]; px[i * 4 + 1] = col[1]; px[i * 4 + 2] = col[2]; px[i * 4 + 3] = (transparent0 && v === 0) ? 0 : 255;
  }
  cx.putImageData(id, 0, 0);
  if (scale) { c.style.width = (w * scale) + 'px'; c.style.height = (h * scale) + 'px'; }
  return c;
}
function rgbaCanvas(rgba, w, h, scale) {
  var c = el('canvas'); c.width = w; c.height = h;
  var cx = c.getContext('2d'), id = cx.createImageData(w, h);
  id.data.set(rgba); cx.putImageData(id, 0, 0);
  if (scale) { c.style.width = (w * scale) + 'px'; c.style.height = (h * scale) + 'px'; }
  return c;
}
G.idxCanvas = idxCanvas; G.rgbaCanvas = rgbaCanvas;

/* RGBA -> Indizes einer Palette (nur erlaubte Indizes lo..hi); Index 0 fuer transparente Pixel */
function quantize(rgba, w, h, pal, lo, hi, opts) {
  opts = opts || {};
  var out = new Uint8Array(w * h), cache = new Map(), dither = !!opts.dither;
  var err = dither ? new Float32Array((w + 2) * 3 * 2) : null;
  function nearest(r, g, b) {
    var key = (r << 16) | (g << 8) | b, c = cache.get(key);
    if (c !== undefined) return c;
    var best = lo, bd = 1e9;
    for (var i = lo; i <= hi; i++) {
      var p = pal[i]; if (!p) continue;
      var dr = p[0] - r, dg = p[1] - g, db = p[2] - b, dd = dr * dr * 3 + dg * dg * 4 + db * db * 2;
      if (dd < bd) { bd = dd; best = i; }
    }
    cache.set(key, best); return best;
  }
  for (var y = 0; y < h; y++) for (var x = 0; x < w; x++) {
    var i = y * w + x, a = rgba[i * 4 + 3];
    if (opts.transparent0 && a < 128) { out[i] = 0; continue; }
    out[i] = nearest(rgba[i * 4], rgba[i * 4 + 1], rgba[i * 4 + 2]);
  }
  return out;
}
G.quantize = quantize;

/* ---------------------------------------------------------------- Tabs */
function registerTab(def) { App.tabs.push(def); }
G.registerTab = registerTab;
function buildNav() {
  var nav = clear($('nav')), lastGroup = null;
  App.tabs.forEach(function (t) {
    if (t.group && t.group !== lastGroup) { nav.appendChild(el('div', { class: 'navgroup', text: t.group })); lastGroup = t.group; }
    nav.appendChild(el('button', { class: 'navbtn' + (t.needsRom && !App.rom ? ' dim' : ''), id: 'nav_' + t.id, title: t.hint || '', onclick: function () { selectTab(t.id); } },
      [el('span', { class: 'ico', text: t.icon || '' }), el('span', { text: t.label })]));
  });
}
function selectTab(id) {
  var t = App.tabs.filter(function (x) { return x.id === id; })[0];
  if (!t) return;
  if (t.needsRom && !App.rom) { toast($t('Bitte zuerst die ROM laden.'), 'err'); return; }
  if (App.active && App.activeTab && App.activeTab.leave) { try { App.activeTab.leave(); } catch (e) { } }
  G.stopAudio && G.stopAudio();
  App.active = id; App.activeTab = t;
  Array.prototype.forEach.call(document.querySelectorAll('.navbtn'), function (b) { b.classList.remove('on'); });
  var nb = $('nav_' + id); if (nb) nb.classList.add('on');
  var view = clear($('view'));
  view.scrollTop = 0;
  try { t.render(view); } catch (e) { view.appendChild(el('div', { class: 'card err', text: $t('Fehler in "') + t.label + '": ' + e.message })); console.error(e); }
  updateStatus();
}
function refreshTab() { if (App.active) { var v = $('view'), st = v.scrollTop; selectTab(App.active); v.scrollTop = st; } }
G.selectTab = selectTab; G.refreshTab = refreshTab; G.buildNav = buildNav;

function updateStatus() {
  var s = $('status');
  if (!App.rom) { s.textContent = $t('Keine ROM geladen - "ROM laden" oder Datei ins Fenster ziehen.'); return; }
  var ch = App.rom.changedBytes();
  s.innerHTML = '<b>' + App.rom.name + '</b> &middot; ' + (App.rom.data.length / 1048576).toFixed(0) + ' MB &middot; ' +
    (ch ? '<span class="warn">' + ch.toLocaleString('de-DE') + $t(' geaenderte Bytes</span>') : $t('unveraendert')) +
    $t(' &middot; frei ab ') + G.hx(App.rom.freeStart()) + ' (' + Math.max(0, ((G.ROM_MAX - App.rom.freeStart()) / 1024) | 0).toLocaleString('de-DE') + $t(' KB bis 16 MB)');
}
G.updateStatus = updateStatus;

/* Aenderungsprotokoll */
function logChange(text) { App.log.push({ t: new Date().toLocaleTimeString('de-DE'), text: text }); updateStatus(); }
G.logChange = logChange;
/* Nach jeder Aenderung: Kataloge verwerfen, die sich auf Adressen stuetzen */
function invalidate(which) {
  if (!which) { G.cache = {}; return; }
  (Array.isArray(which) ? which : [which]).forEach(function (k) { delete G.cache[k]; });
}
G.invalidate = invalidate;
function cached(key, fn) { if (!G.cache[key]) G.cache[key] = fn(); return G.cache[key]; }
G.cached = cached;

/* ---------------------------------------------------------------- ROM laden/speichern */
async function loadRomFile(file) {
  busy($t('ROM wird gelesen ...'));
  await yieldUI();
  try {
    var bytes = await readFileBytes(file);
    if (bytes.length < 0x100000) throw new Error($t('Datei ist zu klein fuer eine GBA-ROM.'));
    busyProgress(0.5, $t('Pruefsumme wird berechnet ...')); await yieldUI();
    var r = new G.Rom(bytes, file.name);
    var code = r.code();
    if (code !== G.K.CODE) { busy(false); if (!await confirmBox($t('Andere ROM'), $t('Die Datei meldet den Spielcode <b>') + code + $t('</b> statt <b>B3RP</b> (Driv3r Europe). Trotzdem laden? Viele Funktionen werden dann nicht korrekt arbeiten.'), $t('Trotzdem laden'))) return; }
    App.rom = r; App.log = []; G.cache = {};
    busy(false);
    if (r.sha1 !== G.K.SHA1) toast($t('ROM geladen - Pruefsumme weicht vom bekannten Original ab (bereits gemoddet?).'), 'warn');
    else toast($t('ROM geladen und verifiziert: Driv3r (Europe).'));
    buildNav();
    selectTab('rom');
  } catch (e) { busy(false); toast($t('Fehler: ') + e.message, 'err'); console.error(e); }
}
G.loadRomFile = loadRomFile;
G.saveRom = function () {
  if (!App.rom) { toast($t('Keine ROM geladen.'), 'err'); return; }
  App.rom.fixHeader();
  var base = App.rom.name.replace(/\.(gba|bin)$/i, '').replace(/_mod$/, '');
  download(base + '_mod.gba', App.rom.data);
  toast($t('Gemoddete ROM gespeichert. Vor dem Weitergeben im Emulator testen!'));
};

/* ---------------------------------------------------------------- Projekt */
/* Projektdatei = JSON mit den Unterschieden zum Original (Base64). */
G.saveProject = function () {
  if (!App.rom) return;
  var runs = App.rom.diff().map(function (r) { return { o: r.off, d: G.b64enc(r.bytes) }; });
  var proj = { app: 'Driv3r Advance Studio', version: 1, name: App.project.name, notes: App.project.notes,
    romSha1: App.rom.sha1, size: App.rom.data.length, runs: runs, log: App.log, saved: new Date().toISOString() };
  var name = (App.project.name || 'projekt').replace(/[^\w\-]+/g, '_') + '.d3studio';
  download(name, new TextEncoder().encode(JSON.stringify(proj)), 'application/json');
  toast($t('Projekt gespeichert (') + runs.length + $t(' Aenderungsbereiche).'));
};
G.loadProject = async function (file) {
  if (!App.rom) { toast($t('Erst die Original-ROM laden, dann das Projekt.'), 'err'); return; }
  try {
    var p = JSON.parse(await readFileText(file));
    if (p.app !== 'Driv3r Advance Studio') throw new Error($t('keine Driv3r-Studio-Projektdatei'));
    if (p.romSha1 && p.romSha1 !== App.rom.sha1 && !await confirmBox($t('Andere Basis-ROM'), $t('Das Projekt wurde mit einer anderen ROM erstellt. Trotzdem anwenden?'))) return;
    App.rom.resetAll();
    if (p.size > App.rom.data.length) App.rom.expandTo(p.size);
    p.runs.forEach(function (r) { var b = G.b64dec(r.d); if (r.o + b.length > App.rom.data.length) App.rom.expandTo(Math.min(G.ROM_MAX, r.o + b.length + 0x100000)); App.rom.data.set(b, r.o); });
    App.project.name = p.name || App.project.name; App.project.notes = p.notes || '';
    App.log = p.log || [];
    App.rom.allocTop = 0;
    G.cache = {};
    toast($t('Projekt "') + App.project.name + $t('" angewendet.'));
    refreshTab();
  } catch (e) { toast($t('Projekt konnte nicht geladen werden: ') + e.message, 'err'); }
};

/* ---------------------------------------------------------------- Start */
function start() {
  buildNav();
  $('btnLoadRom').onclick = async function () { var f = await pickFile('.gba,.bin,.agb'); if (f) loadRomFile(f); };
  $('btnSaveRom').onclick = function () { G.saveRom(); };
  $('btnProject').onclick = function () { if (App.rom) selectTab('rom'); else toast($t('Bitte zuerst die ROM laden.'), 'err'); };
  document.body.addEventListener('dragover', function (e) { e.preventDefault(); document.body.classList.add('drag'); });
  document.body.addEventListener('dragleave', function (e) { if (e.target === document.body || e.clientX <= 0) document.body.classList.remove('drag'); });
  document.body.addEventListener('drop', function (e) {
    e.preventDefault(); document.body.classList.remove('drag');
    var f = e.dataTransfer.files[0];
    if (!f) return;
    if (/\.(gba|bin|agb)$/i.test(f.name)) loadRomFile(f);
    else if (/\.d3studio$/i.test(f.name)) G.loadProject(f);
    else toast($t('Bitte eine .gba-ROM oder eine .d3studio-Projektdatei ablegen.'), 'err');
  });
  selectTab('start');
  updateStatus();
  /* Entwickler-Test: index.html?autoload=<datei.gba>&tab=<id> (nur ueber http) */
  var q = new URLSearchParams(location.search);
  if (q.get('autoload') && /^http/.test(location.protocol)) {
    fetch(q.get('autoload')).then(function (r) { return r.arrayBuffer(); }).then(function (ab) {
      return loadRomFile(new File([new Uint8Array(ab)], q.get('autoload')));
    }).then(function () { if (q.get('tab')) selectTab(q.get('tab')); });
  }
}
G.start = start;
window.addEventListener('DOMContentLoaded', start);
window.addEventListener('beforeunload', function (e) { if (App.rom && App.rom.changedBytes() > 0) { e.preventDefault(); e.returnValue = ''; } });
})(window);
