/* Driv3r Advance Studio - codec_vc.js
   "VC"-Kompression von VD-dev (Dekoder im Spiel: 0x08254338).
   Kopf: 'V','C', u32 Groesse (LE), u8 Modus.
     Modus 0   : nur 8-Bit-Literale
     Modus 1-8 : naechstes Byte = Escape-Wert fuer die oberen <Modus> Bits eines Literals
     Modus 9   : 1 Flag-Bit je Symbol (0 = Literal, 1 = Kopie)
   Bitstrom MSB-zuerst. Gamma-Zahl: k Einsen, eine Null, dann k Bits -> (1<<k)|bits.
   Kopie: L = gamma+1; L>2: dist = ((gamma-1)<<8) + 8 Bit + 2
          L==2: Bit 0 -> dist = 8 Bit + 2 | Bit 1 -> (Modus 9 oder weiteres Bit 1) Fuellung:
          n = gamma+1, Byte = 8 Bit | sonst (Modus 1-8, Bit 0): neuer Escape-Wert.
   Das Spiel schreibt in Halbwoertern - die Groesse muss gerade sein. */
(function (global) {
'use strict';
var G = global.D3S;

function isVC(d, off) { return off >= 0 && off + 7 <= d.length && d[off] === 0x56 && d[off + 1] === 0x43; }
function vcSize(d, off) { return d[off + 2] | (d[off + 3] << 8) | (d[off + 4] << 16) | (d[off + 5] * 16777216); }

function vcDecode(d, off) {
  if (!isVC(d, off)) throw new Error($t('kein VC-Block bei ') + G.hx(off));
  var size = vcSize(d, off), mode = d[off + 6], p = off + 7, esc = -1;
  if (size <= 0 || size > 0x80000) throw new Error($t('VC-Groesse unplausibel'));
  if (mode !== 0 && mode !== 9) { if (mode > 9) throw new Error($t('VC-Modus ') + mode + $t(' unbekannt')); esc = d[p++]; }
  var out = new Uint8Array(size), ol = 0;
  var bitpos = p * 8, n = d.length;
  function bits(k) {
    var v = 0;
    while (k-- > 0) {
      var by = bitpos >> 3;
      if (by >= n) throw new Error($t('VC-Daten abgeschnitten'));
      v = (v << 1) | ((d[by] >> (7 - (bitpos & 7))) & 1); bitpos++;
    }
    return v;
  }
  function gamma() { var k = 0; while (bits(1)) { k++; if (k > 24) throw new Error($t('VC: Gamma-Ueberlauf')); } return k ? ((1 << k) | bits(k)) : 1; }
  function copy(len, dist) {
    var s = ol - dist;
    if (s < 0) throw new Error($t('VC: Kopie vor Pufferanfang'));
    for (var i = 0; i < len && ol < size; i++) out[ol++] = out[s + i];
  }
  while (ol < size) {
    if (mode === 0) { out[ol++] = bits(8); continue; }
    if (mode === 9) {
      if (bits(1) === 0) { out[ol++] = bits(8); continue; }
    } else {
      var hi = bits(mode);
      if (hi !== esc) { out[ol++] = ((hi << (8 - mode)) | bits(8 - mode)) & 255; continue; }
    }
    var L = gamma() + 1;
    if (L !== 2) { var g = gamma(); copy(L, ((g - 1) << 8) + bits(8) + 2); }
    else if (bits(1) === 0) copy(2, bits(8) + 2);
    else if (mode === 9 || bits(1) === 1) {
      var cnt = gamma() + 1, b = bits(8);
      for (var k = 0; k < cnt && ol < size; k++) out[ol++] = b;
    } else {
      var ne = bits(mode), old = esc; esc = ne;
      out[ol++] = ((old << (8 - mode)) | bits(8 - mode)) & 255;
    }
  }
  return { data: out, used: ((bitpos + 7) >> 3) - off, mode: mode };
}

/* --------------------------------------------------------- Encoder (Modus 9) */
function BitWriter() { this.buf = new Uint8Array(1024); this.len = 0; this.acc = 0; this.n = 0; }
BitWriter.prototype.put = function (v, k) {
  for (var i = k - 1; i >= 0; i--) {
    this.acc = (this.acc << 1) | ((v >>> i) & 1);
    if (++this.n === 8) {
      if (this.len >= this.buf.length) { var nb = new Uint8Array(this.buf.length * 2); nb.set(this.buf); this.buf = nb; }
      this.buf[this.len++] = this.acc; this.acc = 0; this.n = 0;
    }
  }
};
BitWriter.prototype.gamma = function (v) {
  var k = 31 - Math.clz32(v);
  for (var i = 0; i < k; i++) this.put(1, 1);
  this.put(0, 1);
  if (k) this.put(v & ((1 << k) - 1), k);
};
BitWriter.prototype.finish = function () {
  if (this.n) this.put(0, 8 - this.n);
  return this.buf.subarray(0, this.len);
};
function gammaBits(v) { var k = 31 - Math.clz32(v); return 2 * k + 1; }

/* Alle Modi probieren (1-8 mit Escape-Wert, 9 mit Flag-Bit) und den kleinsten nehmen. */
function vcEncode(data, opts) {
  opts = opts || {};
  var best = null;
  var modes = opts.modes || [9, 1, 2, 3, 4, 5, 6, 7, 8];
  for (var i = 0; i < modes.length; i++) {
    var r = vcEncodeMode(data, modes[i], opts);
    if (!best || r.length < best.length) best = r;
  }
  /* Selbsttest: zurueck dekodieren */
  var chk = vcDecode(best, 0).data;
  if (!G.bytesEqual(chk, data)) throw new Error($t('VC-Encoder Selbsttest fehlgeschlagen'));
  return best;
}

/* Greedy-LZ mit Hash-Ketten und einfacher Vorausschau. */
function vcEncodeMode(data, mode, opts) {
  var n = data.length;
  var K = mode === 9 ? 0 : mode, esc = 0;
  if (mode !== 9) {
    /* seltensten Wert der oberen K Bits als Escape waehlen */
    var cnt = new Int32Array(1 << K);
    for (var e = 0; e < n; e++) cnt[data[e] >> (8 - K)]++;
    var mn = 1e12;
    for (var v = 0; v < (1 << K); v++) if (cnt[v] < mn) { mn = cnt[v]; esc = v; }
  }
  var LIT = mode === 9 ? 9 : 8, LIT_ESC = K + 11, PRE = mode === 9 ? 1 : K;
  if (n & 1) throw new Error($t('VC: Groesse muss gerade sein'));
  var WIN = opts.window || 0x8000, MAXCHAIN = opts.chain || 96, MAXLEN = 0x4000;
  var head = new Int32Array(65536).fill(-1), prev = new Int32Array(n).fill(-1), ins = 0;
  function hash(i) { return ((data[i] << 8) ^ data[i + 1] ^ (data[i + 2] << 3)) & 0xffff; }
  /* alle Positionen < j genau einmal in die Hash-Ketten eintragen */
  function insertTo(j) { while (ins < j) { if (ins + 2 < n) { var h = hash(ins); prev[ins] = head[h]; head[h] = ins; } ins++; } }
  function run(i) { var b = data[i], j = i + 1; while (j < n && data[j] === b && j - i < MAXLEN) j++; return j - i; }
  function best(i) {
    var bl = 0, bd = 0;
    if (i + 2 >= n) {
      if (i + 1 < n && i >= 2) {
        for (var d2 = 2; d2 <= Math.min(257, i); d2++) if (data[i - d2] === data[i] && data[i - d2 + 1] === data[i + 1]) return { len: 2, dist: d2 };
      }
      return { len: 0, dist: 0 };
    }
    var c = head[hash(i)], chain = 0, lim = Math.min(MAXLEN, n - i);
    while (c >= 0 && chain++ < MAXCHAIN) {
      var dist = i - c;
      if (dist > WIN) break;
      if (dist >= 2 && data[c + bl] === data[i + bl]) {
        var l = 0;
        while (l < lim && data[c + l] === data[i + l]) l++;
        if (l > bl || (l === bl && dist < bd)) { bl = l; bd = dist; if (l === lim) break; }
      }
      c = prev[c];
    }
    if (bl < 3) {
      /* kurze Kopie (L=2) lohnt nur mit kleiner Distanz */
      bl = 0; bd = 0;
      for (var d3 = 2; d3 <= Math.min(257, i); d3++) if (data[i - d3] === data[i] && data[i - d3 + 1] === data[i + 1]) { bl = 2; bd = d3; break; }
    }
    return { len: bl, dist: bd };
  }
  function litCost(b) { return (mode !== 9 && (b >> (8 - K)) === esc) ? LIT_ESC : LIT; }
  function matchCost(len, dist) {
    if (len === 2) return PRE + 10;
    return PRE + gammaBits(len - 1) + gammaBits(((dist - 2) >> 8) + 1) + 8;
  }
  function litsCost(i, len) { var c = 0; for (var k = 0; k < len; k++) c += litCost(data[i + k]); return c; }
  function putPre() { if (mode === 9) bw.put(1, 1); else bw.put(esc, K); }
  function putLit(b) {
    if (mode === 9) { bw.put(0, 1); bw.put(b, 8); return; }
    if ((b >> (8 - K)) !== esc) { bw.put(b, 8); return; }
    /* Escape-Literal: esc, gamma(1)=0, 1, 0, neuer Escape (= alter), untere Bits */
    bw.put(esc, K); bw.put(0, 1); bw.put(1, 1); bw.put(0, 1); bw.put(esc, K); bw.put(b & ((1 << (8 - K)) - 1), 8 - K);
  }
  var bw = new BitWriter(), i = 0;
  while (i < n) {
    insertTo(i);
    var r = run(i), m = best(i);
    var runCost = PRE + (mode === 9 ? 2 : 3) + gammaBits(Math.max(1, r - 1)) + 8;
    var useRun = r >= 3 && (m.len < r || matchCost(m.len, m.dist) / m.len > runCost / r) && runCost < litsCost(i, r);
    if (useRun) {
      /* Fuellung: Praefix, gamma(1)=0, 1, [Modus 1-8: 1], gamma(n-1), Byte */
      putPre(); bw.put(0, 1); bw.put(1, 1); if (mode !== 9) bw.put(1, 1); bw.gamma(r - 1); bw.put(data[i], 8);
      i += r; continue;
    }
    if (m.len >= 2 && matchCost(m.len, m.dist) < litsCost(i, m.len)) {
      /* einfache Vorausschau: ist die Kopie ab i+1 deutlich besser? */
      if (m.len >= 3 && m.len < 32 && i + 1 < n) {
        insertTo(i + 1);
        var m2 = best(i + 1);
        if (m2.len > m.len + 1) { putLit(data[i]); i++; m = m2; }
      }
      var len = m.len, dist = m.dist;
      putPre();
      if (len === 2) { bw.put(0, 1); bw.put(0, 1); bw.put(dist - 2, 8); }
      else { bw.gamma(len - 1); bw.gamma(((dist - 2) >> 8) + 1); bw.put((dist - 2) & 255, 8); }
      i += len; continue;
    }
    putLit(data[i]); i++;
  }
  var body = bw.finish(), hl = mode === 9 ? 7 : 8;
  var out = new Uint8Array(hl + body.length);
  out[0] = 0x56; out[1] = 0x43; G.putU32(out, 2, n); out[6] = mode;
  if (mode !== 9) out[7] = esc;
  out.set(body, hl);
  return out;
}

G.isVC = isVC; G.vcSize = vcSize; G.vcDecode = vcDecode; G.vcEncode = vcEncode;
})(window);
