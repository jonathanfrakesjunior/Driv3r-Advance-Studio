/* Driv3r Advance Studio - tab_bulk.js : Komplett-Paket (alles als ZIP heraus und wieder hinein) */
(function (global) {
'use strict';
var G = global.D3S, el = G.el;
var AREAS = [
  { id: 'bilder', label: $t('Bilder & Texturen'), exp: function (z) { return G.imagesExportAll(z); }, imp: function (n, b, r) { return G.imagesImportFile(n, b, r); } },
  { id: 'zwischensequenzen', label: $t('Zwischensequenzen'), exp: function (z) { return G.cutscenesExportAll(z); }, imp: function (n, b, r, o) { return G.cutscenesImportFile(n, b, r, o); } },
  { id: 'sprites', label: $t('Sprites'), exp: function (z) { return G.spritesExportAll(z); }, imp: function (n, b, r) { return G.spritesImportFile(n, b, r); } },
  { id: 'kacheln', label: $t('HUD, Schrift, Skyline'), exp: function (z) { return G.tilesExportAll(z); }, imp: function (n, b, r) { return G.tilesImportFile(n, b, r); } },
  { id: 'paletten', label: $t('Paletten'), exp: function (z) { return G.palettesExportAll(z); }, imp: function (n, b, r) { return G.palettesImportFile(n, b, r); } },
  { id: 'texte', label: $t('Texte (CSV)'), exp: function (z) { z.add('texte/texte.csv', new TextEncoder().encode(G.textsCSV())); return 1; },
    imp: function (n, b, r) { if (!/texte\/texte\.csv$/i.test(n)) return false; G.textsImportCSV(new TextDecoder().decode(b), r); return true; } },
  { id: 'sound', label: $t('Sound & Musik'), exp: function (z) { return G.soundExportAll(z); }, imp: function (n, b, r, o) { return G.soundImportFile(n, b, r, o); } },
  { id: 'missionen', label: $t('Missionen (JSON)'), exp: function (z) { G.levels().forEach(function (L, i) { z.add('missionen/missionen_' + L.name.toLowerCase() + '.json', new TextEncoder().encode(G.missionsJSON(i))); }); return 2; },
    imp: function (n, b, r) { var m = /missionen\/missionen_(\w+)\.json$/i.exec(n); if (!m) return false; var i = G.levels().findIndex(function (L) { return L.name.toLowerCase() === m[1].toLowerCase(); }); if (i >= 0) G.missionsImportJSON(i, new TextDecoder().decode(b), r); return true; } }
];
var on = {}; AREAS.forEach(function (a) { on[a.id] = true; });
var lastExport = null;   /* Original-Dateien des letzten Exports (zum Erkennen unveraenderter Dateien) */

G.registerTab({
  id: 'bulk', label: $t('Komplett-Paket'), icon: '⧉', group: $t('Allgemein'), needsRom: true,
  render: function (v) {
    v.appendChild(el('h2', { text: $t('Komplett-Paket') }));
    v.appendChild(el('p', { class: 'lead', html: $t('Alle bearbeitbaren Inhalte als ein ZIP exportieren, mit eigenen Werkzeugen bearbeiten (Grafikprogramm, Audio-Editor, Tabellenkalkulation, DAW) ') +
      $t('und wieder einspielen. Zuordnung ueber die Dateinamen - bitte nicht umbenennen. Unveraenderte Dateien werden uebersprungen; ein unveraendert ') +
      $t('eingespieltes Paket laesst die ROM gleich.') }));
    var boxes = el('div', { class: 'row' });
    AREAS.forEach(function (a) { boxes.appendChild(el('label', { class: 'chk' }, [el('input', { type: 'checkbox', checked: on[a.id], onchange: function () { on[a.id] = this.checked; } }), a.label])); });
    v.appendChild(el('div', { class: 'card' }, [el('h4', { text: $t('Bereiche') }), boxes]));
    v.appendChild(el('div', { class: 'card' }, [el('div', { class: 'row' }, [
      G.button($t('Paket exportieren (ZIP)'), exportAll, 'primary'),
      G.button($t('Paket einspielen (ZIP) ...'), async function () { var f = await G.pickFile('.zip'); if (f) importZip(await G.readFileBytes(f)); }),
      G.button($t('Einzelne Dateien einspielen ...'), async function () {
        var fs = await G.pickFile('', true); if (!fs || !fs.length) return;
        var map = new Map();
        for (var i = 0; i < fs.length; i++) map.set(guessPath(fs[i].name), await G.readFileBytes(fs[i]));
        importMap(map);
      })
    ]), el('p', { class: 'hint', html: $t('Aufbau: <span class="mono">bilder/ zwischensequenzen/ sprites/ kacheln/ paletten/ texte/ sound/songs|instrumente|effekte/ missionen/</span>') })]));
  }
});
function guessPath(n) {
  if (/^bild_/.test(n)) return 'bilder/' + n;
  if (/^zs_/.test(n)) return 'zwischensequenzen/' + n;
  if (/^spriteset_/.test(n)) return 'sprites/' + n;
  if (/^(skyline|tiles)_/.test(n)) return 'kacheln/' + n;
  if (/^palette_/.test(n)) return 'paletten/' + n;
  if (/^texte\.csv$/.test(n)) return 'texte/' + n;
  if (/^song\d+\./.test(n)) return 'sound/songs/' + n;
  if (/^instrument\d+\.wav$/.test(n)) return 'sound/instrumente/' + n;
  if (/^effekt\d+\.wav$/.test(n)) return 'sound/effekte/' + n;
  if (/^missionen_/.test(n)) return 'missionen/' + n;
  return n;
}
async function buildPackage() {
  var z = new G.ZipWriter(), counts = {};
  for (var i = 0; i < AREAS.length; i++) {
    var a = AREAS[i]; if (!on[a.id]) continue;
    G.busyProgress(i / AREAS.length, a.label + ' ...'); await G.yieldUI();
    counts[a.id] = await a.exp(z);
  }
  z.add('manifest.json', new TextEncoder().encode(JSON.stringify({ app: 'Driv3r Advance Studio', romSha1: G.App.rom.sha1, erstellt: new Date().toISOString(), bereiche: counts }, null, 1)));
  return z;
}
G.bulkBuild = buildPackage;
G.bulkForget = function () { lastExport = null; };
async function exportAll() {
  G.busy($t('Paket wird erstellt ...')); await G.yieldUI();
  try {
    var z = await buildPackage();
    lastExport = new Map(); z.files.forEach(function (f) { lastExport.set(f.name, f.data); });
    G.busyProgress(0.95, $t('Packen ...')); await G.yieldUI();
    var zip = await z.buildAsync();
    G.busy(false);
    G.download('driv3r_paket.zip', zip, 'application/zip');
    G.toast(z.count() + $t(' Dateien exportiert.'));
  } catch (e) { G.busy(false); G.toast($t('Export fehlgeschlagen: ') + e.message, 'err'); console.error(e); }
}
async function importZip(bytes) {
  try { importMap(G.zipRead(bytes)); } catch (e) { G.toast(e.message, 'err'); }
}
G.bulkImportMap = function (f) { return importMap(f); };
async function importMap(files) {
  var rep = { done: [], skip: [] }, n = 0, total = files.size;
  G.busy($t('Paket wird eingespielt ...')); await G.yieldUI();
  var names = Array.from(files.keys()).sort();
  for (var k = 0; k < names.length; k++) {
    var name = names[k], data = files.get(name);
    if (/manifest\.json$|\/$/.test(name)) continue;
    if (lastExport && lastExport.get(name) && G.bytesEqual(lastExport.get(name), data)) continue;
    var handled = false;
    for (var i = 0; i < AREAS.length && !handled; i++) {
      if (!on[AREAS[i].id]) continue;
      try { handled = await AREAS[i].imp(name, data, rep, lastExport); } catch (e) { rep.skip.push(name + ': ' + e.message); handled = true; }
    }
    n++;
    if (k % 8 === 0) { G.busyProgress(k / total, name); await G.yieldUI(); }
  }
  G.invalidate();
  G.busy(false);
  G.modal($t('Paket eingespielt'), '<p><b>' + rep.done.length + $t('</b> Aenderungen uebernommen.</p>') +
    (rep.done.length ? '<div class="okbox">' + rep.done.slice(0, 60).join('<br>') + (rep.done.length > 60 ? '<br>...' : '') + '</div>' : '') +
    (rep.skip.length ? $t('<p>Nicht uebernommen:</p><div class="warnbox">') + rep.skip.slice(0, 60).join('<br>') + '</div>' : ''));
  G.updateStatus();
}
})(window);
