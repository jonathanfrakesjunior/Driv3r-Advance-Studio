/* Driv3r Advance Studio - codec_audio.js
   WAV lesen/schreiben, Resampling, MIDI (SMF) lesen/schreiben. */
(function (global) {
'use strict';
var G = global.D3S;

/* ---------------------------------------------------------------- WAV */
/* 8-Bit-PCM des Spiels ist vorzeichenbehaftet; WAV 8 Bit ist vorzeichenlos. */
function wavWrite8(s8, rate) {
  var n = s8.length, out = new Uint8Array(44 + n + (n & 1)), dv = new DataView(out.buffer);
  function str(o, s) { for (var i = 0; i < s.length; i++) out[o + i] = s.charCodeAt(i); }
  str(0, 'RIFF'); dv.setUint32(4, 36 + n + (n & 1), true); str(8, 'WAVE');
  str(12, 'fmt '); dv.setUint32(16, 16, true); dv.setUint16(20, 1, true); dv.setUint16(22, 1, true);
  dv.setUint32(24, rate, true); dv.setUint32(28, rate, true); dv.setUint16(32, 1, true); dv.setUint16(34, 8, true);
  str(36, 'data'); dv.setUint32(40, n, true);
  for (var i = 0; i < n; i++) out[44 + i] = (s8[i] + 128) & 255;
  return out;
}
/* Float [-1,1] -> 16-Bit-WAV (fuer gerenderte Songs), mono oder stereo interleaved */
function wavWrite16(f32, rate, channels) {
  channels = channels || 1;
  var n = f32.length, out = new Uint8Array(44 + n * 2), dv = new DataView(out.buffer);
  function str(o, s) { for (var i = 0; i < s.length; i++) out[o + i] = s.charCodeAt(i); }
  str(0, 'RIFF'); dv.setUint32(4, 36 + n * 2, true); str(8, 'WAVE');
  str(12, 'fmt '); dv.setUint32(16, 16, true); dv.setUint16(20, 1, true); dv.setUint16(22, channels, true);
  dv.setUint32(24, rate, true); dv.setUint32(28, rate * 2 * channels, true); dv.setUint16(32, 2 * channels, true); dv.setUint16(34, 16, true);
  str(36, 'data'); dv.setUint32(40, n * 2, true);
  for (var i = 0; i < n; i++) { var v = Math.max(-1, Math.min(1, f32[i])); dv.setInt16(44 + i * 2, Math.round(v * 32767), true); }
  return out;
}
/* -> {rate, data: Float32Array mono} */
function wavRead(buf) {
  var dv = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
  function str(o, n) { var s = ''; for (var i = 0; i < n; i++) s += String.fromCharCode(buf[o + i]); return s; }
  if (str(0, 4) !== 'RIFF' || str(8, 4) !== 'WAVE') throw new Error($t('keine WAV-Datei'));
  var p = 12, fmt = null, data = null;
  while (p + 8 <= buf.length) {
    var id = str(p, 4), len = dv.getUint32(p + 4, true);
    if (id === 'fmt ') fmt = { tag: dv.getUint16(p + 8, true), ch: dv.getUint16(p + 10, true), rate: dv.getUint32(p + 12, true), bits: dv.getUint16(p + 22, true) };
    else if (id === 'data') data = { off: p + 8, len: Math.min(len, buf.length - p - 8) };
    p += 8 + len + (len & 1);
  }
  if (!fmt || !data) throw new Error($t('WAV ohne fmt/data'));
  if (fmt.tag === 0xFFFE) fmt.tag = fmt.bits === 32 ? 3 : 1;
  var bps = fmt.bits >> 3, frames = Math.floor(data.len / (bps * fmt.ch)), out = new Float32Array(frames);
  for (var f = 0; f < frames; f++) {
    var s = 0;
    for (var c = 0; c < fmt.ch; c++) {
      var o = data.off + (f * fmt.ch + c) * bps, v;
      if (fmt.tag === 3 && bps === 4) v = dv.getFloat32(o, true);
      else if (bps === 1) v = (buf[o] - 128) / 128;
      else if (bps === 2) v = dv.getInt16(o, true) / 32768;
      else if (bps === 3) v = ((buf[o] | (buf[o + 1] << 8) | (buf[o + 2] << 16)) << 8 >> 8) / 8388608;
      else v = dv.getInt32(o, true) / 2147483648;
      s += v;
    }
    out[f] = s / fmt.ch;
  }
  return { rate: fmt.rate, data: out };
}
function resample(f32, from, to) {
  if (from === to) return f32;
  var n = Math.max(1, Math.round(f32.length * to / from)), out = new Float32Array(n), r = from / to;
  /* einfacher Tiefpass beim Verkleinern */
  var src = f32;
  if (to < from) {
    var k = Math.max(1, Math.round(r)), lp = new Float32Array(f32.length), acc = 0;
    for (var i = 0; i < f32.length; i++) { acc += f32[i]; if (i >= k) acc -= f32[i - k]; lp[i] = acc / Math.min(k, i + 1); }
    src = lp;
  }
  for (var j = 0; j < n; j++) {
    var x = j * r, i0 = Math.floor(x), fr = x - i0, a = src[Math.min(i0, src.length - 1)], b = src[Math.min(i0 + 1, src.length - 1)];
    out[j] = a + (b - a) * fr;
  }
  return out;
}
function floatToS8(f32, normalize) {
  var peak = 0, i;
  if (normalize) { for (i = 0; i < f32.length; i++) peak = Math.max(peak, Math.abs(f32[i])); }
  var g = normalize && peak > 0 ? 0.98 / peak : 1, out = new Int8Array(f32.length);
  for (i = 0; i < f32.length; i++) out[i] = Math.max(-128, Math.min(127, Math.round(f32[i] * g * 128)));
  return out;
}
function s8ToFloat(s8) { var o = new Float32Array(s8.length); for (var i = 0; i < s8.length; i++) o[i] = (s8[i] << 24 >> 24) / 128; return o; }

/* Abspielen eines Float-Puffers */
var actx = null, cur = null;
function playFloat(f32, rate, channels, onEnd) {
  stopAudio();
  if (!actx) actx = new (global.AudioContext || global.webkitAudioContext)();
  if (actx.state === 'suspended') actx.resume();
  channels = channels || 1;
  var frames = f32.length / channels, buf = actx.createBuffer(channels, Math.max(1, frames), rate);
  for (var c = 0; c < channels; c++) {
    var ch = buf.getChannelData(c);
    for (var i = 0; i < frames; i++) ch[i] = f32[i * channels + c];
  }
  var src = actx.createBufferSource(); src.buffer = buf; src.connect(actx.destination);
  src.onended = function () { if (cur === src) cur = null; if (onEnd) onEnd(); };
  src.start(); cur = src;
  return src;
}
function stopAudio() { if (cur) { try { cur.onended = null; cur.stop(); } catch (e) { } cur = null; } }

/* ---------------------------------------------------------------- MIDI */
function vlq(v) { var b = [v & 127]; v >>>= 7; while (v) { b.unshift((v & 127) | 128); v >>>= 7; } return b; }
/* tracks: [{events:[{t, data:[...]}]}] (absolute Ticks) */
function midiWrite(ppq, tracks) {
  var out = [];
  function s(x) { for (var i = 0; i < x.length; i++) out.push(x.charCodeAt(i)); }
  function u32(v) { out.push((v >>> 24) & 255, (v >>> 16) & 255, (v >>> 8) & 255, v & 255); }
  function u16(v) { out.push((v >> 8) & 255, v & 255); }
  s('MThd'); u32(6); u16(1); u16(tracks.length); u16(ppq);
  tracks.forEach(function (tr) {
    var ev = tr.events.slice().sort(function (a, b) { return a.t - b.t || (a.order || 0) - (b.order || 0); });
    var body = [], last = 0;
    ev.forEach(function (e) { vlq(e.t - last).forEach(function (x) { body.push(x); }); e.data.forEach(function (x) { body.push(x); }); last = e.t; });
    body.push(0, 0xFF, 0x2F, 0);
    s('MTrk'); u32(body.length); body.forEach(function (x) { out.push(x); });
  });
  return new Uint8Array(out);
}
/* -> {ppq, tempo (us/Viertel), notes:[{t,dur,ch,key,vel}], names:{ch:name}} */
function midiRead(buf) {
  function str(o, n) { var s = ''; for (var i = 0; i < n; i++) s += String.fromCharCode(buf[o + i]); return s; }
  function be32(o) { return ((buf[o] << 24) | (buf[o + 1] << 16) | (buf[o + 2] << 8) | buf[o + 3]) >>> 0; }
  function be16(o) { return (buf[o] << 8) | buf[o + 1]; }
  if (str(0, 4) !== 'MThd') throw new Error($t('keine MIDI-Datei'));
  var ntr = be16(10), div = be16(12);
  if (div & 0x8000) throw new Error($t('SMPTE-Zeitbasis wird nicht unterstuetzt'));
  var p = 8 + be32(4), notes = [], tempos = [], programs = {}, names = {};
  for (var t = 0; t < ntr && p + 8 <= buf.length; t++) {
    if (str(p, 4) !== 'MTrk') { p += 8 + be32(p + 4); t--; if (p >= buf.length) break; continue; }
    var len = be32(p + 4), q = p + 8, end = q + len, tick = 0, run = 0, open = {};
    var trackName = '', first = notes.length;
    while (q < end) {
      var d = 0, b;
      do { b = buf[q++]; d = (d << 7) | (b & 127); } while (b & 128);
      tick += d;
      var st = buf[q];
      if (st & 0x80) { q++; if (st < 0xF0) run = st; } else st = run;
      var hi = st & 0xF0, ch = st & 15;
      if (st === 0xFF) {
        var type = buf[q++], l = 0; do { b = buf[q++]; l = (l << 7) | (b & 127); } while (b & 128);
        if (type === 0x51) tempos.push({ t: tick, v: (buf[q] << 16) | (buf[q + 1] << 8) | buf[q + 2] });
        if (type === 0x03) trackName = str(q, l);
        q += l;
      } else if (st === 0xF0 || st === 0xF7) {
        var l2 = 0; do { b = buf[q++]; l2 = (l2 << 7) | (b & 127); } while (b & 128); q += l2;
      } else if (hi === 0x90 || hi === 0x80) {
        var key = buf[q++], vel = buf[q++], k = ch * 128 + key;
        if (hi === 0x90 && vel > 0) {
          if (open[k]) { var o0 = open[k]; notes.push({ t: o0.t, dur: Math.max(1, tick - o0.t), ch: ch, key: key, vel: o0.vel }); }
          open[k] = { t: tick, vel: vel };
        } else if (open[k]) {
          var o1 = open[k]; notes.push({ t: o1.t, dur: Math.max(1, tick - o1.t), ch: ch, key: key, vel: o1.vel }); delete open[k];
        }
      } else if (hi === 0xC0) { if (programs[ch] === undefined) programs[ch] = buf[q]; q += 1; }
      else if (hi === 0xD0) q += 1;
      else q += 2;
    }
    for (var kk in open) { var o2 = open[kk]; notes.push({ t: o2.t, dur: Math.max(1, tick - o2.t), ch: (kk / 128) | 0, key: kk % 128, vel: o2.vel }); }
    if (trackName) for (var ni = first; ni < notes.length; ni++) if (names[notes[ni].ch] === undefined) names[notes[ni].ch] = trackName;
    p = end;
  }
  notes.sort(function (a, b) { return a.t - b.t || a.key - b.key; });
  return { ppq: div, tempo: tempos.length ? tempos[0].v : 500000, notes: notes, programs: programs, names: names };
}

G.wavWrite8 = wavWrite8; G.wavWrite16 = wavWrite16; G.wavRead = wavRead; G.resample = resample;
G.floatToS8 = floatToS8; G.s8ToFloat = s8ToFloat; G.playFloat = playFloat; G.stopAudio = stopAudio;
G.midiWrite = midiWrite; G.midiRead = midiRead; G.vlq = vlq;
})(window);
