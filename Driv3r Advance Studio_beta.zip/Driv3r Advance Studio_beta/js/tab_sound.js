/* Driv3r Advance Studio - tab_sound.js : Songs (GBAMOD30), Instrumente, Soundeffekte */
(function (global) {
'use strict';
var G = global.D3S, el = G.el;
var state = { view: 'songs', song: 0, pat: 0, smp: 0, sfx: 0, rate: 10512 };
var SONG_NAMES = [$t('Titel/Menue'), $t('Stereo-Stueck A'), $t('Stereo-Stueck B'), $t('Musik 4'), $t('Musik 5'), $t('Musik 6'), $t('Musik 7'), $t('Musik 8'), $t('Musik 9'), $t('Spiel-Musik 10')];

function info() { return G.soundInfo(); }
function sampleSet(si) {
  var d = G.App.rom.data, arr = [];
  si.samples.forEach(function (s) {
    arr[s.idx] = { data: new Int8Array(d.buffer, d.byteOffset + s.data, s.len), loopStart: s.loopStart, loopLen: s.loopLen, vol: s.vol || 64, fine: s.fine, rel: s.rel };
  });
  return arr;
}
function s8Of(off, len) { var d = G.App.rom.data; return new Int8Array(d.buffer.slice(d.byteOffset + off, d.byteOffset + off + len)); }
function play(f32, rate, ch) { G.playFloat(f32, rate, ch); }
function sampleRateOf(s) { return Math.round(8363 * Math.pow(2, (s.rel + s.fine / 128) / 12)); }

/* ---------------- Sample-Bank neu schreiben */
/* changes: {idx: {data:Int8Array, vol, fine, rel, loopStart, loopLen}} */
function writeBank(changes, label) {
  var si = info(), d = G.App.rom.data;
  var hdr = new Uint8Array(0x1000); hdr.set(d.subarray(si.bank, si.bank + 0x1000));
  var datas = [];
  for (var k = 0; k < 256; k++) {
    var h = k * 16, len = G.u32(hdr, h);
    var s = si.samples.filter(function (x) { return x.idx === k; })[0];
    var c = changes[k];
    if (c) {
      len = c.data.length;
      G.putU32(hdr, h, len);
      G.putU32(hdr, h + 4, ((c.vol & 0xFFFF) << 16 | (c.fine & 0xFF)) >>> 0);
      G.putU32(hdr, h + 8, (((c.loopLen & 0xFFFF) << 16) | (c.loopStart & 0xFFFF)) >>> 0);
      G.putU32(hdr, h + 12, (s ? (s.w3 & 0xFFFF0000) : 0) | (c.rel & 0xFFFF));
      datas.push(new Uint8Array(c.data.buffer, c.data.byteOffset, c.data.length));
    } else if (s) datas.push(d.subarray(s.data, s.data + s.len));
  }
  var total = 0x1000 + datas.reduce(function (a, b) { return a + b.length; }, 0);
  var blob = new Uint8Array(total), p = 0x1000; blob.set(hdr);
  datas.forEach(function (b) { blob.set(b, p); p += b.length; });
  var res = G.replaceBlob(si.bank, si.bankEnd - si.bank, blob, { refs: [G.K.SND_CFG + 16] });
  G.logChange(label + (res.moved ? $t(' - Sample-Bank verschoben nach ') + G.hx(res.off) : ''));
  return res;
}
/* changes: {idx: {data, rate, loop}} */
function writeSfx(changes, label) {
  var si = info(), d = G.App.rom.data, n = si.effects.length;
  var oldEnd = si.sfxBase; si.effects.forEach(function (e) { oldEnd = Math.max(oldEnd, e.data + e.len); });
  var table = new Uint8Array(4 + 24 * n), datas = [], pos = 0;
  G.putU32(table, 0, n);
  si.effects.forEach(function (e, i) {
    var c = changes[i], data = c ? new Uint8Array(c.data.buffer, c.data.byteOffset, c.data.length) : d.subarray(e.data, e.data + e.len);
    var o = 4 + 24 * i;
    G.putU32(table, o, pos); G.putU32(table, o + 4, data.length); G.putU32(table, o + 8, e.vol);
    G.putU32(table, o + 12, c ? (c.loop || 0) : e.loop); G.putU32(table, o + 16, c ? c.rate : e.rate); G.putU32(table, o + 20, e.w5);
    datas.push(data); pos += data.length;
  });
  var blob = new Uint8Array(table.length + pos), p = table.length; blob.set(table);
  datas.forEach(function (b) { blob.set(b, p); p += b.length; });
  var res = G.replaceBlob(si.sfx, oldEnd - si.sfx, blob, { refs: [G.K.SND_CFG + 20] });
  G.logChange(label + (res.moved ? $t(' - Effekt-Tabelle verschoben nach ') + G.hx(res.off) : ''));
  return res;
}
function writeSong(idx, bytes, label) {
  var si = info(), s = si.songs[idx], old = G.parseSong(G.App.rom.data, s.off);
  var res = G.replaceBlob(s.off, old.size, bytes, { refs: G.findRefs(s.off) });
  G.logChange(label + (res.moved ? $t(' (verschoben nach ') + G.hx(res.off) + ')' : ''));
  return res;
}
G.writeSong = writeSong; G.writeBank = writeBank; G.writeSfx = writeSfx;

async function loadWav(targetRate) {
  var f = await G.pickFile('.wav,audio/wav'); if (!f) return null;
  var w = G.wavRead(await G.readFileBytes(f));
  var rate = targetRate || w.rate;
  var data = G.resample(w.data, w.rate, rate);
  return { name: f.name, rate: rate, s8: G.floatToS8(data, true), seconds: data.length / rate };
}
function rateSelect() {
  return G.select([8363, 10512, 13379, 16000, 22050].map(function (r) { return { value: r, label: r + $t(' Hz') }; }), state.rate, function (x) { state.rate = +x; });
}
function waveCanvas(s8) {
  var c = el('canvas', { class: 'wave', width: 600, height: 80 }), cx = c.getContext('2d');
  cx.fillStyle = '#0f1218'; cx.fillRect(0, 0, 600, 80); cx.strokeStyle = '#f5c518'; cx.beginPath();
  var step = Math.max(1, s8.length / 600);
  for (var x = 0; x < 600; x++) {
    var mn = 127, mx = -128;
    for (var i = Math.floor(x * step); i < Math.min(s8.length, Math.floor((x + 1) * step)); i++) { if (s8[i] < mn) mn = s8[i]; if (s8[i] > mx) mx = s8[i]; }
    cx.moveTo(x + 0.5, 40 - mx * 38 / 128); cx.lineTo(x + 0.5, 40 - mn * 38 / 128);
  }
  cx.stroke(); return c;
}

G.registerTab({
  id: 'sound', label: $t('Sound & Musik'), icon: '♫', group: $t('Inhalt'), needsRom: true,
  leave: function () { G.stopAudio(); },
  render: function (v) {
    var si = info();
    v.appendChild(el('h2', { text: $t('Sound & Musik') }));
    v.appendChild(el('p', { class: 'lead', html: $t('Soundtreiber "LS_Play" von Logik State (Mischrate 10512 Hz). Musik liegt als Tracker-Songs (GBAMOD30, bis 8 Kanaele, 64 Zeilen je Pattern) vor, ') +
      $t('die auf ') + si.samples.length + $t(' Instrumente zugreifen. Dazu kommen ') + si.effects.length + $t(' Soundeffekte. Alles 8-Bit-PCM.') }));
    v.appendChild(el('div', { class: 'toolbar' }, [
      G.button($t('Songs (') + si.songs.length + ')', function () { state.view = 'songs'; G.refreshTab(); }, state.view === 'songs' ? 'on' : ''),
      G.button($t('Instrumente (') + si.samples.length + ')', function () { state.view = 'smp'; G.refreshTab(); }, state.view === 'smp' ? 'on' : ''),
      G.button($t('Soundeffekte (') + si.effects.length + ')', function () { state.view = 'sfx'; G.refreshTab(); }, state.view === 'sfx' ? 'on' : ''),
      el('span', { class: 'spacer' }), G.button($t('■ Stopp'), G.stopAudio)
    ]));
    if (state.view === 'songs') renderSongs(v, si); else if (state.view === 'smp') renderSamples(v, si); else renderSfx(v, si);
  }
});

/* ---------------------------------------------------------------- Songs */
function renderSongs(v, si) {
  var split = el('div', { class: 'split' }), side = el('div', { class: 'side', style: { width: '230px' } }), main = el('div', { style: { flex: '1', minWidth: '0' } });
  var list = el('div', { class: 'list' });
  si.songs.forEach(function (s, i) {
    var p = null; try { p = G.parseSong(G.App.rom.data, s.off); } catch (e) { }
    list.appendChild(el('div', { class: 'it' + (i === state.song ? ' sel' : ''), onclick: function () { state.song = i; state.pat = 0; G.refreshTab(); } },
      [el('b', { text: String(i + 1) }), el('span', { class: 'grow', text: SONG_NAMES[i] || ($t('Song ') + (i + 1)) }), el('small', { text: p ? p.nch + $t(' Kan.') : '?' })]));
  });
  side.appendChild(list); split.appendChild(side); split.appendChild(main); v.appendChild(split);
  var s = si.songs[state.song], song;
  try { song = G.parseSong(G.App.rom.data, s.off); } catch (e) { main.appendChild(el('div', { class: 'card err', text: e.message })); return; }
  var smp = sampleSet(si);
  var base = 'song' + (state.song + 1) + '_' + G.hex(s.off, 6);
  main.appendChild(el('div', { class: 'toolbar' }, [
    el('b', { text: $t('Song ') + (state.song + 1) }),
    G.button($t('▶ Abspielen'), function () { G.busy($t('Song wird berechnet ...')); setTimeout(function () { var r = G.renderSong(song, smp, { rate: 22050 }); G.busy(false); play(r.data, r.rate, 2); G.toast($t('Laenge ') + r.seconds.toFixed(1) + ' s'); }, 30); }, 'primary'),
    G.button('WAV', function () { var r = G.renderSong(song, smp, { rate: 22050 }); G.download(base + '.wav', G.wavWrite16(r.data, r.rate, 2), 'audio/wav'); }),
    G.button('MIDI', function () { G.download(base + '.mid', G.songToMidi(song), 'audio/midi'); }),
    G.button($t('GBAMOD roh'), function () { G.download(base + '.gbamod', G.App.rom.data.slice(s.off, s.off + song.size)); }),
    el('span', { class: 'sep' }),
    G.button($t('MIDI importieren ...'), function () { midiImportDialog(state.song, si); }),
    G.button($t('GBAMOD importieren ...'), async function () {
      var f = await G.pickFile('.gbamod,.bin'); if (!f) return;
      try { var b = await G.readFileBytes(f); G.parseSong(b, 0); writeSong(state.song, b, $t('Song ') + (state.song + 1) + $t(' aus ') + f.name); G.toast($t('Song ersetzt.')); G.refreshTab(); }
      catch (e) { G.toast(e.message, 'err'); }
    })
  ]));
  /* Kopfwerte bearbeiten */
  var tempo = el('input', { type: 'number', min: 32, max: 255, value: song.tempo, style: { width: '80px' } });
  var speed = el('input', { type: 'number', min: 1, max: 31, value: song.speed, style: { width: '70px' } });
  var orders = el('input', { value: song.orders.join(' '), style: { width: '100%' }, class: 'mono' });
  main.appendChild(el('div', { class: 'card' }, [
    el('div', { class: 'infobar' }, [el('span', { html: $t('Adresse <b>') + G.hx(s.off) + '</b>' }), el('span', { html: $t('Groesse <b>') + song.size + $t('</b> Byte') }),
      el('span', { html: $t('Kanaele <b>') + song.nch + '</b>' }), el('span', { html: $t('Patterns <b>') + song.npat + '</b>' }),
      el('span', { html: $t('Instrumente <b>') + G.usedSamples(song).join(', ') + '</b>' })]),
    el('div', { class: 'fieldgrid' }, [
      el('label', {}, [$t('Tempo (BPM-Wert)'), tempo]), el('label', {}, [$t('Speed (Ticks/Zeile)'), speed]),
      el('label', { style: { gridColumn: 'span 3' } }, [$t('Reihenfolge der Patterns (Orders)'), orders])
    ]),
    el('div', { class: 'row', style: { marginTop: '8px' } }, [G.button($t('Uebernehmen'), function () {
      var o = orders.value.trim().split(/[\s,]+/).map(Number).filter(function (x) { return !isNaN(x); });
      if (!o.length || o.some(function (x) { return x < 0 || x >= song.npat; })) { G.toast($t('Orders muessen Patternnummern 0-') + (song.npat - 1) + $t(' sein.'), 'err'); return; }
      song.tempo = Math.max(32, Math.min(255, +tempo.value)); song.speed = Math.max(1, Math.min(31, +speed.value)); song.orders = o;
      writeSong(state.song, G.buildSong(song), $t('Song ') + (state.song + 1) + $t(': Tempo/Speed/Orders')); G.toast($t('Gespeichert.')); G.refreshTab();
    })])
  ]));
  /* Pattern-Ansicht */
  var psel = G.select(song.pats.map(function (p, i) { return { value: i, label: $t('Pattern ') + i }; }), state.pat, function (x) { state.pat = +x; G.refreshTab(); });
  var pat = song.pats[state.pat] || [];
  var t = el('table', { class: 'pattern' }), hr = el('tr', {}, [el('th', { text: '#' })]);
  for (var c = 0; c < song.nch; c++) hr.appendChild(el('th', { text: $t('Kanal ') + (c + 1) }));
  t.appendChild(hr);
  for (var r = 0; r < G.ROWS; r++) {
    var tr = el('tr', {}, [el('td', { class: 'rn', text: (r < 10 ? '0' : '') + r })]);
    pat.forEach(function (rows) {
      var x = rows[r], td = el('td');
      td.appendChild(el('span', { class: x.note === G.NOTE_NONE ? 'em' : 'nt', text: G.noteName(x.note) + ' ' }));
      td.appendChild(el('span', { class: x.inst ? 'in' : 'em', text: (x.inst ? (x.inst < 10 ? '0' : '') + x.inst : '..') + ' ' }));
      td.appendChild(el('span', { class: x.vol ? 'vo' : 'em', text: (x.vol ? 'v' + (x.vol - 1 < 10 ? '0' : '') + (x.vol - 1) : '...') + ' ' }));
      td.appendChild(el('span', { class: (x.fx || x.par) ? 'fx' : 'em', text: (x.fx || x.par) ? x.fx.toString(16).toUpperCase() + G.hex(x.par, 2) : '...' }));
      tr.appendChild(td);
    });
    t.appendChild(tr);
  }
  main.appendChild(el('div', { class: 'card' }, [el('div', { class: 'row' }, [el('h4', { text: $t('Pattern-Ansicht'), style: { margin: 0 } }), psel,
    el('span', { class: 'hint', text: $t('Note Instrument Lautstaerke Effekt (A=Lautstaerke-Rutsche, B=Sprung, D=Patternende, 1/2=Tonhoehe)') })]),
    el('div', { style: { overflow: 'auto', maxHeight: '420px', marginTop: '6px' } }, [t])]));
}

function midiImportDialog(songIdx, si) {
  G.pickFile('.mid,.midi').then(async function (f) {
    if (!f) return;
    var mid;
    try { mid = G.midiRead(await G.readFileBytes(f)); } catch (e) { G.toast(e.message, 'err'); return; }
    var chans = {}; mid.notes.forEach(function (n) { chans[n.ch] = (chans[n.ch] || 0) + 1; });
    var map = {}, body = el('div');
    body.appendChild(el('p', { html: '<b>' + f.name + '</b>: ' + mid.notes.length + $t(' Noten, Tempo ') + (60000000 / mid.tempo).toFixed(1) + $t(' BPM. ') +
      $t('Jedem MIDI-Kanal ein Instrument der Sample-Bank zuordnen (0 = weglassen). Das Studio verteilt Akkorde automatisch auf bis zu 8 GBA-Kanaele.') }));
    var smpOpts = [{ value: 0, label: $t('- weglassen -') }].concat(si.samples.map(function (s) { return { value: s.idx + 1, label: $t('Instrument ') + (s.idx + 1) + ' (' + s.len + ' B)' }; }));
    var t = el('table', { class: 'tbl' }, [el('tr', {}, [el('th', { text: $t('MIDI-Kanal') }), el('th', { text: $t('Noten') }), el('th', { text: $t('Instrument') }), el('th', { text: $t('Transponieren') }), el('th', { text: $t('feste Note') })])]);
    Object.keys(chans).map(Number).sort(function (a, b) { return a - b; }).forEach(function (ch, k) {
      map[ch] = { inst: si.samples[k % si.samples.length].idx + 1, transpose: 0, fixedNote: ch === 9 ? 60 : 0 };
      t.appendChild(el('tr', {}, [
        el('td', { text: (ch + 1) + (ch === 9 ? $t(' (Drums)') : '') + (mid.names[ch] ? ' - ' + mid.names[ch] : '') }), el('td', { text: String(chans[ch]) }),
        el('td', {}, [G.select(smpOpts, map[ch].inst, function (x) { map[ch].inst = +x; })]),
        el('td', {}, [el('input', { type: 'number', value: 0, style: { width: '70px' }, onchange: function () { map[ch].transpose = +this.value; } })]),
        el('td', {}, [el('input', { type: 'number', value: map[ch].fixedNote, title: $t('MIDI-Note, 0 = Originalnote'), style: { width: '70px' }, onchange: function () { map[ch].fixedNote = +this.value; } })])
      ]));
    });
    body.appendChild(t);
    var rpb = el('input', { type: 'number', value: 4, min: 1, max: 16, style: { width: '60px' } });
    var maxc = el('input', { type: 'number', value: 8, min: 1, max: 8, style: { width: '60px' } });
    body.appendChild(el('div', { class: 'row', style: { marginTop: '8px' } }, [el('span', { text: $t('Zeilen pro Viertel') }), rpb, el('span', { text: $t('max. Kanaele') }), maxc]));
    body.appendChild(el('p', { class: 'hint', text: $t('Mehr Kanaele kosten im Spiel Rechenzeit. Die Original-Songs nutzen 2-8 Kanaele.') }));
    var ok = await G.modal($t('MIDI importieren -> Song ') + (songIdx + 1), body, [{ label: $t('Abbrechen'), value: false }, { label: $t('Probehoeren'), value: 'test' }, { label: $t('Importieren'), value: true, primary: true }]);
    if (!ok) return;
    var res = G.midiToSong(mid, { rowsPerBeat: +rpb.value, maxCh: +maxc.value, map: map });
    if (ok === 'test') { var r = G.renderSong(res.song, sampleSet(si), { rate: 22050 }); play(r.data, r.rate, 2); G.toast($t('Vorschau (nicht gespeichert). ') + res.warnings.join(' ')); return; }
    var bytes = G.buildSong(res.song);
    try {
      writeSong(songIdx, bytes, $t('Song ') + (songIdx + 1) + $t(' aus MIDI ') + f.name + ' (' + res.voices + $t(' Kanaele)'));
      G.modal($t('MIDI importiert'), '<p>' + res.song.pats.length + $t(' Patterns, ') + res.song.orders.length + $t(' Orders, ') + res.voices + $t(' Kanaele, ') + bytes.length + $t(' Byte.</p>') +
        (res.warnings.length ? '<div class="warnbox">' + res.warnings.join('<br>') + '</div>' : ''));
      G.refreshTab();
    } catch (e) { G.toast(e.message, 'err'); }
  });
}

/* ---------------------------------------------------------------- Instrumente */
function renderSamples(v, si) {
  var split = el('div', { class: 'split' }), side = el('div', { class: 'side', style: { width: '230px' } }), main = el('div', { style: { flex: '1', minWidth: '0' } });
  var list = el('div', { class: 'list' });
  si.samples.forEach(function (s, i) {
    list.appendChild(el('div', { class: 'it' + (i === state.smp ? ' sel' : ''), onclick: function () { state.smp = i; G.refreshTab(); } },
      [el('b', { text: String(s.idx + 1) }), el('span', { class: 'grow', text: (s.len / sampleRateOf(s)).toFixed(2) + ' s' + (s.loopLen ? $t(', Schleife') : '') }), el('small', { text: s.len + ' B' })]));
  });
  side.appendChild(list); split.appendChild(side); split.appendChild(main); v.appendChild(split);
  var s = si.samples[state.smp]; if (!s) return;
  var data = s8Of(s.data, s.len), rate = sampleRateOf(s);
  main.appendChild(el('div', { class: 'toolbar' }, [el('b', { text: $t('Instrument ') + (s.idx + 1) }),
    G.button('▶ C-4', function () { play(G.s8ToFloat(data), rate, 1); }, 'primary'),
    G.button($t('WAV exportieren'), function () { G.download('instrument' + (s.idx + 1) + '.wav', G.wavWrite8(data, rate), 'audio/wav'); }),
    el('span', { class: 'sep' }), el('span', { class: 'mut', text: $t('Import-Rate') }), rateSelect(),
    G.button($t('WAV importieren ...'), async function () {
      try {
        var w = await loadWav(state.rate); if (!w) return;
        var semis = 12 * Math.log2(w.rate / 8363), rel = Math.floor(semis), fine = Math.round((semis - rel) * 128);
        if (fine >= 128) { rel++; fine -= 128; }
        var keepLoop = s.loopLen > 0 && await G.confirmBox($t('Schleife'), $t('Soll das neue Sample als Endlosschleife (ganzes Sample) laufen? Bei "Abbrechen" wird es einmal abgespielt.'), $t('Als Schleife'));
        writeBank(function () { var c = {}; c[s.idx] = { data: w.s8, vol: s.vol, fine: fine, rel: rel, loopStart: 0, loopLen: keepLoop ? Math.min(0xFFFF, w.s8.length) : 0 }; return c; }(), $t('Instrument ') + (s.idx + 1) + $t(' aus ') + w.name);
        G.toast($t('Instrument ersetzt (') + w.seconds.toFixed(2) + ' s @ ' + w.rate + $t(' Hz).')); G.refreshTab();
      } catch (e) { G.toast(e.message, 'err'); }
    })
  ]));
  main.appendChild(waveCanvas(data));
  var vol = el('input', { type: 'number', min: 0, max: 64, value: s.vol }), rel = el('input', { type: 'number', value: s.rel }), fine = el('input', { type: 'number', min: -128, max: 127, value: s.fine });
  var ls = el('input', { type: 'number', min: 0, value: s.loopStart }), ll = el('input', { type: 'number', min: 0, value: s.loopLen });
  main.appendChild(el('div', { class: 'card', style: { marginTop: '10px' } }, [
    el('div', { class: 'infobar' }, [el('span', { html: $t('Kopf <b>') + G.hx(s.hdr) + '</b>' }), el('span', { html: $t('Daten <b>') + G.hx(s.data) + '</b>' }), el('span', { html: 'C-4 = <b>' + rate + $t(' Hz</b>') })]),
    el('div', { class: 'fieldgrid' }, [el('label', {}, [$t('Lautstaerke (0-64)'), vol]), el('label', {}, [$t('Transponierung (Halbtoene)'), rel]), el('label', {}, [$t('Feinstimmung (1/128)'), fine]),
      el('label', {}, [$t('Schleife Start'), ls]), el('label', {}, [$t('Schleife Laenge (0 = aus)'), ll])]),
    el('div', { class: 'row', style: { marginTop: '8px' } }, [G.button($t('Werte uebernehmen'), function () {
      var a = +ls.value, b = +ll.value;
      if (a + b > s.len || a < 0 || b < 0) { G.toast($t('Schleife liegt ausserhalb des Samples (') + s.len + ').', 'err'); return; }
      var d = G.App.rom.data;
      G.putU32(d, s.hdr + 4, ((+vol.value & 0xFFFF) << 16 | ((+fine.value) & 0xFF)) >>> 0);
      G.putU32(d, s.hdr + 8, ((b << 16) | a) >>> 0);
      G.putU32(d, s.hdr + 12, ((s.w3 & 0xFFFF0000) | ((+rel.value) & 0xFFFF)) >>> 0);
      G.logChange($t('Instrument ') + (s.idx + 1) + $t(': Werte')); G.toast($t('Gespeichert.')); G.refreshTab();
    })])
  ]));
}

/* ---------------------------------------------------------------- Effekte */
function renderSfx(v, si) {
  var split = el('div', { class: 'split' }), side = el('div', { class: 'side', style: { width: '230px' } }), main = el('div', { style: { flex: '1', minWidth: '0' } });
  var list = el('div', { class: 'list', style: { maxHeight: 'calc(100vh - 280px)' } });
  si.effects.forEach(function (e, i) {
    list.appendChild(el('div', { class: 'it' + (i === state.sfx ? ' sel' : ''), onclick: function () { state.sfx = i; G.refreshTab(); } },
      [el('b', { text: String(i) }), el('span', { class: 'grow', text: e.len ? (e.len / (e.rate || 10512)).toFixed(2) + ' s' : $t('(leer)') }), el('small', { text: e.rate + $t(' Hz') })]));
  });
  side.appendChild(list); split.appendChild(side); split.appendChild(main); v.appendChild(split);
  var e = si.effects[state.sfx]; if (!e) return;
  var data = s8Of(e.data, e.len);
  main.appendChild(el('div', { class: 'toolbar' }, [el('b', { text: $t('Effekt ') + state.sfx }),
    G.button($t('▶ Abspielen'), function () { if (e.len) play(G.s8ToFloat(data), e.rate || 10512, 1); }, 'primary'),
    G.button($t('WAV exportieren'), function () { G.download('effekt' + state.sfx + '.wav', G.wavWrite8(data, e.rate || 10512), 'audio/wav'); }),
    el('span', { class: 'sep' }), el('span', { class: 'mut', text: $t('Import-Rate') }), rateSelect(),
    G.button($t('WAV importieren ...'), async function () {
      try {
        var w = await loadWav(state.rate); if (!w) return;
        var c = {}; c[state.sfx] = { data: w.s8, rate: w.rate, loop: 0 };
        writeSfx(c, $t('Effekt ') + state.sfx + $t(' aus ') + w.name); G.toast($t('Effekt ersetzt.')); G.refreshTab();
      } catch (er) { G.toast(er.message, 'err'); }
    })
  ]));
  main.appendChild(waveCanvas(data));
  main.appendChild(el('div', { class: 'infobar' }, [el('span', { html: $t('Eintrag <b>') + G.hx(e.ent) + '</b>' }), el('span', { html: $t('Daten <b>') + G.hx(e.data) + '</b>' }),
    el('span', { html: '<b>' + e.len + $t('</b> Byte') }), el('span', { html: $t('Rate <b>') + e.rate + $t(' Hz</b>') }), el('span', { html: $t('Schleife <b>') + G.hx(e.loop, 8) + '</b>' })]));
}

/* ---------------------------------------------------------------- Komplett-Paket */
G.soundExportAll = function (zip) {
  var si = info(), smp = sampleSet(si), n = 0;
  si.songs.forEach(function (s, i) {
    try {
      var song = G.parseSong(G.App.rom.data, s.off);
      zip.add('sound/songs/song' + (i + 1) + '.mid', G.songToMidi(song));
      zip.add('sound/songs/song' + (i + 1) + '.gbamod', G.App.rom.data.slice(s.off, s.off + song.size)); n++;
    } catch (e) { }
  });
  si.samples.forEach(function (s) { zip.add('sound/instrumente/instrument' + (s.idx + 1) + '.wav', G.wavWrite8(s8Of(s.data, s.len), sampleRateOf(s))); n++; });
  si.effects.forEach(function (e, i) { zip.add('sound/effekte/effekt' + i + '.wav', G.wavWrite8(s8Of(e.data, e.len), e.rate || 10512)); n++; });
  return n;
};
G.soundImportFile = function (name, bytes, report, orig) {
  var m;
  if (orig && orig.get(name) && G.bytesEqual(orig.get(name), bytes)) return true;
  if ((m = /sound\/songs\/song(\d+)\.gbamod$/i.exec(name))) {
    var i = +m[1] - 1, s = info().songs[i]; if (!s) return true;
    var old = G.parseSong(G.App.rom.data, s.off);
    if (G.bytesEqual(G.App.rom.data.subarray(s.off, s.off + old.size), bytes)) return true;
    try { G.parseSong(bytes, 0); writeSong(i, bytes, $t('Song ') + (i + 1) + $t(' (Paket)')); report.done.push($t('Song ') + (i + 1)); } catch (e) { report.skip.push(name + ': ' + e.message); }
    return true;
  }
  if ((m = /sound\/songs\/song(\d+)\.mid$/i.exec(name))) {
    var sg = info().songs[+m[1] - 1];
    if (sg && G.bytesEqual(G.songToMidi(G.parseSong(G.App.rom.data, sg.off)), bytes)) return true;
    report.skip.push(name + $t(': geaenderte MIDI bitte im Sound-Tab importieren (Instrumente zuordnen)')); return true;
  }
  if ((m = /sound\/instrumente\/instrument(\d+)\.wav$/i.exec(name))) {
    var si = info(), s2 = si.samples.filter(function (x) { return x.idx === +m[1] - 1; })[0]; if (!s2) return true;
    var w = G.wavRead(bytes), cur = s8Of(s2.data, s2.len), rate = sampleRateOf(s2);
    var s8 = G.floatToS8(G.resample(w.data, w.rate, w.rate), false);
    if (w.rate === rate && s8.length === cur.length && G.bytesEqual(new Uint8Array(s8.buffer), new Uint8Array(cur.buffer))) return true;
    var semis = 12 * Math.log2(w.rate / 8363), rel = Math.floor(semis), fine = Math.round((semis - rel) * 128); if (fine >= 128) { rel++; fine -= 128; }
    var c = {}; c[s2.idx] = { data: s8, vol: s2.vol, fine: fine, rel: rel, loopStart: s2.loopLen ? 0 : 0, loopLen: s2.loopLen ? Math.min(0xFFFF, s8.length) : 0 };
    writeBank(c, $t('Instrument ') + m[1] + $t(' (Paket)')); report.done.push($t('Instrument ') + m[1]); return true;
  }
  if ((m = /sound\/effekte\/effekt(\d+)\.wav$/i.exec(name))) {
    var si2 = info(), e = si2.effects[+m[1]]; if (!e) return true;
    var w2 = G.wavRead(bytes), s82 = G.floatToS8(w2.data, false), cur2 = s8Of(e.data, e.len);
    if (w2.rate === e.rate && s82.length === cur2.length && G.bytesEqual(new Uint8Array(s82.buffer), new Uint8Array(cur2.buffer))) return true;
    var c2 = {}; c2[+m[1]] = { data: s82, rate: w2.rate, loop: 0 };
    writeSfx(c2, $t('Effekt ') + m[1] + $t(' (Paket)')); report.done.push($t('Effekt ') + m[1]); return true;
  }
  return false;
};
})(window);
