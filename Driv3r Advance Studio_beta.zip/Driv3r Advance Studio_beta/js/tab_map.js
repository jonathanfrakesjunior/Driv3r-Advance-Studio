/* Driv3r Advance Studio - tab_map.js : Karteneditor
   Stadt = 128x128 Zellen a 512 Welteinheiten. Rasterwert (3 Byte) = Anzahl<<20 | Halbwort-Offset ab Kartenbasis.
   Zelle: 6 Byte Kopf (x, y, Radius), dann Anzahl x u16 {Typ<<10 | Offset/2}. Typ 0 = Geometrie:
   {u8 nv, u8 nf, nv x (s16 x, s16 h, s16 y), nf x 12 Byte Flaeche {4 Indizes, Normale(3), 3 Byte, u16 Textur}}.
   Textur & 0x1FF = Deskriptor (40 Byte ab Kartenbasis+0xC000: Typ, Atlas, 4 UV-Ecken). */
(function (global) {
'use strict';
var G = global.D3S, el = G.el;
var st = { level: 0, cx: 0, cy: 0, zoom: 0, sel: null, tex: true, walls: false, grid: true, missions: true, lanes: false, desc: 0, timeOfDay: 0,
  mode: 'view', draft: [], rect: null, selFaces: [],
  bld: { h: 420, storey: 208, wallDesc: 116, roofDesc: 96, collision: true, occluders: true },
  gnd: { material: 1, desc: 96, h0: 0, h1: 0, axis: 'y', tile: 128, surface: false, traffic: true } };
var SNAP = 8;
var view = null;

/* ---------------------------------------------------------------- Daten */
function cellVal(L, col, row) { var d = G.App.rom.data, o = L.mapBase + (row * 128 + col) * 3; return d[o] | (d[o + 1] << 8) | (d[o + 2] << 16); }
function cellInfo(L, col, row) {
  var d = G.App.rom.data, v = cellVal(L, col, row);
  if (!v) return { col: col, row: row, empty: true, v: 0 };
  var cnt = v >>> 20, c = L.mapBase + (v & 0xFFFFF) * 2, ents = [];
  for (var i = 0; i < cnt; i++) { var e = G.u16(d, c + 6 + 2 * i); ents.push({ type: e >> 10, off: c + (e & 0x3FF) * 2 }); }
  return { col: col, row: row, v: v, cnt: cnt, at: c, hx: G.u16(d, c) << 16 >> 16, hy: G.u16(d, c + 2) << 16 >> 16, rad: G.u16(d, c + 4), ents: ents };
}
function geoBlock(off) {
  var d = G.App.rom.data, nv = d[off], nf = d[off + 1], verts = [], faces = [];
  for (var i = 0; i < nv; i++) { var o = off + 2 + 6 * i; verts.push({ at: o, x: G.u16(d, o) << 16 >> 16, h: G.u16(d, o + 2) << 16 >> 16, y: G.u16(d, o + 4) << 16 >> 16 }); }
  var fb = off + 2 + 6 * nv;
  for (var f = 0; f < nf; f++) {
    var o2 = fb + 12 * f;
    faces.push({ at: o2, idx: [d[o2], d[o2 + 1], d[o2 + 2], d[o2 + 3]], nx: d[o2 + 4] << 24 >> 24, ny: d[o2 + 5] << 24 >> 24, nz: d[o2 + 6] << 24 >> 24, tex: G.u16(d, o2 + 10) });
  }
  return { off: off, nv: nv, nf: nf, verts: verts, faces: faces };
}
function descriptors(L) {
  var d = G.App.rom.data, out = [];
  for (var k = 0; k < 512; k++) {
    var o = L.mapBase + 0xC000 + 40 * k, uv = [];
    for (var p = 0; p < 4; p++) uv.push([G.u32(d, o + 8 + 8 * p) / 16, G.u32(d, o + 12 + 8 * p) / 16]);
    out.push({ k: k, at: o, type: G.u32(d, o), atlas: d[o + 6], flat: d[o + 4], uv: uv });
  }
  return out;
}
function atlasCanvases(L, tod) {
  var key = 'atl' + L.id + '_' + tod;
  return G.cached(key, function () {
    var P = G.composePal([L.pals[tod]]).bg, cs = [];
    for (var i = 0; i < 3; i++) {
      var off = L.atlases[i];
      try { var raw = G.vcDecode(G.App.rom.data, off).data; cs.push({ canvas: G.idxCanvas(raw, 256, 256, P, false), raw: raw }); } catch (e) { cs.push(null); }
    }
    cs.P = P; return cs;
  });
}
function descColors(L, tod) {
  return G.cached('dcol' + L.id + '_' + tod, function () {
    var at = atlasCanvases(L, tod), P = at.P;
    return descriptors(L).map(function (ds) {
      if (ds.type === 1) return P[ds.flat] || [128, 128, 128];
      var a = at[ds.atlas] || at[0]; if (!a) return [128, 128, 128];
      var us = ds.uv.map(function (q) { return q[0]; }), vs = ds.uv.map(function (q) { return q[1]; });
      var r = 0, g = 0, b = 0, n = 0;
      for (var y = Math.min.apply(null, vs) | 0; y <= Math.max.apply(null, vs); y += 2) for (var x = Math.min.apply(null, us) | 0; x <= Math.max.apply(null, us); x += 2) {
        var c = P[a.raw[(y & 255) * 256 + (x & 255)]]; r += c[0]; g += c[1]; b += c[2]; n++;
      }
      return n ? [r / n | 0, g / n | 0, b / n | 0] : [128, 128, 128];
    });
  });
}
/* alle Flaechen einer Stadt (fuer die Draufsicht) */
function polys(L) {
  return G.cached('polys' + L.id, function () {
    var list = [];
    for (var row = 0; row < 128; row++) for (var col = 0; col < 128; col++) {
      var ci = cellInfo(L, col, row);
      if (ci.empty) continue;
      ci.ents.forEach(function (e) {
        if (e.type !== 0) return;
        var b = geoBlock(e.off);
        /* Gebaeude haben keine Daecher (von der Strasse unsichtbar): Grundriss als Huelle der Waende einzeichnen */
        /* Wandflaechen ueber gemeinsame Punkte zu Gebaeuden gruppieren */
        var par = []; for (var pi = 0; pi < b.nv; pi++) par.push(pi);
        function fnd(x) { while (par[x] !== x) x = par[x] = par[par[x]]; return x; }
        b.faces.forEach(function (f) { if (f.ny > 20) return; var ids = f.idx.filter(function (i) { return i < b.nv; }); for (var k = 1; k < ids.length; k++) par[fnd(ids[k])] = fnd(ids[0]); });
        var groups = {};
        b.faces.forEach(function (f) { if (f.ny > 20) return; f.idx.forEach(function (i) { if (i < b.nv) { var r = fnd(i); (groups[r] = groups[r] || []).push(b.verts[i]); } }); });
        Object.keys(groups).forEach(function (k) {
          var gp = groups[k], hm = 0; gp.forEach(function (v) { if (v.h > hm) hm = v.h; });
          if (gp.length < 3 || hm <= 40) return;
          var hull = convexHull(gp);
          if (hull.length >= 3) list.push({ col: col, row: row, pts: hull, h: hm - 1, up: true, hull: true, tex: 0 });
        });
        b.faces.forEach(function (f, fi) {
          var ids = [], pts = [];
          f.idx.forEach(function (i) { if (i < b.nv && ids.indexOf(i) < 0) { ids.push(i); pts.push(b.verts[i]); } });
          if (pts.length < 3) return;
          var hmax = -1e9; pts.forEach(function (p) { if (p.h > hmax) hmax = p.h; });
          list.push({ col: col, row: row, pts: pts, h: hmax, ny: f.ny, tex: f.tex, up: f.ny > 20, face: f });
        });
      });
    }
    list.sort(function (a, b) { return a.h - b.h; });
    return list;
  });
}
function convexHull(pts) {
  var p = pts.map(function (v) { return v; }).sort(function (a, b) { return a.x - b.x || a.y - b.y; });
  function cr(o, a, b) { return (a.x - o.x) * (b.y - o.y) - (a.y - o.y) * (b.x - o.x); }
  var lo = [], up = [], i;
  for (i = 0; i < p.length; i++) { while (lo.length >= 2 && cr(lo[lo.length - 2], lo[lo.length - 1], p[i]) <= 0) lo.pop(); lo.push(p[i]); }
  for (i = p.length - 1; i >= 0; i--) { while (up.length >= 2 && cr(up[up.length - 2], up[up.length - 1], p[i]) <= 0) up.pop(); up.push(p[i]); }
  up.pop(); lo.pop(); return lo.concat(up);
}
G.mapCellInfo = cellInfo; G.mapGeoBlock = geoBlock;

/* Welt <-> Bild: 1 Welteinheit = 1/512 Zelle */
function w2s(x, y) { return [(x + 32768 - st.cx) * st.zoom + view.w / 2, (32768 - y - st.cy) * st.zoom + view.h / 2]; }
function s2w(sx, sy) { return [(sx - view.w / 2) / st.zoom + st.cx - 32768, 32768 - ((sy - view.h / 2) / st.zoom + st.cy)]; }
G.mapW2S = function (x, y) { return w2s(x, y); };

/* ---------------------------------------------------------------- Zeichnen */
function draw() {
  if (!view) return;
  var L = G.levels()[st.level], cv = view.cv, cx = cv.getContext('2d');
  cx.setTransform(1, 0, 0, 1, 0, 0);
  cx.fillStyle = '#12223a'; cx.fillRect(0, 0, view.w, view.h);
  var ps = polys(L), cols = descColors(L, st.timeOfDay), atl = st.tex ? atlasCanvases(L, st.timeOfDay) : null, dsc = st.tex ? G.cached('desc' + L.id, function () { return descriptors(L); }) : null;
  var wx0 = s2w(0, 0), wx1 = s2w(view.w, view.h);
  var minX = wx0[0] - 600, maxX = wx1[0] + 600, minY = wx1[1] - 600, maxY = wx0[1] + 600;
  var textured = st.tex && st.zoom >= 0.05;
  cx.lineWidth = 1;
  for (var i = 0; i < ps.length; i++) {
    var p = ps[i];
    if (!p.up && !st.walls) continue;
    var q = p.pts[0];
    if (q.x < minX || q.x > maxX || q.y < minY || q.y > maxY) continue;
    var sp = p.pts.map(function (v) { return w2s(v.x, v.y); });
    if (!p.up) { cx.strokeStyle = 'rgba(255,255,255,.35)'; cx.beginPath(); cx.moveTo(sp[0][0], sp[0][1]); for (var k = 1; k < sp.length; k++) cx.lineTo(sp[k][0], sp[k][1]); cx.stroke(); continue; }
    if (p.hull) {
      var g = Math.min(200, 95 + (p.h >> 3));
      cx.beginPath(); cx.moveTo(sp[0][0], sp[0][1]); for (var kh = 1; kh < sp.length; kh++) cx.lineTo(sp[kh][0], sp[kh][1]); cx.closePath();
      cx.fillStyle = 'rgb(' + g + ',' + (g - 6) + ',' + (g - 14) + ')'; cx.fill(); cx.strokeStyle = 'rgba(0,0,0,.45)'; cx.stroke();
      continue;
    }
    var dk = p.tex & 0x1FF, c = cols[dk];
    cx.beginPath(); cx.moveTo(sp[0][0], sp[0][1]); for (var k2 = 1; k2 < sp.length; k2++) cx.lineTo(sp[k2][0], sp[k2][1]); cx.closePath();
    var ds = dsc && dsc[dk];
    if (textured && ds && ds.type === 2 && atl[ds.atlas] && (p.tex & 0x200)) {
      cx.save(); cx.clip();
      /* affine Abbildung UV -> Bildschirm aus den ersten drei Ecken */
      var u0 = ds.uv[0], u1 = ds.uv[1], u2 = ds.uv[2], s0 = sp[0], s1 = sp[1], s2 = sp[2];
      var den = (u1[0] - u0[0]) * (u2[1] - u0[1]) - (u2[0] - u0[0]) * (u1[1] - u0[1]);
      if (Math.abs(den) > 1e-6) {
        var a = ((s1[0] - s0[0]) * (u2[1] - u0[1]) - (s2[0] - s0[0]) * (u1[1] - u0[1])) / den;
        var b = ((s2[0] - s0[0]) * (u1[0] - u0[0]) - (s1[0] - s0[0]) * (u2[0] - u0[0])) / den;
        var c2 = ((s1[1] - s0[1]) * (u2[1] - u0[1]) - (s2[1] - s0[1]) * (u1[1] - u0[1])) / den;
        var d2 = ((s2[1] - s0[1]) * (u1[0] - u0[0]) - (s1[1] - s0[1]) * (u2[0] - u0[0])) / den;
        cx.setTransform(a, c2, b, d2, s0[0] - a * u0[0] - b * u0[1], s0[1] - c2 * u0[0] - d2 * u0[1]);
        cx.drawImage(atl[ds.atlas].canvas, 0, 0);
        cx.setTransform(1, 0, 0, 1, 0, 0);
      } else { cx.fillStyle = 'rgb(' + c.join(',') + ')'; cx.fill(); }
      cx.restore();
    } else { cx.fillStyle = 'rgb(' + c.join(',') + ')'; cx.fill(); }
  }
  /* Raster */
  if (st.grid && st.zoom * 512 >= 10) {
    cx.strokeStyle = 'rgba(255,255,255,.12)'; cx.beginPath();
    for (var g = 0; g <= 128; g++) {
      var a1 = w2s(g * 512 - 32768, 32768), a2 = w2s(g * 512 - 32768, -32768); cx.moveTo(a1[0], a1[1]); cx.lineTo(a2[0], a2[1]);
      var b1 = w2s(-32768, 32768 - g * 512), b2 = w2s(32768, 32768 - g * 512); cx.moveTo(b1[0], b1[1]); cx.lineTo(b2[0], b2[1]);
    }
    cx.stroke();
  }
  if (st.sel) {
    var t0 = w2s(st.sel.col * 512 - 32768, 32768 - st.sel.row * 512), t1 = w2s((st.sel.col + 1) * 512 - 32768, 32768 - (st.sel.row + 1) * 512);
    cx.strokeStyle = '#f5c518'; cx.lineWidth = 2; cx.strokeRect(t0[0], t0[1], t1[0] - t0[0], t1[1] - t0[1]);
  }
  if (st.lanes) drawLanes(cx, w2s);
  if (st.missions && G.drawMissionOverlay) G.drawMissionOverlay(cx, st.level, w2s, st.zoom);
  drawBuildOverlay(cx);
}
function drawBuildOverlay(cx) {
  cx.setTransform(1, 0, 0, 1, 0, 0);
  if (st.mode === 'building' && st.draft.length) {
    cx.strokeStyle = '#57d98a'; cx.fillStyle = 'rgba(87,217,138,.25)'; cx.lineWidth = 2; cx.beginPath();
    st.draft.forEach(function (p, i) { var q = w2s(p[0], p[1]); if (i) cx.lineTo(q[0], q[1]); else cx.moveTo(q[0], q[1]); });
    if (st.hover) { var hq = w2s(st.hover[0], st.hover[1]); cx.lineTo(hq[0], hq[1]); }
    cx.closePath(); cx.fill(); cx.stroke();
    st.draft.forEach(function (p) { var q = w2s(p[0], p[1]); cx.fillStyle = '#fff'; cx.fillRect(q[0] - 3, q[1] - 3, 6, 6); });
  }
  if (st.mode === 'ground' && st.rect) {
    var a = w2s(st.rect[0], st.rect[1]), b = w2s(st.rect[2], st.rect[3]);
    cx.strokeStyle = '#4da3ff'; cx.fillStyle = 'rgba(77,163,255,.25)'; cx.lineWidth = 2;
    cx.fillRect(Math.min(a[0], b[0]), Math.min(a[1], b[1]), Math.abs(b[0] - a[0]), Math.abs(b[1] - a[1]));
    cx.strokeRect(Math.min(a[0], b[0]), Math.min(a[1], b[1]), Math.abs(b[0] - a[0]), Math.abs(b[1] - a[1]));
  }
  if (st.selFaces.length && st.sel) {
    var L = G.levels()[st.level], ci = cellInfo(L, st.sel.col, st.sel.row);
    if (ci.empty) return;
    var e0 = ci.ents[0]; if (!e0 || e0.type !== 0) return;
    var gb = geoBlock(e0.off);
    cx.strokeStyle = '#ff6b6b'; cx.lineWidth = 2.5;
    st.selFaces.forEach(function (fi) {
      var f = gb.faces[fi]; if (!f) return;
      cx.beginPath();
      f.idx.forEach(function (i, k) { var v = gb.verts[i]; if (!v) return; var q = w2s(v.x, v.y); if (k) cx.lineTo(q[0], q[1]); else cx.moveTo(q[0], q[1]); });
      cx.closePath(); cx.stroke();
    });
  }
}
function snap(w) { return [Math.round(w[0] / SNAP) * SNAP, Math.round(w[1] / SNAP) * SNAP]; }
/* Flaechen der gewaehlten Zelle unter dem Mauszeiger (Draufsicht) */
function hitFaces(L, col, row, wx, wy) {
  var ci = cellInfo(L, col, row); if (ci.empty || !ci.ents.length || ci.ents[0].type !== 0) return [];
  var b = geoBlock(ci.ents[0].off), hits = [];
  b.faces.forEach(function (f, fi) {
    var pts = []; f.idx.forEach(function (i) { var v = b.verts[i]; if (v && pts.indexOf(v) < 0) pts.push(v); });
    if (pts.length < 2) return;
    if (f.ny > 20) {
      var inside = false;
      for (var i = 0, j = pts.length - 1; i < pts.length; j = i++) {
        var xi = pts[i].x, yi = pts[i].y, xj = pts[j].x, yj = pts[j].y;
        if (((yi > wy) !== (yj > wy)) && (wx < (xj - xi) * (wy - yi) / ((yj - yi) || 1e-9) + xi)) inside = !inside;
      }
      if (inside) hits.push({ fi: fi, h: Math.max.apply(null, pts.map(function (p) { return p.h; })), up: true });
    } else {
      var a = pts[0], c = pts[1], dx = c.x - a.x, dy = c.y - a.y, L2 = dx * dx + dy * dy || 1;
      var t = Math.max(0, Math.min(1, ((wx - a.x) * dx + (wy - a.y) * dy) / L2)), px = a.x + t * dx - wx, py = a.y + t * dy - wy;
      if (Math.hypot(px, py) < 6 / Math.max(st.zoom, 0.01)) hits.push({ fi: fi, h: 99999, up: false });
    }
  });
  hits.sort(function (p, q) { return q.h - p.h; });
  return hits;
}
G.mapRedraw = function () { draw(); };

/* ---------------------------------------------------------------- Tab */
G.registerTab({
  id: 'map', label: $t('Karteneditor'), icon: '▦', group: $t('Welt'), needsRom: true,
  leave: function () { if (view && view.ro) view.ro.disconnect(); view = null; },
  render: function (v) {
    var lv = G.levels(), L = lv[st.level];
    v.appendChild(el('h2', { text: $t('Karteneditor') }));
    v.appendChild(el('p', { class: 'lead', html: $t('Draufsicht aus den echten 3D-Daten (Dach- und Bodenflaechen, texturiert). Mausrad = Zoom, Ziehen = verschieben, Klick = Zelle waehlen. ') +
      $t('Rechts unter <b>Bauen</b>: neue Gebaeude, Strassen (mit KI-Verkehr), Plaetze, Wasser, Rampen und Bruecken; einzelne Flaechen loeschen, verschieben, neu texturieren. Dazu Zellen leeren/wiederherstellen und Textur-Deskriptoren. Ebenen: Missionspunkte (Tab "Missionen") und Verkehrsspuren.') }));
    var tb = el('div', { class: 'toolbar' }, [
      G.select(lv.map(function (l, i) { return { value: i, label: l.name }; }), st.level, function (x) { st.level = +x; st.sel = null; st.zoom = 0; G.refreshTab(); }),
      G.select([{ value: 0, label: $t('Tag') }, { value: 1, label: $t('Abend') }, { value: 2, label: $t('Nacht') }], st.timeOfDay, function (x) { st.timeOfDay = +x; draw(); }),
      chk($t('Texturen'), 'tex'), chk($t('Waende'), 'walls'), chk($t('Raster'), 'grid'), chk($t('Missionen'), 'missions'), chk($t('Verkehr'), 'lanes'),
      el('span', { class: 'spacer' }),
      G.button($t('Gesamtansicht'), function () { st.zoom = 0; fit(); draw(); }),
      G.button($t('Karte als PNG'), exportPng)
    ]);
    v.appendChild(tb);
    var wrap = el('div', { class: 'split' });
    var stage = el('div', { id: 'mapstage' }), cv = el('canvas', { id: 'mapcv' });
    stage.appendChild(cv);
    var side = el('div', { class: 'side', style: { width: '330px', maxHeight: 'calc(100vh - 250px)', overflow: 'auto' } });
    wrap.appendChild(stage); wrap.appendChild(side); v.appendChild(wrap);
    var status = el('div', { class: 'mapstatus', text: $t('Bereit') });
    v.appendChild(status);
    view = { cv: cv, stage: stage, w: 800, h: 600, status: status, side: side };
    function resize() { if (!view || view.cv !== cv) return; var r = stage.getBoundingClientRect(); view.w = cv.width = Math.max(100, r.width | 0); view.h = cv.height = Math.max(100, r.height | 0); if (!st.zoom || st.auto) fit(); draw(); }
    view.ro = new ResizeObserver(resize); view.ro.observe(stage);
    setTimeout(resize, 0);
    bindMouse(cv);
    renderSide();
  }
});
function chk(label, key) {
  return el('label', { class: 'chk' }, [el('input', { type: 'checkbox', checked: st[key], onchange: function () { st[key] = this.checked; draw(); } }), label]);
}
function fit() {
  var L = G.levels()[st.level], minc = 128, maxc = 0, minr = 128, maxr = 0;
  for (var r = 0; r < 128; r++) for (var c = 0; c < 128; c++) if (cellVal(L, c, r)) { minc = Math.min(minc, c); maxc = Math.max(maxc, c); minr = Math.min(minr, r); maxr = Math.max(maxr, r); }
  if (minc > maxc) { minc = 0; maxc = 127; minr = 0; maxr = 127; }
  st.cx = ((minc + maxc + 1) / 2) * 512; st.cy = ((minr + maxr + 1) / 2) * 512;
  st.zoom = Math.min(view.w / ((maxc - minc + 2) * 512), view.h / ((maxr - minr + 2) * 512));
  st.auto = true;
}
var drag = null, winBound = false;
function bindMouse(cv) {
  drag = null;
  cv.onwheel = function (e) {
    e.preventDefault();
    var r = cv.getBoundingClientRect(), mx = e.clientX - r.left, my = e.clientY - r.top, before = s2w(mx, my);
    st.auto = false;
    st.zoom *= e.deltaY < 0 ? 1.25 : 0.8; st.zoom = Math.max(0.005, Math.min(2, st.zoom));
    var after = s2w(mx, my); st.cx -= (after[0] - before[0]); st.cy += (after[1] - before[1]);
    draw();
  };
  cv.ondblclick = function (e) { if (st.mode === 'building') { e.preventDefault(); finishBuilding(); } };
  cv.oncontextmenu = function (e) { if (st.mode !== 'view') { e.preventDefault(); if (st.mode === 'building') finishBuilding(); } };
  cv.onmousedown = function (e) {
    var r = cv.getBoundingClientRect();
    if (e.button === 0 && st.mode === 'ground') { var w0 = snap(s2w(e.clientX - r.left, e.clientY - r.top)); st.rect = [w0[0], w0[1], w0[0], w0[1]]; drag = { rect: true, x: e.clientX, y: e.clientY }; return; }
    var hit = G.missionHitTest ? G.missionHitTest(st.level, e.clientX - r.left, e.clientY - r.top, w2s) : null;
    drag = { x: e.clientX, y: e.clientY, cx: st.cx, cy: st.cy, moved: false, mission: st.missions ? hit : null };
  };
  if (winBound) return;
  winBound = true;
  window.addEventListener('keydown', function (e) {
    if (!view || G.App.active !== 'map' || /INPUT|TEXTAREA|SELECT/.test((e.target || {}).tagName || '')) return;
    if (e.key === 'Escape') { st.draft = []; st.rect = null; st.selFaces = []; renderSide(); draw(); }
    if (e.key === 'Enter' && st.mode === 'building') finishBuilding();
    if (e.key === 'Backspace' && st.mode === 'building' && st.draft.length) { e.preventDefault(); st.draft.pop(); renderSide(); draw(); }
    if (e.key === 'Delete' && st.mode === 'select' && st.selFaces.length) deleteSelFaces();
  });
  window.addEventListener('mousemove', function (e) {
    if (!view) return;
    var cv = view.cv;
    var r = cv.getBoundingClientRect(), w = s2w(e.clientX - r.left, e.clientY - r.top);
    if (e.target === cv) view.status.textContent = $t('Welt X ') + Math.round(w[0]) + '  Y ' + Math.round(w[1]) + $t('  |  Zelle Spalte ') + ((w[0] + 32768) >> 9) + $t(', Zeile ') + ((32768 - w[1]) >> 9) + $t('  |  Zoom ') + (st.zoom * 512).toFixed(1) + $t(' px/Zelle');
    if (st.mode === 'building' && e.target === cv) { st.hover = snap(w); draw(); }
    if (!drag) return;
    if (drag.rect) { var ws = snap(w); st.rect[2] = ws[0]; st.rect[3] = ws[1]; draw(); return; }
    if (Math.abs(e.clientX - drag.x) + Math.abs(e.clientY - drag.y) > 3) drag.moved = true;
    if (drag.mission && drag.moved) { G.missionDrag(drag.mission, Math.round(w[0]), Math.round(w[1])); draw(); return; }
    if (drag.moved) { st.auto = false; st.cx = drag.cx - (e.clientX - drag.x) / st.zoom; st.cy = drag.cy - (e.clientY - drag.y) / st.zoom; draw(); }
  });
  window.addEventListener('mouseup', function (e) {
    if (!drag || !view) { drag = null; return; }
    var cv = view.cv;
    if (drag.rect) { drag = null; renderSide(); draw(); return; }
    if (drag.mission && drag.moved) { G.missionDragEnd(drag.mission); }
    else if (!drag.moved && e.button === 0) {
      var r = cv.getBoundingClientRect(), w = s2w(e.clientX - r.left, e.clientY - r.top);
      var col = (w[0] + 32768) >> 9, row = (32768 - w[1]) >> 9;
      if (st.mode === 'building') { if (e.detail < 2) st.draft.push(snap(w)); renderSide(); draw(); drag = null; return; }
      if (col >= 0 && col < 128 && row >= 0 && row < 128) {
        if (st.mode === 'select') {
          var L = G.levels()[st.level];
          if (!st.sel || st.sel.col !== col || st.sel.row !== row) st.selFaces = [];
          st.sel = { col: col, row: row };
          var hits = hitFaces(L, col, row, w[0], w[1]);
          if (hits.length) {
            var fi = hits[0].fi, k = st.selFaces.indexOf(fi);
            if (e.shiftKey) { if (k >= 0) st.selFaces.splice(k, 1); else st.selFaces.push(fi); }
            else st.selFaces = [fi];
          } else if (!e.shiftKey) st.selFaces = [];
        } else { st.sel = { col: col, row: row }; st.selFaces = []; }
        renderSide(); draw();
      }
    }
    drag = null;
  });
}

/* ---------------------------------------------------------------- Seitenleiste */
function renderSide() {
  if (!view) return;
  var side = G.clear(view.side), L = G.levels()[st.level];
  buildCard(side, L);
  if (st.mode === 'select' && st.sel && st.selFaces.length) faceCard(side, L);
  if (!st.sel) {
    side.appendChild(el('div', { class: 'card' }, [el('h4', { text: L.name }), el('div', { class: 'kv' }, [
      el('b', { text: $t('Kartenbasis') }), el('span', { text: G.hx(L.mapBase) }),
      el('b', { text: $t('Belegte Zellen') }), el('span', { text: String(countCells(L)) }),
      el('b', { text: $t('Flaechen') }), el('span', { text: String(polys(L).length) })
    ]), el('p', { class: 'hint', text: $t('Eine Zelle anklicken, um sie zu bearbeiten.') })]));
    descEditor(side, L);
    return;
  }
  var ci = cellInfo(L, st.sel.col, st.sel.row), orig = origVal(L, st.sel.col, st.sel.row);
  var card = el('div', { class: 'card' }, [el('h4', { text: $t('Zelle ') + st.sel.col + ' / ' + st.sel.row })]);
  if (ci.empty) card.appendChild(el('p', { class: 'hint', text: $t('Leere Zelle (Wasser/Nichts).') }));
  else {
    card.appendChild(el('div', { class: 'kv' }, [
      el('b', { text: $t('Daten') }), el('span', { class: 'mono', text: G.hx(ci.at) }),
      el('b', { text: $t('Mittelpunkt') }), el('span', { text: ci.hx + ', ' + ci.hy + ' (r ' + ci.rad + ')' }),
      el('b', { text: $t('Bloecke') }), el('span', { text: ci.ents.map(function (e) { return [$t('Geometrie'), $t('Verdeckung'), $t('Detail'), $t('Objekte'), $t('Kollision'), 'KI'][e.type] || ($t('Typ') + e.type); }).join(', ') })
    ]));
  }
  card.appendChild(el('div', { class: 'row', style: { marginTop: '8px' } }, [
    !ci.empty ? G.button($t('Zelle leeren'), async function () {
      if (!await G.confirmBox($t('Zelle leeren'), $t('Alle Gebaeude, Strassen und Kollisionen dieser Zelle entfernen? (Wiederherstellen ist jederzeit moeglich.)'), $t('Leeren'))) return;
      setCell(L, st.sel.col, st.sel.row, 0); G.logChange(L.name + $t(' Zelle ') + st.sel.col + '/' + st.sel.row + $t(' geleert')); changed();
    }, 'danger') : null,
    ci.v !== orig ? G.button($t('Original wiederherstellen'), function () { setCell(L, st.sel.col, st.sel.row, orig); G.logChange(L.name + $t(' Zelle ') + st.sel.col + '/' + st.sel.row + $t(' wiederhergestellt')); changed(); }) : null
  ]));
  side.appendChild(card);
  if (ci.empty) return;
  ci.ents.filter(function (e) { return e.type === 0; }).forEach(function (e, bi) {
    var b = geoBlock(e.off);
    var hs = b.verts.map(function (v) { return v.h; }), hmin = Math.min.apply(null, hs), hmax = Math.max.apply(null, hs);
    var fac = el('input', { type: 'number', value: 100, step: 5, style: { width: '70px' } }), add = el('input', { type: 'number', value: 0, style: { width: '70px' } });
    var roofTex = el('input', { type: 'number', min: 0, max: 511, value: '', placeholder: $t('Nr.'), style: { width: '70px' } });
    var wallTex = el('input', { type: 'number', min: 0, max: 511, value: '', placeholder: $t('Nr.'), style: { width: '70px' } });
    var used = {}; b.faces.forEach(function (f) { used[f.tex & 0x1FF] = 1; });
    side.appendChild(el('div', { class: 'card' }, [
      el('h4', { text: $t('Geometrie ') + (bi + 1) + ': ' + b.nv + $t(' Punkte, ') + b.nf + $t(' Flaechen') }),
      el('div', { class: 'hint', text: $t('Hoehe ') + hmin + $t(' bis ') + hmax + $t(' | Deskriptoren: ') + Object.keys(used).join(', ') }),
      el('div', { class: 'row tight', style: { marginTop: '6px' } }, [el('span', { text: $t('Hoehe %') }), fac, el('span', { text: '+' }), add,
        G.button($t('Anwenden'), function () {
          var f = +fac.value / 100, a = +add.value, d = G.App.rom.data;
          b.verts.forEach(function (v) { if (v.h > hmin || a) { var nh = Math.round(hmin + (v.h - hmin) * f + (v.h > hmin ? a : 0)); G.putU16(d, v.at + 2, Math.max(-32768, Math.min(32767, nh)) & 0xFFFF); } });
          G.logChange(L.name + $t(' Zelle ') + st.sel.col + '/' + st.sel.row + $t(': Hoehe x') + f + ' +' + a); changed();
        })]),
      el('div', { class: 'row tight', style: { marginTop: '6px' } }, [el('span', { text: $t('Daecher') }), roofTex, el('span', { text: $t('Waende') }), wallTex,
        G.button($t('Textur setzen'), function () {
          var d = G.App.rom.data, n = 0;
          b.faces.forEach(function (f) {
            var target = f.ny > 20 ? roofTex.value : wallTex.value;
            if (target === '') return;
            G.putU16(d, f.at + 10, (f.tex & ~0x1FF) | (+target & 0x1FF) | 0x200); n++;
          });
          G.logChange(L.name + $t(' Zelle ') + st.sel.col + '/' + st.sel.row + ': ' + n + $t(' Flaechen neu texturiert')); changed();
        })]),
      el('p', { class: 'hint', text: $t('Hoehenaenderungen betreffen nur die Grafik; Fahrbahn/Kollision bleiben, wie sie sind. Deskriptor-Nummern siehe unten.') })
    ]));
  });
  descEditor(side, L);
}
/* ---------------------------------------------------------------- Bauen */
function descPreview(L, k, size) {
  var ds = G.cached('desc' + L.id, function () { return descriptors(L); })[k], at = atlasCanvases(L, st.timeOfDay);
  var c = el('canvas', { width: size, height: size, title: $t('Deskriptor ') + k, style: { width: size + 'px', height: size + 'px', imageRendering: 'pixelated', border: '1px solid #333b4b', verticalAlign: 'middle' } });
  if (!ds) return c;
  var cx = c.getContext('2d');
  if (ds.type === 2 && at[ds.atlas]) {
    var us = ds.uv.map(function (q) { return q[0]; }), vs = ds.uv.map(function (q) { return q[1]; });
    var x0 = Math.min.apply(null, us), y0 = Math.min.apply(null, vs);
    cx.drawImage(at[ds.atlas].canvas, x0, y0, Math.max(1, Math.max.apply(null, us) - x0), Math.max(1, Math.max.apply(null, vs) - y0), 0, 0, size, size);
  } else if (ds.type === 1) { cx.fillStyle = 'rgb(' + (at.P[ds.flat] || [0, 0, 0]).join(',') + ')'; cx.fillRect(0, 0, size, size); }
  return c;
}
function descInput(L, obj, key) {
  var wrap = el('span', { class: 'row tight' }), prev = descPreview(L, obj[key], 28);
  var inp = el('input', { type: 'number', min: 0, max: 511, value: obj[key], style: { width: '64px' }, onchange: function () { obj[key] = Math.max(0, Math.min(511, +this.value | 0)); var np = descPreview(L, obj[key], 28); wrap.replaceChild(np, prev); prev = np; } });
  wrap.appendChild(inp); wrap.appendChild(prev);
  wrap.appendChild(G.button($t('Waehlen'), function () { pickDesc(L, obj[key], function (k) { obj[key] = k; inp.value = k; var np = descPreview(L, k, 28); wrap.replaceChild(np, prev); prev = np; }); }));
  return wrap;
}
function pickDesc(L, cur, cb) {
  var grid = el('div', { style: { display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(52px,1fr))', gap: '4px', maxHeight: '60vh', overflow: 'auto' } });
  var ds = G.cached('desc' + L.id, function () { return descriptors(L); });
  ds.forEach(function (d, k) {
    if (d.type !== 1 && d.type !== 2) return;
    grid.appendChild(el('div', { style: { textAlign: 'center', cursor: 'pointer', border: '2px solid ' + (k === cur ? '#f5c518' : 'transparent'), borderRadius: '5px' }, onclick: function () { cb(k); G.$('modal').classList.remove('show'); } },
      [descPreview(L, k, 44), el('div', { style: { fontSize: '10px', color: '#98a2b5' }, text: String(k) })]));
  });
  G.modal($t('Textur (Deskriptor) waehlen'), grid, [{ label: $t('Schliessen'), value: false }]);
}
/* KI-Verkehrsspuren (Pfeile in Fahrtrichtung, grau = keine Autos erzeugen) */
function drawLanes(cx, w2s) {
  var L = G.levels()[st.level], lanes;
  try { lanes = G.cached('lanes' + L.id + '_' + L.mapBase, function () { return G.cityLanes(L); }); } catch (e) { return; }
  cx.lineWidth = 1.5;
  lanes.forEach(function (l) {
    if (l.nodes.length < 2) return;
    cx.strokeStyle = l.flags & 0x80 ? 'rgba(180,180,180,0.7)' : 'rgba(0,230,255,0.85)';
    cx.beginPath();
    l.nodes.forEach(function (v, i) { var p = w2s(v[0], v[2]); if (i) cx.lineTo(p[0], p[1]); else cx.moveTo(p[0], p[1]); });
    cx.stroke();
    var a = w2s(l.nodes[l.nodes.length - 2][0], l.nodes[l.nodes.length - 2][2]), b = w2s(l.nodes[l.nodes.length - 1][0], l.nodes[l.nodes.length - 1][2]);
    var ang = Math.atan2(b[1] - a[1], b[0] - a[0]);
    cx.beginPath(); cx.moveTo(b[0], b[1]); cx.lineTo(b[0] - 7 * Math.cos(ang - 0.45), b[1] - 7 * Math.sin(ang - 0.45));
    cx.moveTo(b[0], b[1]); cx.lineTo(b[0] - 7 * Math.cos(ang + 0.45), b[1] - 7 * Math.sin(ang + 0.45)); cx.stroke();
  });
}
function buildCard(side, L) {
  var prepared = G.cityIsPrepared(L), c = prepared ? G.cityCtx(L) : null;
  var modes = el('div', { class: 'row tight' });
  [['view', $t('Ansehen')], ['select', $t('Flaechen')], ['building', $t('Gebaeude')], ['ground', $t('Boden/Strasse')]].forEach(function (m) {
    modes.appendChild(G.button(m[1], function () { st.mode = m[0]; st.draft = []; st.rect = null; if (m[0] !== 'select') st.selFaces = []; view.cv.style.cursor = m[0] === 'view' ? 'crosshair' : 'cell'; renderSide(); draw(); }, st.mode === m[0] ? 'on' : ''));
  });
  var card = el('div', { class: 'card' }, [el('h4', { text: $t('Bauen') }), modes]);
  if (prepared) card.appendChild(el('div', { class: 'hint', style: { marginTop: '6px' }, text: $t('Bau-Kopie aktiv bei ') + G.hx(L.mapBase) + $t(' - frei: ') + ((c.end - c.heap) / 1024 | 0) + $t(' KB Zellen, ') + ((c.fMax - c.fEnd) / 30 | 0) + $t(' Flaechen, ') + ((c.tMax - c.tEnd) / 12 | 0) + $t(' Waende') }));
  else card.appendChild(el('div', { class: 'hint', style: { marginTop: '6px' }, text: $t('Beim ersten Bauen wird die Stadt automatisch ans ROM-Ende kopiert (ROM wird 16 MB). Das Original bleibt erhalten.') }));
  var B = st.bld, Gd = st.gnd;
  function num(obj, key, min, max, w) { return el('input', { type: 'number', min: min, max: max, value: obj[key], style: { width: (w || 70) + 'px' }, onchange: function () { obj[key] = +this.value; } }); }
  function cb(obj, key, label) { return el('label', { class: 'chk' }, [el('input', { type: 'checkbox', checked: obj[key], onchange: function () { obj[key] = this.checked; } }), label]); }
  if (st.mode === 'building') {
    card.appendChild(el('p', { class: 'hint', html: $t('Eckpunkte auf die Karte klicken (Raster ') + SNAP + $t('). <b>Doppelklick, Rechtsklick oder Enter</b> = bauen, Ruecktaste = letzten Punkt entfernen, Esc = abbrechen. Grundriss muss konvex sein.') }));
    card.appendChild(el('div', { class: 'fieldgrid' }, [
      el('label', {}, [$t('Hoehe'), num(B, 'h', 16, 4000)]), el('label', {}, [$t('Stockwerkhoehe'), num(B, 'storey', 32, 1000)])]));
    card.appendChild(el('div', { class: 'row tight', style: { marginTop: '6px' } }, [el('span', { text: $t('Fassade') }), descInput(L, B, 'wallDesc')]));
    card.appendChild(el('div', { class: 'row tight', style: { marginTop: '4px' } }, [el('span', { text: $t('Dach') }), descInput(L, B, 'roofDesc')]));
    card.appendChild(el('div', { class: 'row', style: { marginTop: '6px' } }, [cb(B, 'collision', $t('massiv (Kollision)')), cb(B, 'occluders', $t('Verdeckung (schneller)'))]));
    card.appendChild(el('div', { class: 'row', style: { marginTop: '6px' } }, [
      el('span', { class: 'mut', text: st.draft.length + $t(' Punkte') }),
      G.button($t('Bauen'), finishBuilding, 'primary'), G.button($t('Verwerfen'), function () { st.draft = []; renderSide(); draw(); })]));
  }
  if (st.mode === 'ground') {
    card.appendChild(el('p', { class: 'hint', html: $t('Rechteck auf der Karte aufziehen. Strassen, Plaetze, Gras, Wasser, Bruecken (Hoehe &gt; 0 ueber Wasser) und Rampen (unterschiedliche Anfangs-/Endhoehe). Die neue Flaeche bestimmt dort den Boden fuer Autos und Figuren.') }));
    card.appendChild(el('div', { class: 'fieldgrid' }, [
      el('label', {}, [$t('Material'), G.select([{ value: 1, label: $t('Strasse') }, { value: 2, label: $t('Gelaende/Gras') }, { value: 3, label: $t('Wasser') }, { value: 0, label: $t('nur Grafik') }], Gd.material, function (x) { Gd.material = +x; })]),
      el('label', {}, [$t('Kachelgroesse'), num(Gd, 'tile', 32, 512)]),
      el('label', {}, [$t('Hoehe Anfang'), num(Gd, 'h0', -2000, 4000)]), el('label', {}, [$t('Hoehe Ende'), num(Gd, 'h1', -2000, 4000)]),
      el('label', {}, [$t('Rampe entlang'), G.select([{ value: 'y', label: $t('Sued -> Nord') }, { value: 'x', label: $t('West -> Ost') }], Gd.axis, function (x) { Gd.axis = x; })])]));
    card.appendChild(el('div', { class: 'row tight', style: { marginTop: '6px' } }, [el('span', { text: $t('Textur') }), descInput(L, Gd, 'desc')]));
    card.appendChild(el('div', { class: 'row', style: { marginTop: '6px' } }, [cb(Gd, 'surface', $t('zusaetzliche Kollisionsflaeche (hohe Bruecke/Rampe)'))]));
    card.appendChild(el('div', { class: 'row', style: { marginTop: '4px' } }, [cb(Gd, 'traffic', $t('Verkehr (KI-Autos, nur bei Strasse ab 64 breit)'))]));
    card.appendChild(el('div', { class: 'row', style: { marginTop: '6px' } }, [
      el('span', { class: 'mut', text: st.rect ? Math.abs(st.rect[2] - st.rect[0]) + ' x ' + Math.abs(st.rect[3] - st.rect[1]) : $t('kein Rechteck') }),
      G.button($t('Bauen'), finishGround, 'primary'), G.button($t('Verwerfen'), function () { st.rect = null; renderSide(); draw(); })]));
  }
  if (st.mode === 'select') card.appendChild(el('p', { class: 'hint', text: $t('Flaeche in einer Zelle anklicken (Umschalt = mehrere). Dann loeschen (Entf), Textur/Material aendern oder verschieben.') }));
  side.appendChild(card);
}
function finishBuilding() {
  if (st.draft.length < 3) { G.toast($t('Mindestens 3 Eckpunkte setzen.'), 'err'); return; }
  try {
    G.buildBuilding(G.levels()[st.level], st.draft, st.bld);
    st.draft = []; G.toast($t('Gebaeude gebaut.')); changed();
  } catch (e) { G.toast(e.message, 'err'); console.error(e); }
}
function finishGround() {
  if (!st.rect) { G.toast($t('Erst ein Rechteck aufziehen.'), 'err'); return; }
  try {
    var Gd = st.gnd;
    G.buildGround(G.levels()[st.level], st.rect, { material: Gd.material, desc: Gd.desc, h0: Gd.h0, h1: Gd.h1, axis: Gd.axis, tile: Gd.tile, surface: Gd.surface, traffic: Gd.traffic });
    st.rect = null; G.toast($t('Flaeche gebaut.')); changed();
  } catch (e) { G.toast(e.message, 'err'); console.error(e); }
}
function deleteSelFaces() {
  try { G.cellDeleteFaces(G.levels()[st.level], st.sel.col, st.sel.row, st.selFaces.slice()); st.selFaces = []; changed(); } catch (e) { G.toast(e.message, 'err'); }
}
function faceCard(side, L) {
  var ci = cellInfo(L, st.sel.col, st.sel.row); if (ci.empty) return;
  var b = geoBlock(ci.ents[0].off), f = b.faces[st.selFaces[0]]; if (!f) return;
  var mat = (f.tex >> 12) & 3, hs = f.idx.map(function (i) { return b.verts[i] ? b.verts[i].h : 0; });
  var o = { desc: f.tex & 0x1FF };
  var dx = el('input', { type: 'number', value: 0, style: { width: '60px' } }), dy = el('input', { type: 'number', value: 0, style: { width: '60px' } }), dh = el('input', { type: 'number', value: 0, style: { width: '60px' } });
  var matSel = G.select([{ value: 0, label: $t('kein Boden') }, { value: 1, label: $t('Strasse') }, { value: 2, label: $t('Gelaende') }, { value: 3, label: $t('Wasser') }], mat, function () { });
  side.appendChild(el('div', { class: 'card okc' }, [
    el('h4', { text: st.selFaces.length + $t(' Flaeche(n) gewaehlt') }),
    el('div', { class: 'kv' }, [el('b', { text: $t('Art') }), el('span', { text: f.ny > 20 ? $t('Boden/Dach') : $t('Wand') }), el('b', { text: $t('Material') }), el('span', { text: G.MAT_NAMES[mat] }),
      el('b', { text: $t('Hoehen') }), el('span', { text: hs.join(', ') }), el('b', { text: $t('Textur') }), el('span', { text: String(f.tex & 0x1FF) })]),
    el('div', { class: 'row tight', style: { marginTop: '6px' } }, [el('span', { text: $t('Textur') }), descInput(L, o, 'desc')]),
    el('div', { class: 'row tight', style: { marginTop: '4px' } }, [el('span', { text: $t('Material') }), matSel,
      G.button($t('Setzen'), function () { try { G.cellSetFaceTex(L, st.sel.col, st.sel.row, st.selFaces.slice(), o.desc, +matSel.value); changed(); } catch (e) { G.toast(e.message, 'err'); } })]),
    el('div', { class: 'row tight', style: { marginTop: '4px' } }, [el('span', { text: 'X' }), dx, el('span', { text: 'Y' }), dy, el('span', { text: $t('Hoehe') }), dh,
      G.button($t('Verschieben'), function () { try { G.cellMoveFaces(L, st.sel.col, st.sel.row, st.selFaces.slice(), +dx.value | 0, +dy.value | 0, +dh.value | 0); changed(); } catch (e) { G.toast(e.message, 'err'); } })]),
    el('div', { class: 'row', style: { marginTop: '6px' } }, [G.button($t('Loeschen (Entf)'), deleteSelFaces, 'danger'),
      G.button($t('Kollision der Zelle entfernen'), function () { try { G.cellClearCollision(L, st.sel.col, st.sel.row, 4); changed(); } catch (e) { G.toast(e.message, 'err'); } }),
      G.button($t('Verdeckung der Zelle entfernen'), function () { try { G.cellClearCollision(L, st.sel.col, st.sel.row, 1); changed(); } catch (e) { G.toast(e.message, 'err'); } })])
  ]));
}

function countCells(L) { var n = 0; for (var r = 0; r < 128; r++) for (var c = 0; c < 128; c++) if (cellVal(L, c, r)) n++; return n; }
function origVal(L, col, row) { var b = G.App.rom.base, mb = G.u32(b, L.tab) - 0x08000000, o = mb + (row * 128 + col) * 3; return b[o] | (b[o + 1] << 8) | (b[o + 2] << 16); }
function setCell(L, col, row, v) { var d = G.App.rom.data, o = L.mapBase + (row * 128 + col) * 3; d[o] = v & 255; d[o + 1] = (v >> 8) & 255; d[o + 2] = (v >> 16) & 255; }
function changed() { var L = G.levels()[st.level]; G.invalidate(['polys' + L.id]); renderSide(); draw(); G.updateStatus(); }

/* Deskriptor-Editor */
function descEditor(side, L) {
  var ds = descriptors(L), cur = ds[st.desc] || ds[0], at = atlasCanvases(L, st.timeOfDay);
  var num = el('input', { type: 'number', min: 0, max: 511, value: st.desc, style: { width: '80px' }, onchange: function () { st.desc = Math.max(0, Math.min(511, +this.value)); renderSide(); } });
  var prev = el('canvas', { width: 96, height: 96, style: { width: '96px', height: '96px', imageRendering: 'pixelated', border: '1px solid #333b4b' } });
  var cx = prev.getContext('2d');
  var us = cur.uv.map(function (q) { return q[0]; }), vs = cur.uv.map(function (q) { return q[1]; });
  var x0 = Math.floor(Math.min.apply(null, us)), y0 = Math.floor(Math.min.apply(null, vs)), x1 = Math.ceil(Math.max.apply(null, us)), y1 = Math.ceil(Math.max.apply(null, vs));
  if (cur.type === 2 && at[cur.atlas]) cx.drawImage(at[cur.atlas].canvas, x0, y0, Math.max(1, x1 - x0), Math.max(1, y1 - y0), 0, 0, 96, 96);
  else if (cur.type === 1) { cx.fillStyle = 'rgb(' + (at.P[cur.flat] || [0, 0, 0]).join(',') + ')'; cx.fillRect(0, 0, 96, 96); }
  var fa = el('input', { type: 'number', min: 0, max: 2, value: cur.atlas, style: { width: '60px' } });
  var fx = el('input', { type: 'number', min: 0, max: 255, value: x0, style: { width: '60px' } }), fy = el('input', { type: 'number', min: 0, max: 255, value: y0, style: { width: '60px' } });
  var fw = el('input', { type: 'number', min: 1, max: 256, value: x1 - x0, style: { width: '60px' } }), fh = el('input', { type: 'number', min: 1, max: 256, value: y1 - y0, style: { width: '60px' } });
  side.appendChild(el('div', { class: 'card' }, [
    el('h4', { text: $t('Textur-Deskriptor') }),
    el('div', { class: 'row' }, [el('span', { text: $t('Nr.') }), num, G.button('<', function () { st.desc = Math.max(0, st.desc - 1); renderSide(); }), G.button('>', function () { st.desc = Math.min(511, st.desc + 1); renderSide(); })]),
    el('div', { class: 'row', style: { marginTop: '6px', alignItems: 'flex-start' } }, [prev, el('div', { class: 'kv' }, [
      el('b', { text: $t('Typ') }), el('span', { text: cur.type === 2 ? $t('Textur') : cur.type === 1 ? $t('Einfarbig (Index ') + cur.flat + ')' : String(cur.type) }),
      el('b', { text: $t('Atlas') }), el('span', { text: String(cur.atlas + 1) }),
      el('b', { text: $t('Bereich') }), el('span', { text: x0 + ',' + y0 + ' ' + (x1 - x0) + 'x' + (y1 - y0) })
    ])]),
    cur.type === 2 ? el('div', { class: 'row tight', style: { marginTop: '6px' } }, [el('span', { text: 'Atlas(0-2)' }), fa, el('span', { text: 'X' }), fx, el('span', { text: 'Y' }), fy, el('span', { text: 'B' }), fw, el('span', { text: 'H' }), fh,
      G.button($t('Speichern'), function () {
        var d = G.App.rom.data, nx0 = +fx.value, ny0 = +fy.value, nw = +fw.value, nh = +fh.value;
        /* Ecken relativ zum alten Rechteck ueberfuehren (Ausrichtung bleibt) */
        cur.uv.forEach(function (q, p) {
          var rx = (x1 - x0) ? (q[0] - x0) / (x1 - x0) : 0, ry = (y1 - y0) ? (q[1] - y0) / (y1 - y0) : 0;
          G.putU32(d, cur.at + 8 + 8 * p, Math.round((nx0 + rx * nw) * 16)); G.putU32(d, cur.at + 12 + 8 * p, Math.round((ny0 + ry * nh) * 16));
        });
        d[cur.at + 6] = Math.max(0, Math.min(2, +fa.value));
        G.logChange(L.name + $t(' Deskriptor ') + cur.k + $t(' -> Atlas ') + fa.value + ' ' + nx0 + ',' + ny0 + ' ' + nw + 'x' + nh);
        G.invalidate(['desc' + L.id, 'dcol' + L.id + '_0', 'dcol' + L.id + '_1', 'dcol' + L.id + '_2']); renderSide(); draw();
      })]) : null,
    el('p', { class: 'hint', text: $t('Ein Deskriptor beschreibt, welcher Ausschnitt eines Atlas auf eine Flaeche kommt. Aenderungen wirken auf alle Flaechen mit dieser Nummer.') })
  ]));
}

function exportPng() {
  var L = G.levels()[st.level], S = 8, W = 128 * S;
  var saved = { zoom: st.zoom, cx: st.cx, cy: st.cy, w: view.w, h: view.h, cv: view.cv, grid: st.grid };
  var c = document.createElement('canvas'); c.width = W; c.height = W;
  view.cv = c; view.w = W; view.h = W; st.zoom = S / 512; st.cx = 32768; st.cy = 32768; st.grid = false;
  draw();
  c.toBlob(function (b) { G.download('karte_' + L.name.toLowerCase() + '.png', b); });
  view.cv = saved.cv; view.w = saved.w; view.h = saved.h; st.zoom = saved.zoom; st.cx = saved.cx; st.cy = saved.cy; st.grid = saved.grid;
  draw();
}
})(window);
