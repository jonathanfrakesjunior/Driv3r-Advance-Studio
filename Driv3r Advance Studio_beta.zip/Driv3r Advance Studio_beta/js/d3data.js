/* Driv3r Advance Studio - d3data.js
   Wissen ueber die ROM "Driv3r (Europe)" (B3RP, 8 MB) und Kataloge aller Inhalte.
   Adressen sind ROM-Offsets (ohne 0x08000000). Zeiger werden, wo moeglich, live aus
   der ROM gelesen, damit verschobene Daten gefunden werden. */
(function (global) {
'use strict';
var G = global.D3S;

var K = G.K = {
  SHA1: '3e4da1cd2a5915d2218cd59e061baeb3a08be1c6',
  CODE: 'B3RP',
  PAL_START: 0x2423AC, PAL_END: 0x244A1C,
  LEVELS: [{ id: 0, name: 'Miami', tab: 0x424 }, { id: 1, name: $t('Nizza'), tab: 0x458 }],
  STORY_TABLE: 0x1728E8, STORY_COUNT: 33,
  MSG_TABLE: 0x1720B4,          /* Missionsmeldungen: je 5 Zeiger (EN FR DE ES IT) */
  CREDITS_TABLE: 0x1BC4,
  JPEG_START: 0x178000, JPEG_END: 0x210000,
  TEXT_START: 0x210000, TEXT_END: 0x2326F0,
  SND_CFG: 0x77A104, SONG_TABLE: 0x77A0D0, SONG_COUNT: 10,
  VEH_TABLE: 0xB3C98, VEH_COUNT: 23,
  CHARMAP: 0xC80,               /* Zeichen -> Glyphe (Menue-Schrift) */
  LANGS: ['EN', 'FR', 'DE', 'ES', 'IT']
};

function rom() { return G.App.rom; }
function D() { return G.App.rom.data; }
function ptr(o) { var v = G.u32(D(), o); return (v >= 0x08000000 && v < 0x09000000) ? v - 0x08000000 : -1; }
G.ptr = ptr;

/* ---------------------------------------------------------------- Paletten */
/* Paletten-Datei: {u16 Anzahl, u16 Byte-Offset ab 0x05000000, Farben} ... Anzahl 0 */
var PAL_NAMES = {
  0x2423AC: $t('Miami Tag'), 0x242776: $t('Miami Abend'), 0x242B40: $t('Miami Nacht'),
  0x242F0A: $t('Nizza Tag'), 0x2432D4: $t('Nizza Abend'), 0x24369E: $t('Nizza Nacht'),
  0x243A68: $t('HUD (Objekte 0-31)'), 0x243AAE: $t('Titelbild'), 0x243CF8: $t('Objekte 0-15 (Menue)'),
  0x243D1E: $t('Hauptmenue'), 0x243F68: $t('Menue-3D A (Farben 0-95)'), 0x24402E: $t('Menue-3D B (Farben 0-95)'),
  0x2440F4: $t('Titel/Sprache'), 0x24431E: $t('Menue-Variante'), 0x244568: $t('Menue-Variante 2'), 0x2447F2: $t('Menue-Variante 3')
};
function parsePalFile(d, off) {
  var p = off, recs = [];
  for (var guard = 0; guard < 8; guard++) {
    var n = G.u16(d, p), o = G.u16(d, p + 2);
    if (n === 0 || n > 512) break;
    recs.push({ n: n, dst: o, off: p + 4 });
    p += 4 + 2 * n;
  }
  return { off: off, recs: recs, end: p + 2 };
}
function paletteFiles() {
  var d = D(), out = [], p = K.PAL_START;
  while (p < K.PAL_END) {
    var f = parsePalFile(d, p);
    if (!f.recs.length) break;
    f.name = PAL_NAMES[p] || ($t('Palette ') + G.hx(p));
    out.push(f); p = f.end;
  }
  return out;
}
/* 256 BG-Farben + 256 OBJ-Farben aus einer oder mehreren Dateien zusammensetzen */
function composePal(files) {
  var d = D(), bg = [], obj = [], i;
  for (i = 0; i < 256; i++) { bg.push([255, 0, 255]); obj.push([255, 0, 255]); }
  files.forEach(function (off) {
    if (off < 0) return;
    parsePalFile(d, off).recs.forEach(function (r) {
      for (var k = 0; k < r.n; k++) {
        var slot = (r.dst >> 1) + k, c = G.c15ToRgb(G.u16(d, r.off + 2 * k));
        if (slot < 256) bg[slot] = c; else if (slot < 512) obj[slot - 256] = c;
      }
    });
  });
  return { bg: bg, obj: obj };
}
G.parsePalFile = parsePalFile; G.paletteFiles = paletteFiles; G.composePal = composePal;

/* ---------------------------------------------------------------- Levels */
function levels() {
  return K.LEVELS.map(function (L) {
    var mapBase = ptr(L.tab), atlasTab = ptr(L.tab + 4), palTab = ptr(L.tab + 8), sky = ptr(L.tab + 12);
    var atlases = [], pals = [];
    for (var i = 0; i < 5; i++) atlases.push(ptr(atlasTab + 4 * i));
    for (var j = 0; j < 3; j++) pals.push(ptr(palTab + 4 * j));
    return { id: L.id, name: L.name, tab: L.tab, mapBase: mapBase, atlasTab: atlasTab, atlases: atlases, palTab: palTab, pals: pals, sky: sky };
  });
}
G.levels = levels;

/* ---------------------------------------------------------------- Bilder (VC) */
function imageCatalog() {
  var lv = levels(), list = [];
  function add(o) { if (o.off >= 0 && G.isVC(D(), o.off)) list.push(o); }
  add({ id: 'title', name: $t('Titelbild'), off: ptr(0x380), w: 240, h: 160, kind: 'bitmap', pals: [0x243AAE], group: $t('Vollbilder') });
  add({ id: 'menubg', name: $t('Hauptmenue-Hintergrund'), off: ptr(0x3A4) >= 0 && G.isVC(D(), ptr(0x3A4)) ? ptr(0x3A4) : 0x26DD9D, w: 240, h: 160, kind: 'bitmap', pals: [0x243D1E], group: $t('Vollbilder') });
  add({ id: 'menu3d_a', name: $t('Menue-3D-Texturen (Waffe, Schilder)'), off: 0x271D89, w: 256, h: 512, kind: 'bitmap', pals: [0x243D1E, 0x24402E], group: $t('Menue-Texturen') });
  add({ id: 'menu3d_b', name: $t('Menue-3D-Texturen 2'), off: 0x2690FC, w: 256, h: 256, kind: 'bitmap', pals: [0x2440F4], group: $t('Menue-Texturen') });
  lv.forEach(function (L) {
    L.atlases.forEach(function (a, i) {
      add({ id: 'atlas_' + L.id + '_' + i, name: L.name + $t(' - Texturatlas ') + (i + 1) + (i >= 3 ? $t(' (Nacht-Variante)') : ''), off: a, w: 256, h: 256,
        kind: 'bitmap', pals: [L.pals[i >= 3 ? 2 : 0]], group: $t('Stadt-Texturen'), level: L.id, slot: i, ref: L.atlasTab + 4 * i });
    });
  });
  return list;
}
/* Kachel-Grafiken fuer Objekte (4 Bit) */
function tileCatalog() {
  var list = [], sk = skylines();
  list.push({ id: 'hud', name: $t('HUD (Energie, Radar, Ziffern, Symbole)'), off: 0x285EA9, bpp: 4, cols: 16, pals: [0x243A68], bank: 1, group: 'HUD' });
  list.push({ id: 'menufont', name: $t('Menue-Schrift & Tasten'), off: 0x26CDD6, bpp: 4, cols: 8, pals: [0x243D1E], bank: 1, group: $t('Menue'), font: true });
  list.push({ id: 'gamefont', name: $t('Spielschrift (Meldungen, 8x16)'), off: ptr(0x234E54), raw: true, size: 0x4000, bpp: 4, pals: [0x243A68], bank: 1, group: $t('Schrift'), glyph16: true });
  sk.forEach(function (s, i) { list.push({ id: 'sky' + i, name: $t('Skyline ') + s.name, off: s.vc, bpp: 4, sky: s, pals: [s.pal], group: $t('Skyline') }); });
  return list.filter(function (t) { return t.off >= 0 && (t.raw || G.isVC(D(), t.off)); });
}
/* Skyline: 6 Spalten x 7 Zeilen aus 32x16-Objekten; Attributtabelle 42 Halbwoerter (spaltenweise) */
function skylines() {
  var d = D(), out = [], tod = [$t('Tag'), $t('Abend'), $t('Nacht')];
  levels().forEach(function (L) {
    if (L.sky < 0) return;
    for (var k = 0; k < 3; k++) {
      var p = L.sky + 8 * k, a = ptr(p), b = ptr(p + 4);
      if (a >= 0 && b >= 0 && G.isVC(d, a)) out.push({ vc: a, attr: b, ref: p, name: L.name + ' ' + tod[k], pal: L.pals[k] });
    }
  });
  return out;
}
G.imageCatalog = imageCatalog; G.tileCatalog = tileCatalog; G.skylines = skylines;

/* ---------------------------------------------------------------- JPEG */
function jpegCatalog() {
  var d = D(), list = [], seen = {};
  /* 1. ueber Storyboards (erfasst auch verschobene Bilder) */
  storyboards().forEach(function (sb) { sb.frames.forEach(function (f) { if (f.jpg >= 0 && !seen[f.jpg]) { seen[f.jpg] = 1; } }); });
  /* 2. Bereich absuchen */
  for (var o = K.JPEG_START; o < K.JPEG_END - 4; o++) {
    if (d[o] === 0xFF && d[o + 1] === 0xD8 && d[o + 2] === 0xFF && d[o + 3] === 0xE0) seen[o] = 1;
  }
  Object.keys(seen).map(Number).sort(function (a, b) { return a - b; }).forEach(function (off) {
    var info = G.jpegScan(d, off);
    if (info) list.push(info);
  });
  return list;
}
function storyboards() {
  var d = D(), out = [];
  for (var i = 0; i < K.STORY_COUNT; i++) {
    var lp = ptr(K.STORY_TABLE + 4 * i);
    if (lp < 0) continue;
    var frames = [], p = lp;
    for (var guard = 0; guard < 200; guard++) {
      var j = G.u32(d, p);
      if (j === 0) break;
      var f = { at: p, jpg: ptr(p), txt: [] };
      for (var l = 0; l < 5; l++) f.txt.push(ptr(p + 4 + 4 * l));
      frames.push(f); p += 24;
    }
    out.push({ id: i, list: lp, frames: frames, end: p });
  }
  return out;
}
G.jpegCatalog = jpegCatalog; G.storyboards = storyboards;

/* ---------------------------------------------------------------- Sprites */
/* Bildeintrag: {s8 ox, s8 oy, u8 w, u8 h, u32 Zeiger} -> w*h Bytes (8 Bit, Index 0 durchsichtig) */
function spriteCatalog() {
  var d = D(), n = d.length, recs = {};
  function okRec(o) {
    var w = d[o + 2], h = d[o + 3];
    if (w < 2 || h < 2) return null;
    if (d[o + 7] !== 0x08) return null;
    var a = d[o + 4] | (d[o + 5] << 8) | (d[o + 6] << 16);
    if (a + w * h > n) return null;
    if (!((a < 0x178000) || (a >= 0x2B0000 && a < 0x467000) || (a >= 0x234000 && a < 0x242000) || (a >= 0x286000 && a < 0x2A0000) || a >= 0x7E5390)) return null;
    var ox = d[o] << 24 >> 24, oy = d[o + 1] << 24 >> 24;
    if (-ox > w + 16 || -oy > h + 16 || ox > 16 || oy > 16) return null;
    return { at: o, ox: ox, oy: oy, w: w, h: h, px: a };
  }
  for (var o = 0; o < n - 8; o += 4) {
    var r = okRec(o);
    if (r) recs[o] = r;
  }
  /* Ketten: aufeinanderfolgende Eintraege, deren Bilddaten lueckenlos folgen */
  var keys = Object.keys(recs).map(Number).sort(function (a, b) { return a - b; }), sets = [], cur = null;
  keys.forEach(function (k) {
    var r = recs[k];
    if (cur && k === cur.last + 8) {
      cur.frames.push(r); cur.last = k;
    } else {
      if (cur) sets.push(cur);
      cur = { first: k, last: k, frames: [r] };
    }
  });
  if (cur) sets.push(cur);
  /* nur echte Serien (>=2 Bilder mit zusammenhaengenden Daten) behalten */
  sets = sets.filter(function (s) {
    if (s.frames.length < 2) return false;
    var chain = 0;
    for (var i = 1; i < s.frames.length; i++) { var a = s.frames[i - 1]; if (s.frames[i].px === a.px + a.w * a.h) chain++; }
    return chain >= Math.max(1, (s.frames.length - 1) * 0.5);
  });
  /* doppelte Bilddaten (gleicher Zeiger) nur einmal zaehlen, Namen vergeben */
  var veh = {};
  for (var m = 0; m < K.VEH_COUNT; m++) {
    var e = ptr(K.VEH_TABLE + 0x100 * m) ; if (e >= 0) veh[e & 0xFFFFFF] = m;
  }
  sets.forEach(function (s, i) {
    s.id = 'spr_' + G.hex(s.first, 6);
    var px = s.frames[0].px;
    var vm = null;
    for (var k in veh) { var ko = +k; if (ko >= s.first && ko <= s.last) vm = veh[k]; }
    if (vm !== null) s.name = $t('Fahrzeug ') + (vm + 1);
    else if (px >= 0x2B0000) s.name = $t('Fahrzeug/Objekt ') + G.hex(s.first, 6);
    else if (px >= 0x234000) s.name = $t('Effekte ') + G.hex(s.first, 6);
    else s.name = $t('Figuren ') + G.hex(s.first, 6);
    s.kind = px >= 0x2B0000 ? $t('Fahrzeuge') : (px >= 0x234000 ? $t('Effekte') : $t('Figuren'));
    s.vnum = vm === null ? 999 : vm;
  });
  sets.sort(function (a, b) { return a.vnum - b.vnum || a.first - b.first; });
  return sets;
}
G.spriteCatalog = spriteCatalog;

/* ---------------------------------------------------------------- Texte */
var TRUSTED = [[0, 0x5000], [0x16D000, 0x178000], [0x22F000, 0x238000]];
function isTrustedSrc(o) { for (var i = 0; i < TRUSTED.length; i++) if (o >= TRUSTED[i][0] && o < TRUSTED[i][1]) return true; return false; }
function textChar(c) { return (c >= 32 && c < 127) || (c >= 0xC0 && c <= 0xFF) || c === 0xA1 || c === 0xBF || c === 0xAA || c === 0xBA || c === 0xB0; }
function textCatalog() {
  var d = D(), refs = new Map(), n = d.length >> 2, i;
  /* Zeiger aus vertrauenswuerdigen Bereichen */
  for (i = 0; i < n; i++) {
    var o = i << 2;
    if (d[o + 3] !== 0x08 || !isTrustedSrc(o)) continue;
    var t = d[o] | (d[o + 1] << 8) | (d[o + 2] << 16);
    if (t >= K.TEXT_START && t < K.TEXT_END || t >= 0x7E5300) {
      var a = refs.get(t); if (a) a.push(o); else refs.set(t, [o]);
    }
  }
  /* Strings: referenzierte Anfaenge + Folgestrings in Textbloecken */
  var strings = [], byOff = {};
  function addStr(off) {
    if (byOff[off]) return byOff[off];
    var e = off;
    while (e < d.length && d[e] !== 0 && e - off < 1000) { if (!textChar(d[e]) && d[e] !== 10) return null; e++; }
    if (e === off || d[e] !== 0) return null;
    var s = { off: off, len: e - off, refs: refs.get(off) || [] };
    strings.push(s); byOff[off] = s; return s;
  }
  refs.forEach(function (v, t) { addStr(t); });
  /* Folgestrings (z. B. Namen in den Credits) direkt hinter referenzierten */
  var starts = strings.slice().sort(function (a, b) { return a.off - b.off; });
  starts.forEach(function (s) {
    var p = s.off + s.len + 1, guard = 0;
    while (guard++ < 80 && p < K.TEXT_END) {
      if (byOff[p]) break;
      var ns = addStr(p);
      if (!ns || ns.len < 1) break;
      p = ns.off + ns.len + 1;
    }
  });
  strings.sort(function (a, b) { return a.off - b.off; });
  /* Mehrsprachige Gruppen: Missionsmeldungen */
  var msg = [];
  for (var m = 0; m < 200; m++) {
    var row = [], ok = true;
    for (var l = 0; l < 5; l++) { var p2 = ptr(K.MSG_TABLE + (m * 5 + l) * 4); if (p2 < 0 || !byOff[p2]) { ok = false; break; } row.push(p2); }
    if (!ok) break;
    msg.push(row);
  }
  return { strings: strings, byOff: byOff, msg: msg };
}
function readStr(off) { var d = D(), s = ''; for (var p = off; d[p] && p - off < 2000; p++) s += String.fromCharCode(d[p]); return s; }
G.textCatalog = textCatalog; G.readStr = readStr; G.textChar = textChar;

/* ---------------------------------------------------------------- Sound */
function soundInfo() {
  var d = D(), cfg = K.SND_CFG;
  var bank = ptr(cfg + 16), sfx = ptr(cfg + 20), songs = [];
  for (var i = 0; i < K.SONG_COUNT; i++) songs.push({ idx: i, ref: K.SONG_TABLE + 4 * i, off: ptr(K.SONG_TABLE + 4 * i) });
  /* Sample-Bank: 256 x 16 Byte Kopf, Daten direkt dahinter aneinander */
  var samples = [], pos = bank + 0x1000;
  for (var k = 0; k < 256; k++) {
    var h = bank + 16 * k, len = G.u32(d, h);
    var w1 = G.u32(d, h + 4), w2 = G.u32(d, h + 8), w3 = G.u32(d, h + 12);
    if (len) samples.push({ idx: k, hdr: h, len: len, data: pos, vol: w1 >>> 16, fine: (w1 & 0xFF) << 24 >> 24, fineRaw: w1 & 0xFFFF,
      loopStart: w2 & 0xFFFF, loopLen: w2 >>> 16, rel: (w3 & 0xFFFF) << 16 >> 16, w3: w3 });
    pos += len;
  }
  var nsfx = G.u32(d, sfx), sfxBase = sfx + 4 + 24 * nsfx, effects = [];
  for (var s = 0; s < nsfx && s < 512; s++) {
    var e = sfx + 4 + 24 * s;
    effects.push({ idx: s, ent: e, off: G.u32(d, e), len: G.u32(d, e + 4), vol: G.u32(d, e + 8), loop: G.u32(d, e + 12), rate: G.u32(d, e + 16), w5: G.u32(d, e + 20), data: sfxBase + G.u32(d, e) });
  }
  return { cfg: cfg, bank: bank, bankEnd: pos, sfx: sfx, sfxBase: sfxBase, samples: samples, effects: effects, songs: songs };
}
G.soundInfo = soundInfo;

/* ---------------------------------------------------------------- Zeiger-Index */
/* Liste aller Stellen, an denen 0x08000000+off als Wort steht (fuer Verschiebungen) */
function findRefs(off) {
  var d = D(), v = (0x08000000 + off) >>> 0, b0 = v & 255, b1 = (v >> 8) & 255, b2 = (v >> 16) & 255, b3 = v >>> 24, out = [];
  for (var o = 0; o + 3 < d.length; o += 4) if (d[o] === b0 && d[o + 1] === b1 && d[o + 2] === b2 && d[o + 3] === b3) out.push(o);
  return out;
}
function setPtr(at, off) { G.putU32(D(), at, 0x08000000 + off); }
G.findRefs = findRefs; G.setPtr = setPtr;

/* Daten ersetzen: passt es an den alten Platz, dort schreiben; sonst ans ROM-Ende
   verschieben und alle Verweise umbiegen. */
function replaceBlob(oldOff, oldSize, bytes, opts) {
  opts = opts || {};
  var r = rom(), d = r.data;
  if (bytes.length <= oldSize && !opts.forceMove) {
    d.set(bytes, oldOff);
    if (opts.clearRest !== false) for (var i = oldOff + bytes.length; i < oldOff + oldSize; i++) d[i] = opts.fill || 0;
    return { off: oldOff, moved: false };
  }
  var refs = opts.refs || findRefs(oldOff);
  if (!refs.length && !opts.noRefsOk) throw new Error($t('Keine Verweise auf ') + G.hx(oldOff) + $t(' gefunden - Daten koennen nicht verschoben werden.'));
  var al = new G.Allocator(r, true), no = al.alloc(bytes.length + (opts.align || 0));
  if (no < 0) throw new Error($t('Kein Platz mehr in der ROM (auch nicht nach Erweiterung auf 16 MB).'));
  if (opts.align === 2 && (no & 1)) no++;
  r.data.set(bytes, no);
  refs.forEach(function (at) { setPtr(at, no); });
  return { off: no, moved: true, refs: refs.length };
}
G.replaceBlob = replaceBlob;

})(window);
