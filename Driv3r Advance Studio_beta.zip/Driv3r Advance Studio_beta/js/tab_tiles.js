/* Driv3r Advance Studio - tab_tiles.js : HUD, Menue-Schrift, Skylines (4-Bit-Objektkacheln, VC-gepackt) */
(function (global) {
'use strict';
var G = global.D3S, el = G.el;
var state = { sel: 0, cols: 0, bank: -1, zoom: 3 };

function objPal(it) { return G.composePal(it.pals).obj; }
function getBuf(it) { var d = G.App.rom.data; return it.raw ? d.slice(it.off, it.off + it.size) : G.vcDecode(d, it.off).data; }
function putBuf(it, buf, label) {
  if (it.raw) { G.App.rom.data.set(buf, it.off); G.logChange(label + ' (' + buf.length + $t(' Byte an Ort und Stelle)')); G.invalidate(['charset']); return; }
  G.writeVC(it.off, buf, label);
}
/* Spielschrift: 256 Zeichen, je 8x16 = 2 Kacheln untereinander; Bogen 16 Zeichen breit */
function glyphsToIdx(buf, bank) {
  var W = 128, H = 256, idx = new Uint8Array(W * H);
  for (var ch = 0; ch < 256; ch++) {
    var gx = (ch & 15) * 8, gy = (ch >> 4) * 16;
    for (var y = 0; y < 16; y++) for (var x = 0; x < 8; x++) {
      var o = ch * 64 + (y >> 3) * 32 + (y & 7) * 4 + (x >> 1), v = (buf[o] >> ((x & 1) * 4)) & 15;
      idx[(gy + y) * W + gx + x] = v ? v + bank * 16 : 0;
    }
  }
  return { idx: idx, w: W, h: H };
}
function idxToGlyphs(idx, buf) {
  for (var ch = 0; ch < 256; ch++) {
    var gx = (ch & 15) * 8, gy = (ch >> 4) * 16;
    for (var y = 0; y < 16; y++) for (var x = 0; x < 8; x += 2) {
      var a = idx[(gy + y) * 128 + gx + x] & 15, b = idx[(gy + y) * 128 + gx + x + 1] & 15;
      buf[ch * 64 + (y >> 3) * 32 + (y & 7) * 4 + (x >> 1)] = a | (b << 4);
    }
  }
  return buf;
}
G.gameFontGlyphs = function () {
  var it = G.cached('tiles', G.tileCatalog).filter(function (t) { return t.id === 'gamefont'; })[0];
  if (!it) return null;
  var buf = getBuf(it), has = {};
  for (var ch = 0; ch < 256; ch++) { for (var k = 0; k < 64; k++) if (buf[ch * 64 + k]) { has[ch] = 1; break; } }
  return has;
};

/* ---------------- Skyline */
function skyLayout(it) {
  var d = G.App.rom.data, cells = [];
  for (var c = 0; c < 6; c++) for (var r = 0; r < 7; r++) {
    var a = G.u16(d, it.sky.attr + 2 * (c * 7 + r));
    cells.push({ col: c, row: r, tile: (a & 0x3FF) - 512, bank: a >> 12, at: it.sky.attr + 2 * (c * 7 + r) });
  }
  return cells;
}
function skyToIdx(buf, cells) {
  var W = 192, H = 112, idx = new Uint8Array(W * H);
  cells.forEach(function (cl) {
    var t = G.obj4ToIdx(buf, cl.tile, 8, 4, cl.bank);
    for (var y = 0; y < 16; y++) idx.set(t.idx.subarray(y * 32, y * 32 + 32), (cl.row * 16 + y) * W + cl.col * 32);
  });
  return { idx: idx, w: W, h: H };
}
function idxToSky(idx, P, rgba, buf, cells) {
  var W = 192;
  cells.forEach(function (cl) {
    var sub = new Uint8Array(32 * 16);
    for (var y = 0; y < 16; y++) for (var x = 0; x < 32; x++) {
      var i = (cl.row * 16 + y) * W + cl.col * 32 + x, v;
      if (idx) { v = idx[i]; v = v ? (v & 15) : 0; }
      else {
        if (rgba[i * 4 + 3] < 128) v = 0;
        else { var bi = G.quantize(rgba.subarray(i * 4, i * 4 + 4), 1, 1, P, cl.bank * 16 + 1, cl.bank * 16 + 15, {})[0]; v = bi & 15; }
      }
      sub[y * 32 + x] = v;
    }
    G.idxToObj4(sub, 32, 8, 4, buf, cl.tile);
  });
  return buf;
}

/* ---------------- Schrift (16x16-Glyphen, 4 Kacheln im 1D-Modus) */
function charMap() {
  var d = G.App.rom.data, m = {};
  for (var c = 0x20; c < 256; c++) { var g = d[G.K.CHARMAP + c]; if (g || c === 0x20) { if (!m[g]) m[g] = []; m[g].push(c); } }
  return m;
}

G.registerTab({
  id: 'tiles', label: $t('HUD, Schrift & Skyline'), icon: '▦', group: $t('Grafik'), needsRom: true,
  render: function (v) {
    var cat = G.cached('tiles', G.tileCatalog);
    v.appendChild(el('h2', { text: $t('HUD, Schrift & Skyline') }));
    v.appendChild(el('p', { class: 'lead', html: $t('4-Bit-Objektgrafiken: HUD (Energie, Radar-Symbole, Ziffern), Menue-Schrift mit Tasten-Symbolen und die ') +
      $t('Skyline-Panoramen, die im Spiel hinter der Stadt stehen. Export als indiziertes PNG; beim Import zaehlen die unteren 4 Bit des Index ') +
      $t('(bzw. die naechste Farbe der jeweiligen Palettenbank).') }));
    var split = el('div', { class: 'split' }), side = el('div', { class: 'side', style: { width: '230px' } }), main = el('div', { style: { flex: '1', minWidth: '0' } });
    var list = el('div', { class: 'list' }), lg = '';
    cat.forEach(function (it, i) {
      if (it.group !== lg) { list.appendChild(el('div', { class: 'navgroup', text: it.group })); lg = it.group; }
      list.appendChild(el('div', { class: 'it' + (i === state.sel ? ' sel' : ''), onclick: function () { state.sel = i; state.cols = 0; state.bank = -1; G.refreshTab(); } }, [el('span', { class: 'grow', text: it.name })]));
    });
    side.appendChild(list); split.appendChild(side); split.appendChild(main); v.appendChild(split);
    var it = cat[state.sel];
    if (!it) return;
    if (it.sky) renderSky(main, it); else if (it.glyph16) renderGlyphs(main, it); else renderSheet(main, it);
  }
});

function renderSky(main, it) {
  var d = G.App.rom.data, dec = G.vcDecode(d, it.off), buf = dec.data, cells = skyLayout(it), P = objPal(it);
  var im = skyToIdx(buf, cells), cv = G.idxCanvas(im.idx, im.w, im.h, P, true), zv = G.zoomView(cv, 3);
  main.appendChild(el('div', { class: 'toolbar' }, [el('b', { text: it.name }), zv.ctl]));
  main.appendChild(el('div', { class: 'infobar' }, [el('span', { html: 'VC <b>' + G.hx(it.off) + '</b>' }), el('span', { html: $t('Attribute <b>') + G.hx(it.sky.attr) + '</b>' }),
    el('span', { html: $t('192x112 Pixel, 42 Felder a 32x16, je Feld eine Palettenbank') })]));
  main.appendChild(zv.wrap);
  main.appendChild(el('div', { class: 'card', style: { marginTop: '10px' } }, [
    el('div', { class: 'row' }, [
      G.button($t('PNG exportieren'), function () { G.exportPNG('skyline_' + state.sel + '_' + G.hex(it.off, 6) + '.png', im.idx, im.w, im.h, P, true); }, 'primary'),
      G.button($t('PNG importieren ...'), async function () {
        var f = await G.pickFile('image/*'); if (!f) return;
        try {
          var img = await G.readImageFile(f);
          if (img.w !== 192 || img.h !== 112) img = G.resizeRGBA(img, 192, 112);
          var nb = idxToSky(img.mode === 'P' ? img.idx : null, P, img.rgba, buf.slice(), cells);
          if (G.bytesEqual(nb, buf)) { G.toast($t('Unveraendert.')); return; }
          G.writeVC(it.off, nb, it.name); G.toast($t('Skyline importiert.')); G.refreshTab();
        } catch (e) { G.toast(e.message, 'err'); }
      })
    ]),
    el('p', { class: 'hint', text: $t('Durchsichtig = Index 0 bzw. Alpha. Jedes 32x16-Feld hat eine eigene 16-Farben-Bank (Himmelsverlauf oben, Gebaeude unten). Farben aendern: Tab "Paletten", Objektfarben der Stadtpalette.') })
  ]));
}

function renderGlyphs(main, it) {
  var buf = getBuf(it), P = objPal(it), bank = it.bank || 1, im = glyphsToIdx(buf, bank);
  var cv = G.idxCanvas(im.idx, im.w, im.h, P, true), zv = G.zoomView(cv, 3);
  main.appendChild(el('div', { class: 'toolbar' }, [el('b', { text: it.name }), zv.ctl]));
  main.appendChild(el('div', { class: 'infobar' }, [el('span', { html: $t('Adresse <b>') + G.hx(it.off) + $t('</b> (unkomprimiert)') }),
    el('span', { text: $t('256 Zeichen, Position = Latin-1-Code (Zeile = oberes Halbbyte). Leere Felder koennen neu gezeichnet werden - z. B. Kleinbuchstaben ab Code 0x61; der Texteditor erlaubt sie danach automatisch.') })]));
  main.appendChild(zv.wrap);
  main.appendChild(el('div', { class: 'card', style: { marginTop: '10px' } }, [el('div', { class: 'row' }, [
    G.button($t('PNG exportieren'), function () { G.exportPNG('spielschrift_' + G.hex(it.off, 6) + '.png', im.idx, im.w, im.h, P, true); }, 'primary'),
    G.button($t('PNG importieren ...'), async function () {
      var f = await G.pickFile('image/*'); if (!f) return;
      try {
        var r = await G.importIndexed(f, 128, 256, P, { lo: bank * 16, hi: bank * 16 + 15, transparent0: true });
        var nb = idxToGlyphs(r.idx, buf.slice());
        if (G.bytesEqual(nb, buf)) { G.toast($t('Unveraendert.')); return; }
        putBuf(it, nb, it.name); G.toast($t('Schrift importiert.')); G.refreshTab();
      } catch (e) { G.toast(e.message, 'err'); }
    })]), el('p', { class: 'hint', text: $t('Bogen 128x256: 16 Zeichen je Zeile, Zelle 8x16. Farben 1-15 der Objekt-Palettenbank ') + bank + $t(' (HUD-Palette), 0 = durchsichtig.') })]));
}
function renderSheet(main, it) {
  var buf = getBuf(it), ntiles = buf.length >> 5, P = objPal(it);
  if (!state.cols) state.cols = it.cols || 16;
  if (state.bank < 0) state.bank = it.bank || 0;
  var sheet = G.obj4ToIdx(buf, 0, ntiles, state.cols, state.bank);
  var cv = G.idxCanvas(sheet.idx, sheet.w, sheet.h, P, true), zv = G.zoomView(cv, 3);
  var bankSel = G.select([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15].map(function (b) { return { value: b, label: $t('Bank ') + b }; }), state.bank, function (x) { state.bank = +x; G.refreshTab(); });
  var colSel = G.select([2, 4, 8, 16, 32].map(function (c) { return { value: c, label: c + $t(' Kacheln breit') }; }), state.cols, function (x) { state.cols = +x; G.refreshTab(); });
  main.appendChild(el('div', { class: 'toolbar' }, [el('b', { text: it.name }), el('span', { class: 'sep' }), colSel, bankSel, zv.ctl]));
  main.appendChild(el('div', { class: 'infobar' }, [el('span', { html: 'VC <b>' + G.hx(it.off) + '</b>' }), el('span', { html: '<b>' + ntiles + $t('</b> Kacheln (8x8, 4 Bit)') }),
    el('span', { text: $t('Objekte liegen im 1D-Modus hintereinander: ein 32x16-Sprite = 8 Kacheln in Folge.') })]));
  var dec = { mode: '-' };
  main.appendChild(zv.wrap);
  var fname = 'kacheln_' + it.id + '_' + G.hex(it.off, 6) + '_' + state.cols + 'breit.png';
  main.appendChild(el('div', { class: 'card', style: { marginTop: '10px' } }, [
    el('div', { class: 'row' }, [
      G.button($t('PNG exportieren'), function () { G.exportPNG(fname, sheet.idx, sheet.w, sheet.h, P, true); }, 'primary'),
      G.button($t('PNG importieren ...'), async function () {
        var f = await G.pickFile('image/*'); if (!f) return;
        try {
          var r = await G.importIndexed(f, sheet.w, sheet.h, P, { lo: state.bank * 16, hi: state.bank * 16 + 15, transparent0: true });
          var idx = r.idx.map(function (x) { return x & 15; });
          var nb = G.idxToObj4(idx, sheet.w, ntiles, state.cols, buf.slice(), 0);
          if (G.bytesEqual(nb, buf)) { G.toast($t('Unveraendert.')); return; }
          putBuf(it, nb, it.name); G.toast($t('Kacheln importiert.')); G.refreshTab();
        } catch (e) { G.toast(e.message, 'err'); }
      })
    ]),
    el('p', { class: 'hint', text: $t('Beim Import muessen Breite (') + state.cols + $t(' Kacheln) und Groesse wie beim Export sein.') })
  ]));
  if (it.font) {
    var cm = charMap(), gl = el('div', { class: 'glyphs' });
    var ng = Math.min(80, ntiles >> 2);
    for (var g = 0; g < ng; g++) {
      var t = G.obj4ToIdx(buf, g * 4, 4, 2, state.bank);
      var c = G.idxCanvas(t.idx, 16, 16, P, true);
      var chars = (cm[g] || []).map(function (x) { return String.fromCharCode(x); }).join(' ');
      gl.appendChild(el('div', { class: 'g', title: $t('Glyphe ') + g }, [c, el('small', { text: g + (chars ? ': ' + chars : '') })]));
    }
    main.appendChild(el('div', { class: 'card' }, [el('h4', { text: $t('Menue-Schrift: Glyphen (16x16) und zugeordnete Zeichen') }), gl,
      el('p', { class: 'hint', text: $t('Zeichentabelle bei ') + G.hx(G.K.CHARMAP) + $t(' (256 Byte: Zeichen -> Glyphe). Zum Bearbeiten der Glyphen "2 Kacheln breit" waehlen: dann steht jede Glyphe als 16x16-Block untereinander.') })]));
  }
}

G.tilesExportAll = function (zip) {
  var cat = G.cached('tiles', G.tileCatalog), n = 0;
  cat.forEach(function (it, i) {
    var buf = getBuf(it), P = objPal(it);
    if (it.glyph16) { var gi = glyphsToIdx(buf, it.bank || 1); zip.add('kacheln/tiles_' + it.id + '_glyph.png', G.pngWriteIndexed(gi.idx, gi.w, gi.h, P, true)); n++; return; }
    if (it.sky) { var im = skyToIdx(buf, skyLayout(it)); zip.add('kacheln/skyline_' + it.id + '.png', G.pngWriteIndexed(im.idx, im.w, im.h, P, true)); }
    else { var cols = it.cols || 16, sh = G.obj4ToIdx(buf, 0, buf.length >> 5, cols, it.bank || 0); zip.add('kacheln/tiles_' + it.id + '_' + cols + '.png', G.pngWriteIndexed(sh.idx, sh.w, sh.h, P, true)); }
    n++;
  });
  return n;
};
G.tilesImportFile = function (name, bytes, report) {
  var m = /kacheln\/(skyline|tiles)_([a-z0-9]+?)(?:_(\d+|glyph))?\.png$/i.exec(name);
  if (!m) return false;
  var it = G.cached('tiles', G.tileCatalog).filter(function (x) { return x.id === m[2]; })[0];
  if (!it) { report.skip.push(name + $t(': unbekannt')); return true; }
  var buf = getBuf(it), P = objPal(it), png = G.pngRead(bytes), nb;
  if (it.glyph16) {
    if (png.w !== 128 || png.h !== 256) { report.skip.push(name + $t(': falsche Groesse')); return true; }
    var bk = it.bank || 1, gidx = png.mode === 'P' ? png.idx : G.quantize(png.rgba, 128, 256, P, bk * 16, bk * 16 + 15, { transparent0: true });
    nb = idxToGlyphs(gidx, buf.slice());
    if (!G.bytesEqual(nb, buf)) { putBuf(it, nb, it.name); report.done.push(it.name); }
    return true;
  }
  if (it.sky) {
    if (png.w !== 192 || png.h !== 112) { report.skip.push(name + $t(': falsche Groesse')); return true; }
    nb = idxToSky(png.mode === 'P' ? png.idx : null, P, png.rgba, buf.slice(), skyLayout(it));
  } else {
    var cols = +m[3] || it.cols || 16, nt = buf.length >> 5, sh = G.obj4ToIdx(buf, 0, nt, cols, it.bank || 0);
    if (png.w !== sh.w || png.h !== sh.h) { report.skip.push(name + $t(': falsche Groesse')); return true; }
    var b = it.bank || 0, idx = png.mode === 'P' ? png.idx : G.quantize(png.rgba, sh.w, sh.h, P, b * 16, b * 16 + 15, { transparent0: true });
    nb = G.idxToObj4(idx.map(function (x) { return x & 15; }), sh.w, nt, cols, buf.slice(), 0);
  }
  if (!G.bytesEqual(nb, buf)) { putBuf(it, nb, it.name); report.done.push(it.name); }
  return true;
};
})(window);
