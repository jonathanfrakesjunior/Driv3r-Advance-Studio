/* Driv3r Advance Studio - tab_hex.js : Hex-Ansicht / -Editor fuer Experten */
(function (global) {
'use strict';
var G = global.D3S, el = G.el;
var st = { off: 0x2423AC };
G.registerTab({
  id: 'hex', label: $t('Hex-Editor'), icon: '#', group: $t('Experten'), needsRom: true,
  render: function (v) {
    var d = G.App.rom.data;
    v.appendChild(el('h2', { text: $t('Hex-Editor') }));
    v.appendChild(el('p', { class: 'lead', text: $t('Rohansicht der ROM. Geaenderte Bytes sind hervorgehoben. Schreiben: Adresse + Hex-Bytes eingeben.') }));
    var addr = el('input', { value: G.hx(st.off), class: 'mono', style: { width: '130px' } });
    var bytes = el('input', { class: 'mono', placeholder: 'z. B. 00 7F 1F', style: { width: '300px' } });
    v.appendChild(el('div', { class: 'toolbar' }, [
      el('span', { text: $t('Adresse') }), addr, G.button($t('Gehe zu'), function () { st.off = Math.max(0, parseInt(addr.value, 16) & ~15); G.refreshTab(); }),
      G.button('-0x100', function () { st.off = Math.max(0, st.off - 256); G.refreshTab(); }), G.button('+0x100', function () { st.off = Math.min(d.length - 256, st.off + 256); G.refreshTab(); }),
      el('span', { class: 'sep' }), bytes,
      G.button($t('An Adresse schreiben'), function () {
        var a = parseInt(addr.value, 16), b = bytes.value.trim().split(/\s+/).map(function (x) { return parseInt(x, 16); });
        if (isNaN(a) || b.some(isNaN)) { G.toast($t('Ungueltige Eingabe'), 'err'); return; }
        b.forEach(function (x, i) { d[a + i] = x & 255; }); G.logChange($t('Hex: ') + b.length + $t(' Byte bei ') + G.hx(a)); G.invalidate(); G.refreshTab();
      })
    ]));
    var base = G.App.rom.base, lines = [];
    for (var r = 0; r < 32; r++) {
      var o = st.off + r * 16; if (o >= d.length) break;
      var h = '', a = '';
      for (var i = 0; i < 16; i++) {
        var x = d[o + i], ch = o + i < base.length && base[o + i] !== x;
        h += (ch ? '<b>' : '') + G.hex(x, 2) + (ch ? '</b>' : '') + ' ';
        a += x >= 32 && x < 127 ? String.fromCharCode(x).replace('&', '&amp;').replace('<', '&lt;') : '.';
      }
      lines.push('<i>' + G.hex(o, 6) + '</i>  ' + h + ' ' + a);
    }
    v.appendChild(el('div', { class: 'hexview', html: lines.join('\n') }));
  }
});
})(window);
