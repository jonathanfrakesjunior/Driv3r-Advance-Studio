/* Driv3r Advance Studio - tab_text.js : Texte (Latin-1, NUL-terminiert, 5 Sprachen) */
(function (global) {
'use strict';
var G = global.D3S, el = G.el;
var state = { view: 'msg', q: '', page: 0 };

/* Erlaubte Zeichen = alle Zeichen, die das Spiel in seinen Texten selbst benutzt */
function allowedSet() {
  return G.cached('charset', function () {
    var tc = G.cached('texts', G.textCatalog), set = {}, d = G.App.rom.data;
    tc.strings.forEach(function (s) { for (var i = 0; i < s.len; i++) set[d[s.off + i]] = 1; });
    set[32] = 1; set[10] = 1;
    var gl = G.gameFontGlyphs && G.gameFontGlyphs();
    if (gl) for (var ch in gl) set[ch] = 1;   /* neu gezeichnete Zeichen der Spielschrift */
    return set;
  });
}
function encodeText(str) {
  var set = allowedSet(), out = [], bad = {};
  str = str.replace(/\r/g, '');
  for (var i = 0; i < str.length; i++) {
    var c = str.charCodeAt(i);
    if (c > 255) { bad[str[i]] = 1; continue; }
    if (!set[c]) {
      var up = str[i].toUpperCase().charCodeAt(0);
      if (up < 256 && set[up]) c = up; else { bad[str[i]] = 1; continue; }
    }
    out.push(c);
  }
  var b = Object.keys(bad);
  if (b.length) throw new Error($t('Diese Zeichen gibt es in der Spielschrift nicht: ') + b.join(' ') + $t(' (Tipp: Grossbuchstaben verwenden)'));
  return new Uint8Array(out);
}
G.encodeText = encodeText;

function textRefs(off) {
  return G.findRefs(off).filter(function (o) { return o < 0x5000 || (o >= 0x16D000 && o < 0x178000) || (o >= 0x22F000 && o < 0x238000) || o >= G.App.rom.origSize - 0x1B000; });
}
/* Text schreiben: passt er, an Ort und Stelle; sonst ans Ende verschieben und Zeiger umbiegen */
function writeText(off, str, label) {
  var d = G.App.rom.data, enc = encodeText(str), oldLen = 0;
  while (d[off + oldLen] && oldLen < 4000) oldLen++;
  if (enc.length <= oldLen) {
    d.set(enc, off); for (var i = off + enc.length; i <= off + oldLen; i++) d[i] = 0;
  } else {
    var refs = textRefs(off);
    if (!refs.length) throw new Error($t('Dieser Text hat keinen eigenen Zeiger und darf hoechstens ') + oldLen + $t(' Zeichen lang sein.'));
    var buf = new Uint8Array(enc.length + 1); buf.set(enc);
    var al = new G.Allocator(G.App.rom, true), no = al.alloc(buf.length);
    if (no < 0) throw new Error($t('Kein Platz mehr in der ROM.'));
    G.App.rom.data.set(buf, no);
    refs.forEach(function (at) { G.setPtr(at, no); });
    off = no;
  }
  G.logChange((label || $t('Text')) + ': "' + str.slice(0, 40) + (str.length > 40 ? '...' : '') + '"');
  G.invalidate(['texts', 'charset']);
  return off;
}
G.writeText = writeText;

G.registerTab({
  id: 'text', label: $t('Texte'), icon: 'T', group: $t('Inhalt'), needsRom: true,
  render: function (v) {
    var tc = G.cached('texts', G.textCatalog);
    v.appendChild(el('h2', { text: $t('Texte') }));
    v.appendChild(el('p', { class: 'lead', html: $t('Alle Texte des Spiels. Die Schrift kennt nur Grossbuchstaben, Ziffern, Satzzeichen und Akzente ') +
      $t('(Kleinbuchstaben werden automatisch umgewandelt). Laengere Texte werden ans ROM-Ende verschoben, sofern sie einen eigenen Zeiger haben. ') +
      $t('Missionsmeldungen gehoeren zum Missionsbefehl "Meldung" (Nummer = ID).') }));
    v.appendChild(el('div', { class: 'toolbar' }, [
      G.button($t('Missionsmeldungen (') + tc.msg.length + ')', function () { state.view = 'msg'; G.refreshTab(); }, state.view === 'msg' ? 'on' : ''),
      G.button($t('Alle Texte (') + tc.strings.length + ')', function () { state.view = 'all'; G.refreshTab(); }, state.view === 'all' ? 'on' : ''),
      el('span', { class: 'sep' }),
      el('input', { placeholder: $t('Suchen ...'), value: state.q, oninput: function () { state.q = this.value; state.page = 0; clearTimeout(this._t); var self = this; this._t = setTimeout(function () { G.refreshTab(); var i = document.querySelector('#view input'); if (i) { i.focus(); i.setSelectionRange(self.value.length, self.value.length); } }, 350); } }),
      el('span', { class: 'spacer' }),
      G.button($t('CSV exportieren'), function () { G.download('driv3r_texte.csv', new TextEncoder().encode(G.textsCSV()), 'text/csv'); }),
      G.button($t('CSV importieren'), async function () {
        var f = await G.pickFile('.csv,.txt'); if (!f) return;
        var rep = { done: [], skip: [] }; G.textsImportCSV(await G.readFileText(f), rep);
        G.modal($t('CSV-Import'), '<p>' + rep.done.length + $t(' Texte geaendert.</p>') + (rep.skip.length ? '<p class="warnbox">' + rep.skip.slice(0, 40).join('<br>') + '</p>' : ''));
        G.refreshTab();
      })
    ]));
    var q = state.q.toUpperCase();
    if (state.view === 'msg') renderMsg(v, tc, q); else renderAll(v, tc, q);
  }
});

function editor(off, label) {
  var cur = G.readStr(off);
  var ta = el('textarea', { rows: Math.min(4, 1 + (cur.length / 60 | 0)), style: { width: '100%' } }, [cur]);
  var cnt = el('div', { class: 'txtcnt' });
  var hasRef = null;
  function upd() {
    if (hasRef === null) hasRef = textRefs(off).length > 0;
    var over = ta.value.length > cur.length && !hasRef;
    cnt.textContent = ta.value.length + ' / ' + cur.length + (hasRef ? $t(' (wird bei Bedarf verschoben)') : $t(' (feste Laenge)'));
    cnt.className = 'txtcnt' + (over ? ' over' : '');
  }
  ta.onfocus = upd; ta.oninput = upd;
  ta.onchange = function () {
    if (ta.value === cur) return;
    try { writeText(off, ta.value, label); cur = ta.value; G.toast($t('Gespeichert.')); } catch (e) { G.toast(e.message, 'err'); ta.value = cur; }
  };
  return el('div', {}, [ta, cnt]);
}

function renderMsg(v, tc, q) {
  var t = el('table', { class: 'tbl' }, [el('tr', {}, [el('th', { text: $t('ID') })].concat(G.K.LANGS.map(function (l) { return el('th', { text: l }); })))]);
  var n = 0;
  tc.msg.forEach(function (row, id) {
    if (q) { var hit = row.some(function (o) { return G.readStr(o).indexOf(q) >= 0; }) || String(id) === q; if (!hit) return; }
    if (n++ > 120) return;
    t.appendChild(el('tr', {}, [el('td', { class: 'mono', text: String(id) })].concat(row.map(function (o, li) { return el('td', { style: { minWidth: '160px', verticalAlign: 'top' } }, [editor(o, $t('Meldung ') + id + ' ' + G.K.LANGS[li])]); }))));
  });
  v.appendChild(el('div', { class: 'card', style: { overflow: 'auto' } }, [t, n > 120 ? el('p', { class: 'hint', text: $t('Nur die ersten 120 Treffer - Suche verfeinern.') }) : null]));
}

function renderAll(v, tc, q) {
  var items = tc.strings.filter(function (s) { return !q || G.readStr(s.off).indexOf(q) >= 0 || G.hex(s.off, 6) === q; });
  var per = 60, pages = Math.max(1, Math.ceil(items.length / per));
  if (state.page >= pages) state.page = 0;
  var t = el('table', { class: 'tbl' }, [el('tr', {}, [el('th', { text: $t('Adresse') }), el('th', { text: $t('Zeiger') }), el('th', { text: $t('Text') })])]);
  items.slice(state.page * per, state.page * per + per).forEach(function (s) {
    t.appendChild(el('tr', {}, [el('td', { class: 'mono', text: G.hx(s.off) }), el('td', { text: s.refs.length ? String(s.refs.length) : '-' }), el('td', { style: { width: '100%' } }, [editor(s.off, $t('Text ') + G.hx(s.off))])]));
  });
  v.appendChild(el('div', { class: 'row', style: { marginBottom: '6px' } }, [
    G.button('<', function () { state.page = Math.max(0, state.page - 1); G.refreshTab(); }),
    el('span', { text: $t('Seite ') + (state.page + 1) + ' / ' + pages + ' (' + items.length + $t(' Texte)') }),
    G.button('>', function () { state.page = Math.min(pages - 1, state.page + 1); G.refreshTab(); })
  ]));
  v.appendChild(el('div', { class: 'card' }, [t]));
}

/* CSV: Adresse;Text  (Semikolon, Anfuehrungszeichen) */
function csvq(s) { return '"' + s.replace(/"/g, '""') + '"'; }
G.textsCSV = function () {
  var tc = G.cached('texts', G.textCatalog), lines = ['adresse;meldung_id;sprache;text'];
  var msgOf = {};
  tc.msg.forEach(function (row, id) { row.forEach(function (o, li) { msgOf[o] = id + ';' + G.K.LANGS[li]; }); });
  tc.strings.forEach(function (s) { lines.push(G.hex(s.off, 6) + ';' + (msgOf[s.off] || ';') + ';' + csvq(G.readStr(s.off))); });
  return '﻿' + lines.join('\r\n');
};
function parseCSV(text) {
  var rows = [], row = [], cell = '', q = false;
  text = text.replace(/^﻿/, '');
  for (var i = 0; i < text.length; i++) {
    var c = text[i];
    if (q) { if (c === '"') { if (text[i + 1] === '"') { cell += '"'; i++; } else q = false; } else cell += c; }
    else if (c === '"') q = true;
    else if (c === ';') { row.push(cell); cell = ''; }
    else if (c === '\n') { row.push(cell); rows.push(row); row = []; cell = ''; }
    else if (c !== '\r') cell += c;
  }
  if (cell || row.length) { row.push(cell); rows.push(row); }
  return rows;
}
G.textsImportCSV = function (text, rep) {
  var rows = parseCSV(text), tc = G.cached('texts', G.textCatalog), valid = {};
  tc.strings.forEach(function (s) { valid[s.off] = 1; });
  rows.slice(1).forEach(function (r) {
    if (r.length < 4) return;
    var off = parseInt(r[0], 16), txt = r[3];
    if (!valid[off]) { rep.skip.push(r[0] + $t(': unbekannte Adresse')); return; }
    if (G.readStr(off) === txt) return;
    try { writeText(off, txt, 'CSV ' + r[0]); rep.done.push(r[0]); } catch (e) { rep.skip.push(r[0] + ': ' + e.message); }
  });
};
})(window);
