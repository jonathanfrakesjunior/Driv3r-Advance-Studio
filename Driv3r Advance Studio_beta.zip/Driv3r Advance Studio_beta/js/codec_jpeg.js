/* Driv3r Advance Studio - codec_jpeg.js
   Die Zwischensequenz-Bilder sind normale Baseline-JPEGs (240x160, YCbCr 4:2:0),
   nur der SOS-Marker FFDA ist im ROM durch FF1A ersetzt.
   Anzeige: Marker zuruecktauschen und den Browser dekodieren lassen.
   Import: eigener Baseline-Encoder, der das Original-Layout nachbaut
   (APP0, 2x DQT, SOF0, 4x DHT, SOS->FF1A, EOI). */
(function (global) {
'use strict';
var G = global.D3S;

function isJpeg(d, off) { return d[off] === 0xFF && d[off + 1] === 0xD8 && d[off + 2] === 0xFF; }

/* Laenge eines JPEG im ROM bestimmen (bis einschliesslich EOI), Marker-Liste */
function jpegScan(d, off) {
  if (!isJpeg(d, off)) return null;
  var p = off + 2, sos = -1, markers = [];
  while (p + 4 < d.length) {
    if (d[p] !== 0xFF) return null;
    var m = d[p + 1], len = (d[p + 2] << 8) | d[p + 3];
    markers.push({ m: m, off: p, len: len });
    if (m === 0x1A || m === 0xDA) { sos = p; p += 2 + len; break; }
    p += 2 + len;
  }
  if (sos < 0) return null;
  /* Entropiedaten bis FFD9 (FF00 = Stopfbyte, FFD0-D7 = Restart) */
  while (p + 1 < d.length) {
    if (d[p] === 0xFF) {
      var b = d[p + 1];
      if (b === 0xD9) { p += 2; break; }
      if (b === 0x00 || (b >= 0xD0 && b <= 0xD7)) { p += 2; continue; }
    }
    p++;
  }
  var w = 0, h = 0, q = [];
  markers.forEach(function (mk) {
    if (mk.m === 0xC0) { h = (d[mk.off + 5] << 8) | d[mk.off + 6]; w = (d[mk.off + 7] << 8) | d[mk.off + 8]; }
    if (mk.m === 0xDB) {
      var s = mk.off + 4, e = mk.off + 2 + mk.len;
      while (s < e) { var id = d[s] & 15, tb = new Uint8Array(64); for (var i = 0; i < 64; i++) tb[i] = d[s + 1 + i]; q[id] = tb; s += 65; }
    }
  });
  return { off: off, size: p - off, sos: sos, w: w, h: h, quant: q, obfuscated: d[sos + 1] === 0x1A };
}

/* Standard-JPEG-Bytes (FFDA) aus ROM-Bytes */
function toStdJpeg(d, info) {
  var b = d.slice(info.off, info.off + info.size);
  b[info.sos - info.off + 1] = 0xDA;
  return b;
}

/* -> Promise {w,h,rgba} */
function decodeJpeg(bytes) {
  return new Promise(function (resolve, reject) {
    var url = URL.createObjectURL(new Blob([bytes], { type: 'image/jpeg' }));
    var img = new Image();
    img.onload = function () {
      var c = document.createElement('canvas'); c.width = img.width; c.height = img.height;
      var cx = c.getContext('2d'); cx.drawImage(img, 0, 0);
      var id = cx.getImageData(0, 0, c.width, c.height);
      URL.revokeObjectURL(url);
      resolve({ w: c.width, h: c.height, rgba: new Uint8Array(id.data.buffer), canvas: c });
    };
    img.onerror = function () { URL.revokeObjectURL(url); reject(new Error($t('JPEG konnte nicht dekodiert werden'))); };
    img.src = url;
  });
}

/* ------------------------------------------------------------ Encoder */
var ZZ = [0,1,8,16,9,2,3,10,17,24,32,25,18,11,4,5,12,19,26,33,40,48,41,34,27,20,13,6,7,14,21,28,
  35,42,49,56,57,50,43,36,29,22,15,23,30,37,44,51,58,59,52,45,38,31,39,46,53,60,61,54,47,55,62,63];
var STD_LQ = [16,11,10,16,24,40,51,61,12,12,14,19,26,58,60,55,14,13,16,24,40,57,69,56,14,17,22,29,51,87,80,62,
  18,22,37,56,68,109,103,77,24,35,55,64,81,104,113,92,49,64,78,87,103,121,120,101,72,92,95,98,112,100,103,99];
var STD_CQ = [17,18,24,47,99,99,99,99,18,21,26,66,99,99,99,99,24,26,56,99,99,99,99,99,47,66,99,99,99,99,99,99,
  99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99];
/* Standard-Huffman-Tabellen (Annex K) */
var DC_L_BITS = [0,1,5,1,1,1,1,1,1,0,0,0,0,0,0,0], DC_L_VAL = [0,1,2,3,4,5,6,7,8,9,10,11];
var DC_C_BITS = [0,3,1,1,1,1,1,1,1,1,1,0,0,0,0,0], DC_C_VAL = [0,1,2,3,4,5,6,7,8,9,10,11];
var AC_L_BITS = [0,2,1,3,3,2,4,3,5,5,4,4,0,0,1,0x7d];
var AC_L_VAL = [0x01,0x02,0x03,0x00,0x04,0x11,0x05,0x12,0x21,0x31,0x41,0x06,0x13,0x51,0x61,0x07,0x22,0x71,0x14,0x32,0x81,0x91,0xa1,0x08,
  0x23,0x42,0xb1,0xc1,0x15,0x52,0xd1,0xf0,0x24,0x33,0x62,0x72,0x82,0x09,0x0a,0x16,0x17,0x18,0x19,0x1a,0x25,0x26,0x27,0x28,0x29,0x2a,0x34,0x35,0x36,
  0x37,0x38,0x39,0x3a,0x43,0x44,0x45,0x46,0x47,0x48,0x49,0x4a,0x53,0x54,0x55,0x56,0x57,0x58,0x59,0x5a,0x63,0x64,0x65,0x66,0x67,0x68,0x69,0x6a,
  0x73,0x74,0x75,0x76,0x77,0x78,0x79,0x7a,0x83,0x84,0x85,0x86,0x87,0x88,0x89,0x8a,0x92,0x93,0x94,0x95,0x96,0x97,0x98,0x99,0x9a,0xa2,0xa3,0xa4,
  0xa5,0xa6,0xa7,0xa8,0xa9,0xaa,0xb2,0xb3,0xb4,0xb5,0xb6,0xb7,0xb8,0xb9,0xba,0xc2,0xc3,0xc4,0xc5,0xc6,0xc7,0xc8,0xc9,0xca,0xd2,0xd3,0xd4,0xd5,
  0xd6,0xd7,0xd8,0xd9,0xda,0xe1,0xe2,0xe3,0xe4,0xe5,0xe6,0xe7,0xe8,0xe9,0xea,0xf1,0xf2,0xf3,0xf4,0xf5,0xf6,0xf7,0xf8,0xf9,0xfa];
var AC_C_BITS = [0,2,1,2,4,4,3,4,7,5,4,4,0,1,2,0x77];
var AC_C_VAL = [0x00,0x01,0x02,0x03,0x11,0x04,0x05,0x21,0x31,0x06,0x12,0x41,0x51,0x07,0x61,0x71,0x13,0x22,0x32,0x81,0x08,0x14,0x42,0x91,
  0xa1,0xb1,0xc1,0x09,0x23,0x33,0x52,0xf0,0x15,0x62,0x72,0xd1,0x0a,0x16,0x24,0x34,0xe1,0x25,0xf1,0x17,0x18,0x19,0x1a,0x26,0x27,0x28,0x29,0x2a,
  0x35,0x36,0x37,0x38,0x39,0x3a,0x43,0x44,0x45,0x46,0x47,0x48,0x49,0x4a,0x53,0x54,0x55,0x56,0x57,0x58,0x59,0x5a,0x63,0x64,0x65,0x66,0x67,0x68,
  0x69,0x6a,0x73,0x74,0x75,0x76,0x77,0x78,0x79,0x7a,0x82,0x83,0x84,0x85,0x86,0x87,0x88,0x89,0x8a,0x92,0x93,0x94,0x95,0x96,0x97,0x98,0x99,0x9a,
  0xa2,0xa3,0xa4,0xa5,0xa6,0xa7,0xa8,0xa9,0xaa,0xb2,0xb3,0xb4,0xb5,0xb6,0xb7,0xb8,0xb9,0xba,0xc2,0xc3,0xc4,0xc5,0xc6,0xc7,0xc8,0xc9,0xca,0xd2,
  0xd3,0xd4,0xd5,0xd6,0xd7,0xd8,0xd9,0xda,0xe2,0xe3,0xe4,0xe5,0xe6,0xe7,0xe8,0xe9,0xea,0xf2,0xf3,0xf4,0xf5,0xf6,0xf7,0xf8,0xf9,0xfa];

function buildHuff(bits, vals) {
  var code = 0, k = 0, tab = {};
  for (var l = 1; l <= 16; l++) {
    for (var i = 0; i < bits[l - 1]; i++) { tab[vals[k++]] = [code, l]; code++; }
    code <<= 1;
  }
  return tab;
}
var HT = null;
function tables() {
  if (!HT) HT = { dcl: buildHuff(DC_L_BITS, DC_L_VAL), dcc: buildHuff(DC_C_BITS, DC_C_VAL), acl: buildHuff(AC_L_BITS, AC_L_VAL), acc: buildHuff(AC_C_BITS, AC_C_VAL) };
  return HT;
}
function scaleQuant(base, quality) {
  quality = Math.max(1, Math.min(100, quality));
  var s = quality < 50 ? 5000 / quality : 200 - quality * 2, out = new Uint8Array(64);
  for (var i = 0; i < 64; i++) out[i] = Math.max(1, Math.min(255, Math.floor((base[i] * s + 50) / 100)));
  return out;   /* in natuerlicher Reihenfolge */
}

/* float-DCT (AAN wuerde reichen, die Bilder sind klein) */
var COS = (function () { var c = new Float64Array(64); for (var x = 0; x < 8; x++) for (var u = 0; u < 8; u++) c[x * 8 + u] = Math.cos((2 * x + 1) * u * Math.PI / 16); return c; })();
function fdct(block, out) {
  var tmp = new Float64Array(64);
  for (var y = 0; y < 8; y++) for (var u = 0; u < 8; u++) {
    var s = 0; for (var x = 0; x < 8; x++) s += block[y * 8 + x] * COS[x * 8 + u];
    tmp[y * 8 + u] = s * (u === 0 ? Math.SQRT1_2 : 1) / 2;
  }
  for (var u2 = 0; u2 < 8; u2++) for (var v = 0; v < 8; v++) {
    var s2 = 0; for (var y2 = 0; y2 < 8; y2++) s2 += tmp[y2 * 8 + u2] * COS[y2 * 8 + v];
    out[v * 8 + u2] = s2 * (v === 0 ? Math.SQRT1_2 : 1) / 2;
  }
}

/* quantNat: {0: Uint8Array(64) natuerliche Reihenfolge, 1: ...} */
function encodeJpeg(rgba, w, h, opts) {
  opts = opts || {};
  var T = tables();
  var ql = opts.lumQ || scaleQuant(STD_LQ, opts.quality || 85);
  var qc = opts.chrQ || scaleQuant(STD_CQ, opts.quality || 85);
  var out = [], bitbuf = 0, bitcnt = 0;
  function byte(b) { out.push(b & 255); }
  function word(v) { byte(v >> 8); byte(v); }
  function putBits(code, len) {
    for (var i = len - 1; i >= 0; i--) {
      bitbuf = (bitbuf << 1) | ((code >> i) & 1); bitcnt++;
      if (bitcnt === 8) { byte(bitbuf); if (bitbuf === 0xFF) byte(0); bitbuf = 0; bitcnt = 0; }
    }
  }
  function flushBits() { if (bitcnt) { putBits(0x7F, 8 - bitcnt); } }
  /* Kopf wie im Original */
  word(0xFFD8);
  word(0xFFE0); word(16); [0x4A, 0x46, 0x49, 0x46, 0, 1, 1, 1, 0, 11, 0, 11, 0, 0].forEach(byte);
  [[0, ql], [1, qc]].forEach(function (q) {
    word(0xFFDB); word(67); byte(q[0]);
    for (var i = 0; i < 64; i++) byte(q[1][ZZ[i]]);
  });
  word(0xFFC0); word(17); byte(8); word(h); word(w); byte(3);
  byte(1); byte(0x22); byte(0); byte(2); byte(0x11); byte(1); byte(3); byte(0x11); byte(1);
  function dht(cls, id, bits, vals) {
    word(0xFFC4); word(3 + 16 + vals.length); byte((cls << 4) | id);
    bits.forEach(byte); vals.forEach(byte);
  }
  dht(0, 0, DC_L_BITS, DC_L_VAL); dht(1, 0, AC_L_BITS, AC_L_VAL);
  dht(0, 1, DC_C_BITS, DC_C_VAL); dht(1, 1, AC_C_BITS, AC_C_VAL);
  var sosAt = out.length;
  word(0xFFDA); word(12); byte(3); byte(1); byte(0x00); byte(2); byte(0x11); byte(3); byte(0x11); byte(0); byte(63); byte(0);

  /* Farbraum */
  var Y = new Float64Array(w * h), Cb = new Float64Array(w * h), Cr = new Float64Array(w * h);
  for (var i = 0; i < w * h; i++) {
    var r = rgba[i * 4], g = rgba[i * 4 + 1], b = rgba[i * 4 + 2];
    Y[i] = 0.299 * r + 0.587 * g + 0.114 * b - 128;
    Cb[i] = -0.168736 * r - 0.331264 * g + 0.5 * b;
    Cr[i] = 0.5 * r - 0.418688 * g - 0.081312 * b;
  }
  function px(arr, x, y) { if (x >= w) x = w - 1; if (y >= h) y = h - 1; return arr[y * w + x]; }
  var blk = new Float64Array(64), coef = new Float64Array(64), pred = [0, 0, 0];
  function bitLen(v) { v = Math.abs(v); var n = 0; while (v) { n++; v >>= 1; } return n; }
  function encBlock(comp, q, dcT, acT) {
    fdct(blk, coef);
    var zz = new Int32Array(64);
    for (var i = 0; i < 64; i++) { var k = ZZ[i]; zz[i] = Math.round(coef[k] / q[k]); }
    var diff = zz[0] - pred[comp]; pred[comp] = zz[0];
    var s = bitLen(diff), c = dcT[s]; putBits(c[0], c[1]);
    if (s) putBits(diff < 0 ? diff + (1 << s) - 1 : diff, s);
    var run = 0;
    for (var j = 1; j < 64; j++) {
      var v = zz[j];
      if (v === 0) { run++; continue; }
      while (run > 15) { var z = acT[0xF0]; putBits(z[0], z[1]); run -= 16; }
      var sz = bitLen(v), cc = acT[(run << 4) | sz]; putBits(cc[0], cc[1]);
      putBits(v < 0 ? v + (1 << sz) - 1 : v, sz);
      run = 0;
    }
    if (run) { var e = acT[0]; putBits(e[0], e[1]); }
  }
  for (var my = 0; my < h; my += 16) for (var mx = 0; mx < w; mx += 16) {
    for (var by = 0; by < 2; by++) for (var bx = 0; bx < 2; bx++) {
      for (var yy = 0; yy < 8; yy++) for (var xx = 0; xx < 8; xx++) blk[yy * 8 + xx] = px(Y, mx + bx * 8 + xx, my + by * 8 + yy);
      encBlock(0, ql, T.dcl, T.acl);
    }
    [Cb, Cr].forEach(function (C, ci) {
      for (var yy = 0; yy < 8; yy++) for (var xx = 0; xx < 8; xx++) {
        var sx = mx + xx * 2, sy = my + yy * 2;
        blk[yy * 8 + xx] = (px(C, sx, sy) + px(C, sx + 1, sy) + px(C, sx, sy + 1) + px(C, sx + 1, sy + 1)) / 4;
      }
      encBlock(ci + 1, qc, T.dcc, T.acc);
    });
  }
  flushBits();
  word(0xFFD9);
  var res = new Uint8Array(out);
  if (opts.obfuscate !== false) res[sosAt + 1] = 0x1A;
  return res;
}

/* Qualitaet grob aus einer Original-Luma-Tabelle schaetzen */
function estimateQuality(q) {
  if (!q) return 85;
  var best = 85, bd = 1e9;
  for (var Q = 20; Q <= 100; Q++) {
    var t = scaleQuant(STD_LQ, Q), s = 0;
    for (var i = 0; i < 64; i++) s += Math.abs(t[i] - q[ZZ.indexOf(i)] );
    if (s < bd) { bd = s; best = Q; }
  }
  return best;
}

G.isJpeg = isJpeg; G.jpegScan = jpegScan; G.toStdJpeg = toStdJpeg; G.decodeJpeg = decodeJpeg;
G.encodeJpeg = encodeJpeg; G.estimateQuality = estimateQuality; G.JPEG_ZZ = ZZ;
})(window);
