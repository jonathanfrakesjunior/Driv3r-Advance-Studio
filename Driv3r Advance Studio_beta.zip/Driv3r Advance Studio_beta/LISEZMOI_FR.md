# Driv3r Advance Studio

Outil de modding pour **Driv3r** (Game Boy Advance, version européenne, code B3RP, 8 Mo).
Fonctionne dans le navigateur sans installation : **double-cliquez sur `index.html`** (ou `Driv3r Advance Studio starten.bat`).
Ni serveur, ni Python, ni connexion Internet nécessaires. Testé avec Chrome/Edge.

**Langues :** Deutsch, English, Français, Español, Italiano – à choisir en haut à droite (mémorisé).

ROM attendue : SHA-1 `3e4da1cd2a5915d2218cd59e061baeb3a08be1c6`.

## Premiers pas

1. Ouvrez `index.html`, cliquez sur **Charger la ROM** (ou glissez le .gba dans la fenêtre).
2. Choisissez une section à gauche : exporter, modifier, importer.
3. Enregistrez régulièrement le projet sous **ROM & projet** (`.d3studio` – ne contient que vos modifications).
4. **Enregistrer la ROM** crée le `.gba` final (la somme de contrôle de l'en-tête est corrigée). Testez toujours dans mGBA.
   Autre possibilité : **Créer un patch IPS** pour partager sans la ROM.

Le fichier original n'est jamais modifié. Quand la place manque, le Studio déplace automatiquement les données en fin de ROM,
met à jour tous les pointeurs et étend la ROM à 16 Mo si nécessaire (la sauvegarde EEPROM ne permet pas davantage).

## Sections

| Section | Contenu | Format |
|---|---|---|
| Images & textures | Écran titre, menu principal, 2 textures 3D du menu, 10 atlas de textures des villes 256×256 | PNG indexé ; compression VC automatique |
| Cinématiques | 213 images fixes de l'histoire 240×160, 33 séquences sous-titrées (EN/FR/DE/ES/IT) | PNG/JPG en entrée, JPEG réencodé automatiquement |
| Sprites | 23 véhicules (tous les angles), animations des personnages, effets | PNG par image (même dans une nouvelle taille) ou en planche (8 images/ligne) |
| HUD, police & skyline | Symboles du HUD, police du menu, **police du jeu** (256 caractères 8×16 pour tous les messages), 6 panoramas de skyline | PNG 4 bits, éditeur de caractères |
| Palettes | 16 fichiers de palette (villes jour/soir/nuit, menus, HUD) | sélecteur de couleur, JASC .pal, .act, PNG |
| Textes | Messages de mission en 5 langues, crédits, textes des menus | éditeur + CSV |
| Son & musique | 10 morceaux (tracker GBAMOD30), 16 instruments, 38 effets | WAV, export/import MIDI, .gbamod brut |
| Éditeur de carte | Miami & Nice en vue de dessus texturée issue des données 3D, voies de circulation | **Construire bâtiments, routes avec circulation IA, places, eau, rampes, ponts** ; supprimer/déplacer/retexturer des faces, vider/restaurer des cellules, descripteurs |
| Missions | 25 missions (Miami 1–12, Nice 13–25) avec toutes les étapes, les 19 commandes nommées | modifier champs/hexa, insérer/supprimer/déplacer des étapes, déplacer les points sur la carte, JSON |
| Paquet complet | tout en ZIP, dans les deux sens | réimporté sans modification, la ROM reste identique à l'octet près |

### Astuces

* **Images :** les PNG indexés gardent leurs indices. Les images RVB sont adaptées à la palette. Pour des images plein écran
  entièrement nouvelles, cochez « Créer de nouvelles couleurs » – le Studio calcule une palette propre dans la plage autorisée.
* Les **textures des villes** sont appliquées sur les faces 3D via des descripteurs (cadres). L'option « Cadres de texture » les montre dans l'atlas.
  Laissez les motifs au même endroit ou ajustez le descripteur dans l'éditeur de carte.
* **Musique via MIDI :** attribuez un instrument à chaque canal MIDI ; les accords sont répartis sur jusqu'à 8 canaux GBA.
  « Écouter » calcule l'aperçu dans le navigateur sans enregistrer. Importez d'abord vos propres instruments en WAV.
* **Construire (éditeur de carte → Construire) :** *Bâtiment* : cliquez les sommets, un double-clic construit (emprise convexe, hauteur,
  étage, texture de façade/toit, massif, occultation). *Sol/route* : tracez un rectangle – route, herbe, eau ou
  graphisme seul ; hauteurs de début/fin différentes = rampe, hauteur au-dessus de l'eau = pont. Les routes d'au moins 64 unités
  de large reçoivent automatiquement deux voies opposées avec circulation IA (conduite à droite), raccordées aux voies proches (jusqu'à 200 unités)
  – commencez donc de préférence à un carrefour. Le calque « Circulation » affiche toutes les voies.
  *Faces* : cliquez des faces pour les supprimer, les déplacer, les retexturer ou changer leur matériau.
  À la première construction, la ville est copiée en fin de ROM (la ROM passe à 16 Mo) ; l'original reste intact.
* **Missions :** 00 début de mission (jeu de textures, heure du jour, véhicule, position de départ), 02 point de sauvegarde,
  03 cibles avec limite de temps, 04/0B/10 se rendre à (zone, repère ou objet, avec flèche radar), 05 cinématique,
  06 message (numéro = ID du message dans l'onglet Textes), 07 chrono, 08 barrage (6 objets), 09 véhicule IA avec itinéraire,
  0A acteur avec compte à rebours, 0C poursuite, 0D formation, 0E attendre un acteur, 0F course, 11 chemin, 12 mission réussie.
  L'éditeur de carte affiche les points de la mission choisie ; on peut les déplacer à la souris.
* **Police du jeu :** dans « HUD, police & skyline » → groupe « Police ». Les caractères nouvellement dessinés (p. ex. minuscules)
  sont ensuite acceptés dans l'éditeur de texte.

## Notes techniques (pour les curieux)

* Compression « VC » (VD-dev) : en-tête `VC`, taille u32, mode 0–9 ; flux de bits avec codes gamma (décodeur du jeu à 0x08254338).
* Graphismes : mode 4 (bitmap 8 bits), HUD/police/skyline en objets 4 bits en mode 1D.
* Ville : 128×128 cellules de 512 unités, grille à la base de la carte (Miami 0x5F8800, Nice 0x4B0000),
  descripteurs de texture à base+0xC000, table des missions via base+0x11020, surfaces de collision via base+0x1101C,
  murs d'occultation via base+0x11000, voies de circulation via base+0x11064 (par voie : nœuds X/hauteur/Y + successeurs).
  Entrées de cellule : 0 géométrie (doit être en premier, fournit la hauteur du sol), 1 occultation, 2 détail, 3 objets,
  4 collision, 5 points d'apparition de la circulation.
* Interpréteur de missions à 0x0816E178 (table d'initialisation 0x0817137C, table de mise à jour 0x0816E324).
* Police du jeu : pointeur à 0x234E54, 256 caractères de 8×16 pixels, 4 bits.
* Son : « LS_Play (C) Logik State 2003 », fréquence de mixage 10512 Hz, morceaux « GBAMOD30 » (colonnes de canaux codées RLE).
* Cinématiques : JPEG standard, seul le marqueur SOS FFDA est stocké en FF1A.

## Mod : Vice City (mods/Driv3r - Vice City Mod.gba)

Miami est entièrement remplacée par une ville d'après le modèle `werkzeuge/vice_city_karte.png` (Nice reste d'origine) :
deux îles principales avec plage, parcs, aéroport, ponts et petites îles, 365 tronçons de route avec circulation IA
(730 voies), environ 740 bâtiments le long des routes (hauts blocs sur les zones blanches du modèle), quais, eau.
La densité de construction est choisie pour que le jeu tourne à 20 images/s comme l'original.
Le départ du joueur et les voitures de départ sont dans le centre-ville de l'île ouest ; tous les points de mission ont été déplacés
vers la nouvelle route la plus proche (mission 1 entièrement relative au nouveau départ). Les missions sont donc jouables mais ne suivent
plus la géographie d'origine de Miami – on peut les ajuster davantage dans l'éditeur de missions.
La ROM peut être ouverte et modifiée dans le Studio (construction, faces, circulation).

**Vos propres villes :** `werkzeuge/stadt_aus_bild.py <image.png> <sortie.gba> [unités par pixel]` (Python avec numpy,
scipy, scikit-image, Pillow). Couleurs du modèle : bleu = eau, noir = route, jaune = plage, vert = parc,
gris = zone constructible, blanc = hauts bâtiments. La ROM originale est lue dans le dossier du Studio.

## Limites

* Les emprises des bâtiments doivent être convexes (composez les formes en L ou en U avec plusieurs bâtiments).
* Les objets des cellules (type 3 : lampadaires, bouches d'incendie, etc.) sont affichés et conservés, mais pas modifiables individuellement.
* L'aperçu des morceaux dans le navigateur est une reproduction du lecteur tracker – dans le jeu, le son peut légèrement différer.
